using UnityEngine;
using System.IO;

[CreateAssetMenu(fileName = "ResourceData", menuName = "SO/New ResourceData", order = 9)]
[System.Serializable]
public class ResourceData : ScriptableObject
{
    public int totalResources;
    public int usedResources;

    // JSON으로 저장
    public void SaveToJson(string path)
    {
        string jsonData = JsonUtility.ToJson(this, true);
        File.WriteAllText(path, jsonData);
    }

    // JSON에서 로드
    public void LoadFromJson(string path)
    {
        if (File.Exists(path))
        {
            string jsonData = File.ReadAllText(path);
            JsonUtility.FromJsonOverwrite(jsonData, this);
        }
    }
}
