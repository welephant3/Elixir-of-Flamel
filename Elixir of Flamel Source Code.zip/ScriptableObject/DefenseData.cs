using System.Collections.Generic;
using UnityEngine;
using System.IO;

[CreateAssetMenu(fileName = "DefenseData", menuName = "SO/New DefenseData", order = 8)]
[System.Serializable]
public class DefenseData : ScriptableObject
{
    public List<WallPositionData> walls = new List<WallPositionData>();
    public List<TowerPositionData> towers = new List<TowerPositionData>();
    public ResourceData resourceData; // 자원 정보 추가

    public int baseMaxEnemies = 10; // 기본 최대 적 수
    public int maxEnemies; // 실제 최대 적 수

    // JSON으로 저장
    public void SaveToJson(string path)
    {
        string jsonData = JsonUtility.ToJson(this, true);
        File.WriteAllText(path, jsonData);
    }

    // JSON에서 로드
    public void LoadFromJson(string path)
    {
        if (File.Exists(path))
        {
            string jsonData = File.ReadAllText(path);
            JsonUtility.FromJsonOverwrite(jsonData, this);
        }
    }
}

[System.Serializable]
public class WallPositionData
{
    public Vector2 position;
}

[System.Serializable]
public class TowerPositionData
{
    public Vector2 position;
    public int upgradeLevel; // 업그레이드 레벨 추가
    public int towerType;    // 타워 종류 추가

    // JSON으로 저장
    public string ToJson()
    {
        return JsonUtility.ToJson(this);
    }

    // JSON에서 로드
    public static TowerPositionData FromJson(string jsonData)
    {
        return JsonUtility.FromJson<TowerPositionData>(jsonData);
    }
}