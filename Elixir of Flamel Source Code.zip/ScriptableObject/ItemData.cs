using UnityEngine;

[System.Serializable]
public class RecipeMaterials
{
    public string itemId;
    public ItemData data;
    public int value;
}

[CreateAssetMenu(fileName = "Item", menuName = "SO/New Item", order = 0)]
public class ItemData : ScriptableObject
{
    [Header("Info")]
    public string itemId;
    public eItemType itemType; //추후 아이템 타입을 설정할 때 사용 일반 아이템/섭취 가능 아이템/장착 아이템/설치 아이템 등
    public string displayName; //이름
    public string description; // 설명
    public Sprite icon; //아이콘으로 사용할 Sprite 등록

    [Header("Stacking")]
    public bool canStack = true; //아이템을 여러 개 습득 가능한지 체크
    public int maxStackAmount = 99; //최대 쌓을 수 있는 갯수

    [Header("Recipe")]
    //public eCraftType craftType; //장착 장비나, 포션, 건축물 등 아이템 타입을 결정
    public RecipeMaterials[] recipe; // 제작 가능한 아이템이라면 (Default가 아니라면) 제작에 들어가는 재료를 세팅
    public int resultQuantity; //생성하면 제작될 양을 결정

    public enum EffectType
    {
        HealthRecovery,
        StaminaRecovery,
        SpeedBoost
    }

    [Header("Effect Type")]
    public EffectType effectType;

    [Header("Effect Values")]
    public float value;
    public float duration;
}