using UnityEngine;

[CreateAssetMenu(fileName = "Tower", menuName = "SO/New Tower", order = 5)]

public class TowerData : ScriptableObject
{
    public int towerType; // 타워 타입 필드 추가
    public TowerLevel[] levels;
    public RuntimeAnimatorController animatorController; // 애니메이션 컨트롤러 추가
    public WeaponType weaponType; // 무기 유형 추가
    public int initialCost;    // 타워 설치 비용 추가
}

[System.Serializable]
public class TowerLevel
{
    public Sprite towerSprite;
    public float attackPower;
    public float attackRange;
    public float attackCooldown;
}

public enum WeaponType
{
    Arrow,
    Bullet
}
