using UnityEngine;

public enum eNPCFunc
{
    PRODUCTION,
    RELIEF,
    GROW
}
[CreateAssetMenu(fileName = "NPC", menuName = "SO/New NPC", order = 4)]
public class NPCData : ScriptableObject
{
    public int id;
    public string name;
    public string[] ScriptTxt;
    public string btntxt;
    public Sprite NPCImg;
    public eNPCFunc NPCFunc; //리팩토링시 NPC 오브젝트에 붙이고 타입으로 분류 시도
}
