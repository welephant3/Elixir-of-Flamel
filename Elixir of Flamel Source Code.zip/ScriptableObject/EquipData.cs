using UnityEngine;

[System.Serializable]

public class ItemDataEquippable
{
    public eEquipStatType type;
    public float value;
}

[CreateAssetMenu(fileName = "EquipItem", menuName = "SO/New Equip", order = 2)]
public class EquipData : ItemData
{
    [Header("Equip")]
    public string EquipId = "E";
    public eEquipType equiptype;
    public ItemDataEquippable[] equipStats;
    public bool isEquipped;

    private void OnEnable()
    {
        itemType = eItemType.EQUIP;
        canStack = false;
        maxStackAmount = 0;
    }

    [Header("Equip")]
    public GameObject equipPrefab; // 장착시 사용할 장비 프리펩

    public ObjectStat ToObjectStat()
    {
        ObjectStat stat = new ObjectStat
        {
            StatChangeType = eStatChangeType.ADD,
            StatDataSO = ScriptableObject.CreateInstance<ObjectStatData>() // 새로운 스탯 데이터 생성
        };

        foreach (var equipStat in equipStats)
        {            
            switch (equipStat.type)
            {
                case eEquipStatType.ATK:
                    stat.StatDataSO.DamageValue = equipStat.value;
                    break;
                case eEquipStatType.DEF:
                    stat.StatDataSO.DefenseValue = equipStat.value;
                    break;
                    // 다른 스탯 타입 추가시 여기에
            }
        }

        stat.Id = int.Parse(itemId);

        return stat;
    }
}