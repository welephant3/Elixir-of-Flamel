using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ProductList
{
    public bool isMaked;
    public EquipData data;
}
[CreateAssetMenu(fileName = "Town", menuName = "SO/New Town", order = 7)]
public class TownSceneData : ScriptableObject
{
    //Todo 타운씬 데이터 SaveData에 등록
    public int curDays;
    public ProductList[] productLists;
    public bool isReliefed;
    public bool isNotEnough;
    public List<ItemData> GrowData = new List<ItemData>(); // 재료 슬롯의 아이템 데이터
    public bool isGrowed;
    public bool[] VisitFeild;
}
