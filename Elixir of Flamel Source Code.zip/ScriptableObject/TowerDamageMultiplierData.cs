using UnityEngine;

[CreateAssetMenu(fileName = "TowerDamageMultiplierData", menuName = "SO/New TowerDamageMultiplierData", order = 10)]
public class TowerDamageMultiplierData : ScriptableObject
{
    public float damageMultiplier = 1.0f; // 초기 데미지 배율

    // 데미지 배율을 변경하는 메서드
    public void SetDamageMultiplier(float multiplier)
    {
        damageMultiplier = multiplier;
    }
}
