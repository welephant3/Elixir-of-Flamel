using UnityEngine;

[CreateAssetMenu(fileName = "DefenseEnemy", menuName = "SO/New DefenseEnemyData", order = 6)]
public class DefenseEnemyData : ScriptableObject
{
    public float maxHealth;
}