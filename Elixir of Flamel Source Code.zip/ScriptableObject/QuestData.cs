using UnityEngine;

public enum eQuestType
{
    PRODUCTION,
    RELIEF,
    GROW
}
[System.Serializable]
public class TargetData
{
    public ItemData targetData;
    public int targetCurCount;
    public int targetCount;
}
[System.Serializable]
public class QuestDatas
{
    [Header("QuestType")]
    public eQuestType type;
    [Header("QuestState")]
    public bool isAcceptable;
    public bool isProgress;
    public bool isSatisfy;
    public bool isSucess;
    [Header("QuestInfo")]
    public int questID;
    public string title;
    public string beforeAcceptTxt;
    public string descriptionTxt;
    public string rewardTxt;
    public TargetData[] targetData;
    public int[] ActivateQuestindex;
}



[CreateAssetMenu(fileName = "Quest", menuName = "SO/New Quest", order = 9)]
public class QuestData : ScriptableObject
{
    public QuestDatas[] data;
}
