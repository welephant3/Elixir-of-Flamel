using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class EnvironmentGenerator : MonoBehaviour
{
    [SerializeField] private RandomMapGenerator randomMapGenerator;

    [Header("타일맵")]
    [SerializeField] private Tilemap waterTileMap;
    [SerializeField] private Tilemap environmentTileMap;
    [SerializeField] private Tilemap obstacleTileMap;

    [Header("룰타일")]
    [SerializeField] private RuleTile waterTile;
    [SerializeField] private RuleTile environmentTile;
    [SerializeField] private RuleTile obstacleTile;

    [Header("생성 확률 설정, .'n'f로 설정")]
    [SerializeField] private float waterTileRate;
    [SerializeField] private float environmentTileRate;
    [SerializeField] private float obstacleTileRate;
        
    private List<Vector3Int> _objectPositions;    
    private int _mapSize;    

    private void Awake()
    {
        _mapSize = randomMapGenerator.mapSize;
        _objectPositions = randomMapGenerator.GetObjectPositions();           
    }

    private void Start()
    {
        GenerateEnvironment();
    }

    private void GenerateEnvironment()
    {
        waterTileMap.ClearAllTiles();
        environmentTileMap.ClearAllTiles();
        obstacleTileMap.ClearAllTiles();

        Vector3Int point = Vector3Int.zero;

        //타일 배치 순서에 따라 부적절한 경우(ex.위 타일이 아랫 타일의 위에 그려지는 경우)를 방지하고자 역순으로 변경함.
        //아래는 가독성을 위해서 남겨놓은 기존에 작성한 코드. 추가로 x와 y의 순서도 변경함. 일반 반복문의 반대라고 생각하면 됨.
        //for (int x = 2; x < _mapSize - 2; x++)        
        //    for (int y = 2; y < _mapSize - 2; y++)
        for (int y = _mapSize - 3; y >= 2; y--)
        {
            for (int x = _mapSize - 3; x >= 2; x--)

            {
                point.Set(x, y, 0);                
                PlaceRandomTile(point);
            }
        }
    }

    private void PlaceRandomTile(Vector3Int position)
    {
        float randomValue = Random.value;

        if (randomValue < waterTileRate)
        {
            waterTileMap.SetTile(position, waterTile);
            SetCollider(position, Tile.ColliderType.Grid);
            if (!IsPlaceCollider(waterTileMap, position))
            {
                waterTileMap.SetTile(position, null);
            }
        }
        else if (randomValue < waterTileRate + environmentTileRate)
        {
            environmentTileMap.SetTile(position, environmentTile);
            SetCollider(position, Tile.ColliderType.None);
        }
        else if (randomValue < waterTileRate + environmentTileRate + obstacleTileRate)
        {
            obstacleTileMap.SetTile(position, obstacleTile);
            SetCollider(position, Tile.ColliderType.Grid);
            if (!IsPlaceCollider(obstacleTileMap, position))
            {
                obstacleTileMap.SetTile(position, null);
            }
        }                
    }

    //생성된 타일에 콜라이더 설정
    private void SetCollider(Vector3Int pos, Tile.ColliderType colliderType)
    {
        TileBase tile = environmentTileMap.GetTile(pos);
        if (tile != null)
        { 
            environmentTileMap.SetColliderType(pos, colliderType);            
        }
    }

    //타일 배치시 개별 타일의 경계를 확인하고 겹치는지 확인
    private bool IsPlaceCollider(Tilemap tilemap, Vector3Int position)
    {
        Bounds tileBounds = tilemap.GetTileBounds(position);
        for (int i = 0; i < _objectPositions.Count; i++)
        {
            //타일의 경계 안에 오브젝트 위치가 포함되는지 확인
            if (tileBounds.Contains(_objectPositions[i]))
            {
                return false ;
            }
        }
        return true;
    }
}

//주어진 타일 위치에서 타일의 경계를 가져오는 확장 메서드를 제공
public static class TilemapExtensions
{
    public static Bounds GetTileBounds(this Tilemap tilemap, Vector3Int position)
    { 
        TileBase tile = tilemap.GetTile(position);
        if (tile == null)
        { 
            return new Bounds();
        }

        tilemap.CompressBounds();
        Vector3 tileCenter = tilemap.GetCellCenterLocal(position);
        return new Bounds(tileCenter, tilemap.cellSize);
    }
}