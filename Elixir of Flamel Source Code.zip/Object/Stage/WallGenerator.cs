using UnityEngine;
using UnityEngine.Tilemaps;

public class WallGenerator : MonoBehaviour
{
    [SerializeField] private RandomMapGenerator _randomMapGenerator;

    [SerializeField] private Tilemap wallTileMap;
    [SerializeField] private RuleTile wallTile;

    public BoundsInt.PositionEnumerator _bounds;
    private int _mapSize;

    private void Start()
    {
        _mapSize = _randomMapGenerator.mapSize;
        _bounds = _randomMapGenerator.groundTileMap.cellBounds.allPositionsWithin;
        SettingWallTile(_mapSize);
    }

    private void SettingWallTile(int mapSize)
    {   
        wallTileMap.ClearAllTiles();

        Vector3Int point = Vector3Int.zero;

        for (int x = -1; x <= mapSize; x++)
        {
            for (int y = -1; y <= mapSize; y++)
            {
                point.Set(x, y, 0);                

                //맵 테두리에 벽 타일 배치
                if (x == -1 || x == mapSize-1 || y == -1 || y == mapSize-1)
                {
                    wallTileMap.SetTile(point, wallTile);
                }
            }
        }

        //벽 타일에만 콜라이더 추가
        foreach (var pos in _bounds)
        {
            if (_randomMapGenerator.groundTileMap.GetTile(pos) == wallTile)
            {                
                wallTileMap.GetComponent<TilemapCollider2D>();
                wallTileMap.GetComponent<CompositeCollider2D>();
            }            
        }
    }
}