using System.Collections.Generic;
//using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Tilemaps;

//Perlin Noise(랜덤한 지형)와 Fractal Noise(보다 자연스러운 지형)을 혼용 + (바이옴적용)Voronoi Noise로 다양성을 추가
//Perlin Noise : 파동 형태로 구성된 무작위 패턴을 생성하는 노이즈, 지형의 높낮이와 그에 맞는 타일맵을 배치.
//Fractal Noise : 저주파 Perlin Noise와 고주파 Perlin Noise를 중첩하여 얻어낸 디테일한 노이즈
//=====> 자연스러운 지형을 만드는 데 사용
//Voronoi Noise : 임의의 여러 점을 선택 후, 그 점으로부터 가장 가까운 점을 얼마나 가까운지 표현한 노이지
//=> 바이옴 : 맵을 다양한 생태계로 구분하여 각 구역에 특성을 부여하는 데 사용, 다만 기획의 의도와는 다소 거리감이 있어서 구현은 배제함.


public class RandomMapGenerator : MonoBehaviour
{
    [Header("타일맵 관련")]
    public Tilemap groundTileMap;  //타일맵 컴포넌트  
    [SerializeField] private GameObject startPos;
    [SerializeField] private GameObject exitPos;
    [Tooltip("포탈과 타일의 태그")]
    [SerializeField] private string startPortalTag, exitPortalTag, tileTag;

    [Space(10)]
    [Header("값 관련")]
    public int mapSize;  //맵의 크기
    [SerializeField] private float mapScale = 0.01f;  //맵의 스케일(노이즈의 크기 조절)
    [SerializeField] private int octaves;  //노이즈 중첩 횟수      

    [Space]
    [Header("지형")]
    [SerializeField] private TileBase bottomLayer, middleLayer, upperLayer, additiveLayer;
        
    public List<Vector3Int> ObjectPosition = new List<Vector3Int>();    

    private float _seed;  //노이즈 생성을 위한 시드 값

    private void Awake() //async void Awake()
    {
        _seed = Random.Range(0, 10000f);  //랜덤 생성을 위한 값

        //var noiseArr = await Task.Run(GenerateNoise);  //노이즈 생성 대기
        var noiseArr = GenerateNoise();  //노이즈 생성 대기
        SettingTileMap(noiseArr);
    }

    private void OnEnable()
    {
        PlaceRandomObjects();
    }

    //노이즈 배열 생성 메서드, 중첩된 Perlin 노이즈를 사용, 각 위치에서 노이즈 값을 계산하고 0~1사이의 값으로 정규화함
    private float[,] GenerateNoise()
    {
        float[,] noiseArr = new float[mapSize, mapSize];
        float min = float.MaxValue;
        float max = float.MinValue;

        for (int x = 0; x < mapSize; x++)
        {
            for (int y = 0; y < mapSize; y++)
            {
                float lacunarity = 2.0f;  //주파수 증가율
                float gain = 0.5f;        //루프당 진폭 감소율
                float amplitude = 0.5f;   //진폭
                float frequency = 1f;     //주파수

                //저주파 노이즈와 고주파 노이즈를 중첩
                for (int i = 0; i < octaves; i++)
                {
                    //noiseArr[x, y] = Mathf.PerlinNoise(x * mapScale + _seed, y * mapScale + _seed); => PerlinNoise 생성
                    noiseArr[x, y] += amplitude * (Mathf.PerlinNoise(_seed + (x * mapScale * frequency), _seed + (y * mapScale + frequency) * 2 - 1));  // -1 ~ 1

                    frequency *= lacunarity;
                    amplitude *= gain;
                }

                //최소, 최대 노이즈 값 갱신
                if (noiseArr[x, y] < min)
                {
                    min = noiseArr[x, y];
                }
                else if (noiseArr[x, y] > max)
                {
                    max = noiseArr[x, y];
                }
            }
        }

        //중첩된 노이즈 값을 0~1로 변환
        for (int x = 0; x < mapSize; x++)
        {
            for (int y = 0; y < mapSize; y++)
            {
                noiseArr[x, y] = Mathf.InverseLerp(min, max, noiseArr[x, y]);  // = A, B 사이의 value가 있는 위치를 반환                                   
            }
        }
        return noiseArr;
    }

    //타일을 배치하는 메서드
    private void SettingTileMap(float[,] noiseArr)
    {
        groundTileMap.ClearAllTiles();  //타일맵 초기화       

        Vector3Int point = Vector3Int.zero;

        for (int x = 0; x < mapSize; x++)
        {
            for (int y = 0; y < mapSize; y++)
            {
                point.Set(x, y, 0);
                groundTileMap.SetTile(point, GetTileByHight(noiseArr[x, y]));  //타일 배치      
            }
        }
    }

    //높낮이에 맞는 타일을 반환하는 메서드
    private TileBase GetTileByHight(float height)
    {
        switch (height)
        {
            case <= 0.3f: return bottomLayer;
            case <= 0.8f: return middleLayer;
            case <= 0.95f: return upperLayer;
            default: return additiveLayer;
        }
    }

    private void PlaceRandomObjects()
    {
        PlaceObjectRandomly(startPos, startPortalTag);
        PlaceObjectRandomly(exitPos, exitPortalTag);
    }

    private void PlaceObjectRandomly(GameObject obj, string tag)
    {
        Vector3Int pos = GetValidPosition();
        if (pos != Vector3Int.zero)
        {
            Instantiate(obj).transform.position = pos;
            ObjectPosition.Add(pos);            
        }      
    }

    private Vector3Int GetValidPosition()
    {
        Vector3Int position;

        do
        {
            int x = Random.Range(2, mapSize - 4);
            int y = Random.Range(2, mapSize - 4);
            position = new Vector3Int(x, y, 0);

        } while (ObjectPosition.Contains(position));

        return position;
    }

    public List<Vector3Int> GetObjectPositions()
    { 
        return ObjectPosition;
    }
}