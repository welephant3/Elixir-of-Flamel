using UnityEngine;

public class Wall : MonoBehaviour
{
    public int wallCost = 1; // 벽의 설치 비용

    public void CancelWall()
    {
        DefenseResourceManager resourceManager = FindObjectOfType<DefenseResourceManager>();
        DefenseData defenseData = FindObjectOfType<DefenseManager>().defenseData;

        if (resourceManager != null)
        {
            resourceManager.RefundResources(wallCost);

            // 벽 데이터 삭제
            Vector2 position = new Vector2(transform.position.x, transform.position.y);
            defenseData.walls.RemoveAll(wall => wall.position == position);

            Destroy(gameObject);
        }
    }
}
