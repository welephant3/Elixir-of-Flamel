using UnityEngine;

public class WeaponAnimatorController : MonoBehaviour
{
    private Animator animator;

    void Awake()
    {
        animator = GetComponent<Animator>();
    }

    public void SetIdleState()
    {
        animator.SetBool("IsAttacking", false);
    }

    public void SetAttackState()
    {
        animator.SetBool("IsAttacking", true);
    }
}
