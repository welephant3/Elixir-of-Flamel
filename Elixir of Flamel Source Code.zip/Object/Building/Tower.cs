using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;

public class Tower : MonoBehaviour
{
    public TowerData towerData; // 타워 데이터(ScriptableObject)
    public GameObject upgradePanelPrefab; // 업그레이드 패널 프리팹
    public GameObject rangeIndicator; // 범위 표시기
    private int currentLevel = 0; // 현재 타워 레벨
    public ObjectPool objectPool;

    private float attackCooldownTimer; // 공격 쿨다운 타이머
    public Transform firePoint; // 총알 발사 지점
    private static GameObject currentUpgradePanel; // 현재 업그레이드 패널 인스턴스
    private static GameObject currentRangeIndicator; // 현재 범위 표시기 인스턴스
    private static Tower currentSelectedTower; // 현재 선택된 타워
    public int towerCost = 2; // 타워 설치 비용
    public List<int> upgradeCosts = new List<int> { 1, 2 }; // 업그레이드 비용 리스트 (기본값으로 설정)

    private DefenseResourceManager resourceManager;
    private WeaponAnimatorController weaponAnimator; // 타워 무기 애니메이터 컨트롤러

    public TowerDamageMultiplierData damageMultiplierData; // 데미지 배율 데이터

    //private SpriteRenderer spriteRenderer;


    private void Awake()
    {
        resourceManager = FindObjectOfType<DefenseResourceManager>();
        //spriteRenderer = GetComponent<SpriteRenderer>();
    }
    void Start()
    {
        objectPool = FindObjectOfType<ObjectPool>();
        weaponAnimator = GetComponentInChildren<WeaponAnimatorController>(); // 무기 애니메이터 참조
        SetTowerAttributes(currentLevel);

        InitializeUpgradeCosts();

        //int sortingOrder = Mathf.RoundToInt(-transform.position.y * 2);
        //spriteRenderer.sortingOrder = sortingOrder;

        // 타임 시스템 이벤트 구독
        TimeSystem.Instance.OnDayChange += ResetDamage;
    }

    void OnDestroy()
    {
        // 이벤트 구독 해제
        if (TimeSystem.Instance != null)
        {
            TimeSystem.Instance.OnDayChange -= ResetDamage;
        }
    }

    // 업그레이드 비용 리스트 초기화
    private void InitializeUpgradeCosts()
    {
        switch (towerData.towerType)
        {
            case 0: // 노말타워
                upgradeCosts = new List<int> { 1, 2 };
                break;
            case 1: // 중급타워
                upgradeCosts = new List<int> { 2, 4 };
                break;
        }
    }

    // 데미지 변경 메서드
    public void ChangeDamage(float multiplier)
    {
        damageMultiplierData.SetDamageMultiplier(multiplier);       
    }

    private void ResetDamage()
    {
        damageMultiplierData.SetDamageMultiplier(1.0f);        
    }

    void Update()
    {
        // 쿨다운 타이머 감소 및 적 탐지 및 공격 처리
        attackCooldownTimer -= Time.deltaTime;
        DetectAndAttack();

        // 타워 클릭 처리
        if (Input.GetMouseButtonDown(0))
        {
            HandleTowerClick();
        }
    }

    private void HandleTowerClick()
    {
        Vector2 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        RaycastHit2D hit = Physics2D.Raycast(mousePosition, Vector2.zero);

        if (hit.collider != null)
        {
            Tower clickedTower = hit.collider.gameObject.GetComponent<Tower>();
            if (clickedTower != null)
            {
                // 다른 타워 클릭 시 기존 타워의 업그레이드 패널과 범위 표시기 숨기기
                if (currentSelectedTower != null && currentSelectedTower != clickedTower)
                {
                    currentSelectedTower.HideRangeIndicator();
                    currentSelectedTower.HideUpgradePanel();
                }

                // 새 타워 선택 및 업그레이드 패널과 범위 표시기 업데이트
                clickedTower.OnTowerClick();
            }
        }
        else if (currentUpgradePanel != null && !IsPointerOverUIObject())
        {
            // UI가 아닌 곳을 클릭 시 업그레이드 패널과 범위 표시기 숨기기
            HideRangeIndicator();
            HideUpgradePanel();
            currentSelectedTower = null;
        }
    }

    private bool IsPointerOverUIObject()
    {
        // UI 객체 위에 포인터가 있는지 확인
        PointerEventData eventDataCurrentPosition = new PointerEventData(EventSystem.current)
        {
            position = new Vector2(Input.mousePosition.x, Input.mousePosition.y)
        };
        List<RaycastResult> results = new List<RaycastResult>();
        EventSystem.current.RaycastAll(eventDataCurrentPosition, results);
        return results.Count > 0;
    }

    void OnTowerClick()
    {
        // 업그레이드 패널과 범위 표시기 제거
        HideUpgradePanel();
        HideRangeIndicator();

        // 현재 선택된 타워 업데이트
        currentSelectedTower = this;

        // 업그레이드 패널 생성 및 위치 설정
        if (currentUpgradePanel == null && upgradePanelPrefab != null)
        {
            currentUpgradePanel = Instantiate(upgradePanelPrefab, Vector2.zero, Quaternion.identity, FindObjectOfType<Canvas>().transform);
            currentUpgradePanel.SetActive(true);
            UpdateUpgradePanel();
        }

        // 범위 표시기 활성화
        if (rangeIndicator != null)
        {
            currentRangeIndicator = rangeIndicator;
            rangeIndicator.SetActive(true);
            UpdateRangeIndicator(currentLevel);
        }
    }

    private void UpdateUpgradePanel()
    {
        // 업그레이드 패널의 텍스트와 버튼 업데이트
        TextMeshProUGUI[] texts = currentUpgradePanel.GetComponentsInChildren<TextMeshProUGUI>();
        Button upgradeButton = currentUpgradePanel.GetComponentInChildren<Button>();

        if (texts.Length >= 4)
        {
            TowerLevel current = towerData.levels[currentLevel];
            texts[0].text = $"데미지: {current.attackPower}";
            texts[1].text = $"공격속도: {current.attackCooldown}";

            if (currentLevel < towerData.levels.Length - 1)
            {
                TowerLevel next = towerData.levels[currentLevel + 1];
                texts[2].text = $"업그레이드시 데미지: {next.attackPower}";
                texts[3].text = $"업그레이드시 공격속도: {next.attackCooldown}";

                if (upgradeButton != null)
                {
                    upgradeButton.gameObject.SetActive(true);
                    upgradeButton.onClick.RemoveAllListeners();
                    upgradeButton.onClick.AddListener(UpgradeTower);
                }
            }
            else
            {
                texts[2].text = "최대 레벨입니다.";
                texts[3].text = "";

                if (upgradeButton != null)
                {
                    upgradeButton.gameObject.SetActive(false);
                }
            }
        }
    }

    public void UpgradeTower()
    {
        if (resourceManager != null && currentLevel < upgradeCosts.Count)
        {
            int upgradeCost = upgradeCosts[currentLevel];
            if (resourceManager.CanPlaceTower(upgradeCost))
            {
                resourceManager.UseResources(upgradeCost);
                currentLevel++;

                // 타워의 속성 업데이트
                SetTowerAttributes(currentLevel);

                // 타워 데이터 업데이트 및 JSON 저장
                DefenseManager defenseManager = FindObjectOfType<DefenseManager>();
                if (defenseManager != null)
                {
                    DefenseData defenseData = defenseManager.defenseData;
                    Vector2 position = new Vector2(transform.position.x, transform.position.y);

                    // 기존 타워 데이터 찾아서 업데이트
                    TowerPositionData towerData = defenseData.towers.Find(tower => tower.position == position);
                    if (towerData != null)
                    {
                        towerData.upgradeLevel = currentLevel;
                    }

                    // defenseData를 JSON으로 저장
                    defenseManager.SaveDefenseData();
                }

                // 업그레이드 패널 업데이트
                UpdateUpgradePanel();
            }
        }
    }

    private void SetTowerAttributes(int level)
    {
        // 타워 속성 설정
        TowerLevel data = towerData.levels[level];
        GetComponent<SpriteRenderer>().sprite = data.towerSprite;
        attackCooldownTimer = data.attackCooldown;

        // 범위 표시기 업데이트
        if (rangeIndicator != null && rangeIndicator.activeSelf)
        {
            UpdateRangeIndicator(level);
        }
    }

    private void UpdateRangeIndicator(int level)
    {
        // 범위 표시기의 크기 업데이트
        float radius = towerData.levels[level].attackRange;
        rangeIndicator.transform.localScale = new Vector3(radius * 1, radius * 1, 1);
    }

    private void DetectAndAttack()
    {
        // 적 탐지 및 공격
        if (attackCooldownTimer > 0) return;

        int enemyLayer = LayerMask.GetMask("DefenseEnemy");
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, towerData.levels[currentLevel].attackRange, enemyLayer);
        Collider closestEnemy = null;
        float closestDistance = float.MaxValue;

        foreach (var hitCollider in hitColliders)
        {
            if (hitCollider.CompareTag("DefenseEnemy"))
            {
                float distance = Vector3.Distance(transform.position, hitCollider.transform.position);
                if (distance < closestDistance)
                {
                    closestDistance = distance;
                    closestEnemy = hitCollider;
                }
            }
        }

        if (closestEnemy != null)
        {
            Attack(closestEnemy);
            attackCooldownTimer = towerData.levels[currentLevel].attackCooldown;
        }
        else
        {
            if (weaponAnimator != null)
            {
                weaponAnimator.SetIdleState();
            }
        }
    }

    private void Attack(Collider target)
    {
        GameObject projectile = null;
        switch (towerData.weaponType)
        {
            case WeaponType.Arrow:
                projectile = objectPool.SpawnFromPool("Arrow");
                break;
            case WeaponType.Bullet:
                projectile = objectPool.SpawnFromPool("Bullet");
                break;
        }

        // 발사체가 제대로 생성되었는지 확인
        if (projectile != null)
        {
            projectile.transform.position = firePoint.position; // 발사체의 위치 설정
            projectile.GetComponent<Projectile>().Initialize(target.transform, towerData.levels[currentLevel].attackPower);
        }

        // 무기 애니메이터 설정
        if (weaponAnimator != null)
        {
            //Vector3 direction = target.transform.position - transform.position;
            //float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            //weaponAnimator.transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));
            //weaponAnimator.transform.localPosition = Vector3.zero;
            weaponAnimator.SetAttackState();
        }
    }

    public void CancelTower()
    {
        // 타워 취소 처리 및 자원 환불
        if (resourceManager != null)
        {
            // 타워 설치 비용과 업그레이드 비용을 합산하여 환불
            int totalRefund = towerData.initialCost;
            for (int i = 0; i < currentLevel; i++)
            {
                totalRefund += upgradeCosts[i];
            }
            resourceManager.RefundResources(totalRefund);

            // 타워 데이터 삭제 및 JSON 파일 업데이트
            DefenseManager defenseManager = FindObjectOfType<DefenseManager>();
            if (defenseManager != null)
            {
                DefenseData defenseData = defenseManager.defenseData;
                Vector2 position = new Vector2(transform.position.x, transform.position.y);

                // 타워 데이터 삭제
                defenseData.towers.RemoveAll(tower => tower.position == position);

                // defenseData를 JSON으로 저장
                defenseManager.SaveDefenseData();
            }

            // 타워 오브젝트 제거
            Destroy(gameObject);
        }
    }

    private void HideRangeIndicator()
    {
        // 범위 표시기 숨기기
        if (currentRangeIndicator != null)
        {
            currentRangeIndicator.SetActive(false);
            currentRangeIndicator = null;
        }
    }

    private void HideUpgradePanel()
    {
        // 업그레이드 패널 숨기기
        if (currentUpgradePanel != null)
        {
            currentUpgradePanel.SetActive(false);
            Destroy(currentUpgradePanel);
            currentUpgradePanel = null;
        }
    }

    public int GetUpgradeLevel() => currentLevel; // 현재 업그레이드 레벨 반환
    public int GetTowerType() => towerData.towerType; // 타워 타입 반환
    public void SetTowerType(int type) => towerData.towerType = type; // 타워 타입 설정

    public void SetUpgradeLevel(int level)
    {
        // 업그레이드 레벨 설정 및 속성 업데이트
        currentLevel = level;
        SetTowerAttributes(level);
    }
}
