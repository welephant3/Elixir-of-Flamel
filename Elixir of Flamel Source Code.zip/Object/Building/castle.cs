using UnityEngine;
using UnityEngine.UI;

public class Castle : MonoBehaviour
{
    public float maxHealth;
    private float castleHP;

    public Image hpBarBackground; // HP 바 배경 이미지
    public Image hpBarFill; // HP 바 채우기 이미지
        
    void Start()
    {
        castleHP = maxHealth;

        // HP 바 초기화
        if (hpBarFill != null && hpBarBackground != null)
        {
            UpdateHPBar(); // 초기 상태로 HP 바 업데이트
        }
    }

    public void TakeDamage(float amount)
    {
        castleHP -= amount;
        if (castleHP <= 0)
        {
            castleHP = 0; // 체력이 0 이하로 떨어지지 않도록 보정
            GameOver();
        }
        UpdateHPBar();
    }

    void GameOver()
    {
        DefenseUIManager uiManager = FindObjectOfType<DefenseUIManager>();
        if (uiManager != null)
        {
            uiManager.ShowGameOverPanel(); // 게임오버 패널 표시
        }
    }

    void UpdateHPBar()
    {
        if (hpBarFill != null && hpBarBackground != null)
        {
            float healthPercent = Mathf.Clamp01(castleHP / maxHealth);
            hpBarFill.fillAmount = healthPercent;
        }
    }
}