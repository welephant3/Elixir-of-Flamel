using UnityEngine;

public class Equip : MonoBehaviour
{
    private Transform equipSlots;
    public EquipSlot[] slots { get; private set; }
    public ObjectStatHandler PlayerStatHandler;

    private void Awake()
    {
        equipSlots = transform.Find("EquipSlots");
        slots = new EquipSlot[equipSlots.childCount];
    }
    private void Start()
    {
        PlayerManager.Instance.equip += OnEquip;
        PlayerManager.Instance.unequip += OnUnequip;
        PlayerStatHandler = PlayerManager.Instance.PlayerInstanceOrigin.GetComponentInChildren<ObjectStatHandler>();

        for (int i = 0; i < slots.Length; i++)
        {
            slots[i] = equipSlots.GetChild(i).GetComponent<EquipSlot>();
            slots[i].equip = this;
            slots[i].slotIndex = i;
            slots[i].Clear();
        }
    }

    public void OnEquip(EquipData data)
    {
        slots[(int)data.equiptype].Set(data);
        var statModifier = data.ToObjectStat();        
        PlayerStatHandler.AddStatModifier(statModifier);
    }

    public virtual void OnUnequip(EquipData data)
    {
        slots[(int)data.equiptype].Clear();
        var statModifier = data.ToObjectStat();
        PlayerStatHandler.RemoveStatModifier(statModifier);
    }
}
