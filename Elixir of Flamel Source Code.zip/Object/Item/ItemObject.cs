using System.Collections;
using UnityEngine;

public class ItemObject : MonoBehaviour, IInteractable
{
    public ItemData data;
    //public AudioSource pickupSound; 추후 사운드 등록할 경우 사용
    //추후 아이템 제작관련 시스템을 넣을 경우 추가 등록
    private SpriteOutline _spriteOutline;

    private void Awake()
    {
        _spriteOutline = GetComponent<SpriteOutline>();
    }

    public void ClosePrompt()
    {
        if (PlayerManager.Instance.promptPanel.activeSelf)
        {
            //판넬 활성화 되어있으면 끄기
            PlayerManager.Instance.promptPanel.SetActive(false);
            _spriteOutline.UpdateOutline(false);
        }
    }

    public void GetInteractPrompt()
    {
        if (data != null)
        {
            PlayerManager.Instance.promptPanel.SetActive(true);
            string str = $"[{data.displayName}]\n{data.description}"; //아이템의 이름 및 설명 
            PlayerManager.Instance.promptText.text = str;

            _spriteOutline.UpdateOutline(true);

            StartCoroutine(ClosePromptAfterDelay(3.0f)); //3초 뒤에 프롬프트가 꺼지도록 세팅
        }
    }

    public void OnInteract()
    {
        //임시적으로 플레이어의 인벤토리에 넣는 기능 추가
        PlayerManager.Instance.itemData = data;
        PlayerManager.Instance.addItem?.Invoke();
        if(PlayerManager.Instance.isPickuped == true)
        {
            PickupItem();
            Destroy(gameObject);
            PlayerManager.Instance.isPickuped = false;
            Debug.Log("획득");
        }
        else
        {
            return;
        }
    }

    private IEnumerator ClosePromptAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        ClosePrompt();
    }

    private void PickupItem()
    {
        //// 아이템 획득 사운드 재생
        //if (pickupSound != null)
        //{
        //    pickupSound.Play();
        //}
    }
}
