using TMPro;
using UnityEngine;

public class StatUIUpdater : MonoBehaviour
{
    [Header("UI Texts")]
    public TextMeshProUGUI HpText;
    public TextMeshProUGUI SpText;
    public TextMeshProUGUI AtkText;
    public TextMeshProUGUI RangeText;
    public TextMeshProUGUI DefText;
    public TextMeshProUGUI SpeedText;

    private ObjectStatHandler _objectStatHandler;

    private void Awake()
    {
        _objectStatHandler = PlayerManager.Instance.PlayerInstanceOrigin.GetComponentInChildren<ObjectStatHandler>();
        
        UpdateUI();
                
        _objectStatHandler.OnStatChanged += UpdateUI;
    }

    private void OnDestroy()
    {
        if (_objectStatHandler != null)
        {
            _objectStatHandler.OnStatChanged -= UpdateUI;
        }
    }

    private void UpdateUI()
    {
        HpText.text = _objectStatHandler.CurrentStat.StatDataSO.MaxHealth.ToString();
        SpText.text = _objectStatHandler.CurrentStat.StatDataSO.MaxStamina.ToString();
        AtkText.text = _objectStatHandler.CurrentStat.StatDataSO.DamageValue.ToString("F0");
        RangeText.text = _objectStatHandler.CurrentStat.StatDataSO.MaxRange.ToString("F0");
        DefText.text = _objectStatHandler.CurrentStat.StatDataSO.DefenseValue.ToString("F0");
        SpeedText.text = _objectStatHandler.CurrentStat.StatDataSO.Speed.ToString("F0");
    }
}
