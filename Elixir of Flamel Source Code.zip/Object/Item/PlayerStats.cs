using System.Collections;
using UnityEngine;

public class PlayerStats : MonoBehaviour
{
    public ObjectStatData playerStatSO;
    public GameObject player;


    private void Start()
    {
        player = PlayerManager.Instance.PlayerInstance;
        playerStatSO = player.GetComponent<ObjectStatHandler>().CurrentStat.StatDataSO;
    }

    public void HealthRecovery(float amount)
    {
        player.GetComponent<HealthSystem>().ChangeHealth(amount);
    }

    public void StaminaRecovery(float amount, float duration)
    {
        StartCoroutine(StaminaRecoveryCoroutine(amount, duration));
    }
    private IEnumerator StaminaRecoveryCoroutine(float amount, float duration)
    {
        player.GetComponent<StaminaSystem>().staminaRecoveryRate += amount;
        yield return new WaitForSeconds(duration);
        player.GetComponent<StaminaSystem>().staminaRecoveryRate -= amount;
    }

    public void SpeedBoost(float amount, float duration)
    {
        StartCoroutine(SpeedBoostCoroutine(amount, duration));
    }

    private IEnumerator SpeedBoostCoroutine(float amount, float duration)
    {
        float originalSpeed = playerStatSO.Speed;
        playerStatSO.Speed += amount;
        yield return new WaitForSeconds(duration);
        playerStatSO.Speed = originalSpeed;
    }
}