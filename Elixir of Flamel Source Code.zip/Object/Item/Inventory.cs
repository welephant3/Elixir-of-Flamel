using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Inventory : MonoBehaviour
{
    private enum eDescriptionIndex
    {
        ITEM_NAME,
        ITEM_DESCRIPTION,
        STAT_NAME,
        STAT_VALUE
    }

    private enum eBtnIndex
    {
        USE_BTN,
        DROP_BTN,
        EQUIP_BTN,
        UNEQUIP_BTN,
        INSTALL_BTN
    }

    public event Action InventoryRefresh; //인벤토리 변경 때마다 새로고침

    [Header("Inventory")]
    private Transform Inventoryslots; //슬롯이 담긴 Transform 저장
    [SerializeField] private List<TextMeshProUGUI> selectedDescriptions; //아이템 설명창에 있는 텍스트를 담을 리스트
    [SerializeField] private List<GameObject> invenBtns = new List<GameObject>(); // 인벤토리에 존재하는 버튼들을 리스트화 
    public ItemSlot[] slots { get; private set; } //슬롯들을 리스트화
    public ItemSlot selectedSlot; // 현재 선택된 슬롯을 담을 변수
    public PlayerStats playerStats;

    private void Start()
    {
        Inventoryslots = transform.Find("Slots");

        foreach (Transform transform in transform.Find("Info"))
        {
            if (transform.TryGetComponent(out TextMeshProUGUI component))
                selectedDescriptions.Add(component);
        }

        foreach (Transform transform in transform.Find("InvenBtns"))
        {
            invenBtns.Add(transform.gameObject);
        }

        invenBtns[(int)eBtnIndex.USE_BTN].GetComponent<Button>().onClick.AddListener(OnUseBtn); //특정 인덱스 버튼 클릭시 실행될 로직
        invenBtns[(int)eBtnIndex.DROP_BTN].GetComponent<Button>().onClick.AddListener(OnDropBtn);
        invenBtns[(int)eBtnIndex.EQUIP_BTN].GetComponent<Button>().onClick.AddListener(OnEquipBtn);
        invenBtns[(int)eBtnIndex.UNEQUIP_BTN].GetComponent<Button>().onClick.AddListener(OnUnequipBtn);
        
        slots = new ItemSlot[Inventoryslots.childCount];

        for (int i = 0; i < slots.Length; i++) //각 리스트에 슬롯의 인덱스를 등록해주고 초기화
        {
            slots[i] = Inventoryslots.GetChild(i).GetComponent<ItemSlot>();
            slots[i].inventory = this;
            slots[i].slotIndex = i;
            slots[i].Clear();
        }

        if (PlayerManager.Instance.addItem == null)
        {
            PlayerManager.Instance.addItem += AddItem; //additem에 구독시킴
        }

        //스탯 연결시 스탯 업데이트
        //아이템 드랍시 드랍 포지션도 구독시킴

        ClearSelectedItemWindow(); //초기 설명칸 스크립트, 버튼 초기화
        UpdateUI();
    }
 
    
    private void OnUseBtn()
    {
        UseItem(selectedSlot.item);
        RemoveSelectedItem(1);        
    }

    private void OnDropBtn() //아이템을 드롭시킬때 씀
    {
        if (selectedSlot.item is EquipData equipData)
        {
            if (selectedSlot.isEquiped == true)
            {
                return;
            }
        }

        RemoveSelectedItem(1);
    }

    public void OnEquipBtn() //장착시 동작할 스크립트
    {
        if (selectedSlot.item is EquipData equipData)
        {
            for (int i = 0; i < slots.Length; i++)
            {
                if (slots[i].item is EquipData data && data.equiptype == equipData.equiptype && slots[i].isEquiped == true)
                {
                    slots[i].isEquiped = false;
                    slots[i].EquipUI.gameObject.SetActive(false);
                    PlayerManager.Instance.UnEquip(data);
                }
            }           
            selectedSlot.isEquiped = true;
            selectedSlot.EquipUI.gameObject.SetActive(true);
            PlayerManager.Instance.Equip(equipData);

            invenBtns[(int)eBtnIndex.EQUIP_BTN].SetActive(false);
            invenBtns[(int)eBtnIndex.UNEQUIP_BTN].SetActive(true);
        }
    }
    public void UseItem(ItemData itemData)
    {
        switch (itemData.effectType)
        {
            case ItemData.EffectType.HealthRecovery:
                playerStats.HealthRecovery(itemData.value);
                break;

            case ItemData.EffectType.StaminaRecovery:
                playerStats.StaminaRecovery(itemData.value, itemData.duration);
                break;

            case ItemData.EffectType.SpeedBoost:
                playerStats.SpeedBoost(itemData.value, itemData.duration);
                break;
        }

    }
    public void OnUnequipBtn() //장착 해제시 동작할 스크립트
    {
        if (selectedSlot.item is EquipData equipData)
        {
            //def 스탯 원복 등 위의 주석내용 반대의 작업 필요.           
            selectedSlot.isEquiped = false;
            selectedSlot.EquipUI.gameObject.SetActive(false);
            PlayerManager.Instance.UnEquip(equipData);

            invenBtns[(int)eBtnIndex.EQUIP_BTN].SetActive(true);
            invenBtns[(int)eBtnIndex.UNEQUIP_BTN].SetActive(false);
        }
    }
        
    public void AddItem() 
    {
        ItemData data = PlayerManager.Instance.itemData; 
        AddItem(data);
    }
    public void AddItem(ItemData data)
    {
        if (data.canStack)
        {
            ItemSlot slot = GetItemStack(data);
            if (slot != null) //stack이 가능하고 현재 인벤토리에 존재할 떄.
            {
                slot.quantity++;
                UpdateUI();
                PlayerManager.Instance.itemData = null;
                PlayerManager.Instance.isPickuped = true;
                return;
            }
        }

        ItemSlot emptySlot = GetEmptySlot();

        if (emptySlot != null) //빈 슬롯이 존재할 떄.
        {
            emptySlot.item = data;
            emptySlot.quantity = 1;
            UpdateUI();
            PlayerManager.Instance.itemData = null;
            PlayerManager.Instance.isPickuped = true;
            return;
        }
        else
        {
            PlayerManager.Instance.itemData = null;
            return;
        }
    }

    private void ClearSelectedItemWindow()
    {
        selectedSlot = null;

        foreach (var element in selectedDescriptions)
        {
            element.text = string.Empty;
        }

        foreach (var element in invenBtns)
        {
            element.SetActive(false);
        }
    }

    public void UpdateUI()
    {
        for (int i = 0; i < slots.Length; i++)
        {
            if (slots[i].item != null)
            {
                slots[i].Set();
            }
            else
            {
                slots[i].Clear();
            }
        }

        InventoryRefresh?.Invoke(); //Refresh 실행
    }

    public void RemoveSelectedItem(int value)
    {
        for(int i = 0; i< value; i++)
        {
            selectedSlot.quantity--;
        }

        if (selectedSlot.quantity <= 0)
        {
            selectedSlot.item = null;
            ClearSelectedItemWindow();
        }

        UpdateUI();
    }

    public void SelectItem(int index)
    {
        if (slots[index].item == null) return; //선택한 슬롯에 아이템이 없다면 반환

        if (selectedSlot != null) //기존에 선택한 슬롯이 있다면 초기화
        {
            selectedSlot.SelectedDisable();

            if (selectedSlot.item is EquipData equip)
                equip.isEquipped = false;
        }

        ClearSelectedItemWindow();
        selectedSlot = slots[index]; //selectedSlot에 현재 선택한 슬롯의 인덱스를 넣고

        //이름과 설명을 입력
        selectedDescriptions[(int)eDescriptionIndex.ITEM_NAME].text = selectedSlot.item.displayName;
        selectedDescriptions[(int)eDescriptionIndex.ITEM_DESCRIPTION].text = selectedSlot.item.description;

        //아이템 슬롯에 있는 타입에 따라 버튼 활성화
        if (selectedSlot.item.itemType == eItemType.CONSUME)
        {
            invenBtns[(int)eBtnIndex.USE_BTN].SetActive(true);
        }
        // 선택한 아이템타입이 건설이면, 설치 버튼 활성화

        else
        {
            if (selectedSlot.item is EquipData equipItem)
            {
                for (int i = 0; i < equipItem.equipStats.Length; i++)
                {
                    selectedDescriptions[(int)eDescriptionIndex.STAT_NAME].text
                        += equipItem.equipStats[i].type.ToString() + ":\n";
                    selectedDescriptions[(int)eDescriptionIndex.STAT_VALUE].text
                        += equipItem.equipStats[i].value.ToString() + "\n";
                }

                if (slots[index].isEquiped)
                {
                    invenBtns[(int)eBtnIndex.UNEQUIP_BTN].SetActive(true);
                }
                else
                {
                    invenBtns[(int)eBtnIndex.EQUIP_BTN].SetActive(true);
                }
            }
        }

        invenBtns[(int)eBtnIndex.DROP_BTN].SetActive(true);
    }

    //인벤토리에 들어온 아이템을 쌓을 수 있는지 여부. 
    public ItemSlot GetItemStack(ItemData data)
    {
        for (int i = 0; i < slots.Length; i++)
        {
            if (slots[i].item == data && slots[i].quantity < data.maxStackAmount)
            {
                return slots[i];
            }
        }
        return null;
    }

    //비어있는 슬롯을 찾아주고 없으면 null 반환.
    private ItemSlot GetEmptySlot()
    {
        for (int i = 0; i < slots.Length; i++)
        {
            if (slots[i].item == null)
            {
                return slots[i];
            }
        }
        return null;
    }
}
