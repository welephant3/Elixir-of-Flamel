using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UIInventory : MonoBehaviour
{
    private enum eUIInventory //인벤토리와 장착 탭을 구분
    {
        INVENTORY,
        EQUIP
    }

    [Header("Workshop")]
    public List<GameObject> UIinvenBtns = new List<GameObject>(); //버튼을 받아올 리스트
    public List<GameObject> UIinvenPanels = new List<GameObject>(); // 판넬을 받아올 리스트
    public int currentActiveIndex; //현재 인덱스 숫자를 저장할 변수
    private int _sortOrder = 30;
    private Canvas _canvas;

    private void Awake()
    {
        _canvas = GetComponentInParent<Canvas>();

        foreach (Transform child in transform.Find("Btns")) //버튼을 찾아서 리스트에 입력
        {
            UIinvenBtns.Add(child.gameObject);
        }

        foreach (Transform child in transform.Find("Panels")) //판넬을 찾아서 리스트에 입력
        {
            UIinvenPanels.Add(child.gameObject);
            if (!child.gameObject.activeSelf)
                child.gameObject.SetActive(true);
        }
    }
    void Start()
    {
        //인벤토리 키 입력시 사용할 Action에 구독시킴
        PlayerManager.Instance.PlayerInstance.GetComponent<PlayerInteraction>().OnInventoryEvent += ToggleUIInventory;

        UIinvenBtns[(int)eUIInventory.INVENTORY].GetComponent<Button>().onClick.AddListener(OnInvenClicked); //특정 인덱스 버튼클릭시 실행할 로직
        UIinvenBtns[(int)eUIInventory.EQUIP].GetComponent<Button>().onClick.AddListener(OnEquipClicked); 

        StartCoroutine(DelayedStart());
        SceneManager.sceneLoaded += OnSceneLoad;
    }

    private IEnumerator DelayedStart()
    {
        yield return null;

        foreach (GameObject obj in UIinvenPanels) //판넬을 등록한 뒤 전체 비활성화
        {
            obj.SetActive(false);
        }
        currentActiveIndex = 0; // 인덱스를 인벤토리를 초기값으로
        ToggleBtns(currentActiveIndex); //인벤토리를 켜놓은 상태로 초기화

        gameObject.SetActive(false); //모든 초기화 완료 후 자기자신 끄기.
    }

    private void ToggleUIInventory()
    {
        if (gameObject.activeSelf)
        {
            gameObject.SetActive(false);
            if (GameManager.Instance.IsCanShoot)
            { GameManager.Instance.ConnectShootEvent(); }
        }
        else
        {
            if (_canvas.sortingOrder != _sortOrder)
            { _canvas.sortingOrder = _sortOrder; }
            gameObject.SetActive(true);
            TutorialController.Instance.TutorialUIOn(ref TutorialController.Instance.IsInventory, (int)eFunctionName.INVENTORY);
            if (GameManager.Instance.IsCanShoot)
            { GameManager.Instance.DisconnectShootEvent(); }
        }
    }

    private void OnInvenClicked()
    {
        ToggleBtns((int)eUIInventory.INVENTORY);
    }

    private void OnEquipClicked()
    {
        ToggleBtns((int)eUIInventory.EQUIP);
    }

    private void ToggleBtns(int index)
    {
        UIinvenBtns[currentActiveIndex].SetActive(true);
        UIinvenPanels[currentActiveIndex].SetActive(false);

        currentActiveIndex = index;
        UIinvenBtns[currentActiveIndex].SetActive(false);
        UIinvenPanels[currentActiveIndex].SetActive(true);
    }

    private void OnSceneLoad(Scene scene, LoadSceneMode mode)
    {
        gameObject.SetActive(false);
    }
}
