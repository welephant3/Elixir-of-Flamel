using System.Collections;
using UnityEngine;

// 플레이어에 붙을 스크립트
public interface IInteractable
{
    public void GetInteractPrompt(); //화면에 띄울 프롬프트 
    public void ClosePrompt();
    public void OnInteract(); // Interact 되었을 시 발동되는 효과 정하기
}

public class Interaction : MonoBehaviour
{
    [Header("Interact Ray")] // 수치변경및 테스트를 위한 SerializeField 설정 차후 private
    [SerializeField]private float checkRate = 0.01f;
    private float lastCheckTime; // 최근 체크한 시간
    [SerializeField]private float maxCheckDistance; // 체크할 최대 거리
    public LayerMask layerMask; // 상호작용이 가능한 오브젝트에 걸어둘 Layer (Interactable 설정)
    private float increaseAngle = 90.0f;
    public bool isPortal = false;

    [Header("Ray Object")]
    [SerializeField] public GameObject curInteractGameObject; // 검출할 오브젝트
    public IInteractable curInteractable; // IInteractable 캐싱

    private void Start()//
    {
        PlayerManager.Instance.PlayerInstance.GetComponent<PlayerInteraction>().OnInteractionEvent += OnInteractInput;
    }
      
    void Update()
    {
        if (Time.time - lastCheckTime > checkRate && !isPortal) // 시간-최근 체크 시간이 체크 빈도보다 클 떄
        {
            lastCheckTime = Time.time; //체크 타임을 동기화
            Vector2 origin = transform.position;  // 캐릭터의 현재 위치
            bool interactableFound = false; //

            // 45도 간격으로 360도 방향으로 Ray를 쏨
            for (float angle = 0; angle < 360; angle += increaseAngle)
            {
                // 각도에 따라 Ray의 방향을 설정
                Vector2 direction = Quaternion.Euler(0, 0, angle) * Vector2.right;

                RaycastHit2D[] hits = Physics2D.RaycastAll(origin, direction, maxCheckDistance);
                
                foreach (RaycastHit2D hit in hits)
                {
                    //Player 레이어 무시.
                    if (((1 << hit.collider.gameObject.layer) & layerMask) != 0) //player Layer와 검출할 레이어가 같지 않을때는 0 , 같을때는 1이 출력됨
                    {
                        if (hit.collider.gameObject != curInteractGameObject) // 기존 게임오브젝트와 다르다면 새로 담기
                        {
                            curInteractGameObject = hit.collider.gameObject;

                            if (hit.collider.gameObject.TryGetComponent(out IInteractable interactable)) //interactable을 상속받은 스크립트를 가진 오브젝트일때만
                            {
                                if (curInteractable != null)
                                {
                                    curInteractable.ClosePrompt();
                                }

                                curInteractable = interactable;
                                curInteractable.GetInteractPrompt();
                            }
                        }
                        interactableFound = true;
                        break; // 첫 번째 충돌체만 처리하고 루프 종료.
                    }
                }
            }

            if (!interactableFound)
            {
                if (curInteractable != null)
                {
                    curInteractable.ClosePrompt();
                }

                curInteractGameObject = null; // 부딪히지 않았다면 초기화
                curInteractable = null;
            }
        }
    }

    public void OnInteractInput() //E키를 눌러 습득한 경우 프롬프트를 닫고 구현된 상호작용을 실행
    {
        if (curInteractable != null)
        {
            curInteractable.ClosePrompt();
            curInteractable.OnInteract();

            // Portal 스크립트인지 확인하고 InteractionType이 Field인지 검사
            if (curInteractGameObject.TryGetComponent(out Portal portal))
            {
                isPortal = true;
            }

            // 초기화
            curInteractGameObject = null;
            curInteractable = null;
        }
    }

    public void swicthbool()
    {
        StartCoroutine(swicthbool(1));
    }

    private IEnumerator swicthbool(float delay)
    {
        yield return new WaitForSeconds(delay);
        isPortal = false;
    }
}
