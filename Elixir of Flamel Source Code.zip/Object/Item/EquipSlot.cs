using UnityEngine;
using UnityEngine.UI;

public class EquipSlot : MonoBehaviour
{
    public Equip equip;

    [Header("Item Slot Info")]
    public int slotIndex; //슬롯의 숫자 무기,투구,갑옷,목걸이,반지,신발 순
    private Button slotButton;

    private readonly string iconName = "Icon";
    public Image icon;

    private void Awake()
    {
        slotButton = GetComponent<Button>(); //추후 버튼관련 기능 추가할 경우 사용 아니라면 리팩토링때 삭제
    }
    public void Set(EquipData data)
    {
        icon.gameObject.SetActive(true);
        icon.sprite = data.icon;
    }

    public void Clear()
    {
        icon.gameObject.SetActive(false);
    }
}
