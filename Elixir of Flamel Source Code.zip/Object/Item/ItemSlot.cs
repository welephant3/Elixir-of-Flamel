using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ItemSlot : MonoBehaviour
{
    public Inventory inventory; //Inventory에서 초기화.

    [Header("Item Slot Info")]
    public int slotIndex; //Inventory에서 초기화.
    public ItemData item; //Inventory에서 할당.
    private Button slotButton;

    private readonly string iconName = "Icon";
    private Image icon;

    private readonly string quantityName = "Quantity";
    private TextMeshProUGUI quatityText;
    public int quantity; //Inventory에서 할당.

    private readonly string boolEquip = "BoolEquip";
    public GameObject EquipUI;

    private readonly string selectName = "Select";
    private Image selectEdge;
    private bool isSelected;
    public bool isEquiped = false;

    private void Awake()
    {
        slotButton = GetComponent<Button>();

        icon = transform.Find(iconName).GetComponent<Image>();

        if (icon != null)
        {
            quatityText = icon.transform.Find(quantityName).GetComponent<TextMeshProUGUI>(); //숫자 입력할 Txt받아옴
            selectEdge = icon.transform.Find(selectName).GetComponent<Image>(); //선택시 활성화될 버튼 클릭 이펙트
            EquipUI = icon.transform.Find(boolEquip).gameObject;

            quantity = 0;
            isSelected = false;
            EquipUI.gameObject.SetActive(false);
        }
    }

    private void Start()
    {
        slotButton.onClick.AddListener(OnClickSlot); //버튼에 OnClickSlot 등록
    }

    private void OnEnable()
    {
        selectEdge.enabled = isSelected;
    }

    public void Set() //Inventory에서 호출 슬롯 세팅
    {
        icon.gameObject.SetActive(true);
        icon.sprite = item.icon;
        quatityText.text = quantity > 0 ? quantity.ToString() : string.Empty;
    }

    public void Clear() //Inventory에서 호출 슬롯 초기화
    {
        item = null;
        icon.gameObject.SetActive(false);
        quatityText.text = string.Empty;
    }

    public void OnClickSlot() //클릭시 Inventory SelectItem실행 테두리 활성화
    {
        if (item != null)
        {
            inventory.SelectItem(slotIndex);
            isSelected = true;
            selectEdge.enabled = isSelected;
        }
    }

    public void SelectedDisable() // 이미 선택된 슬롯이 있을시 비활성화 Inventory에서 실행
    {
        isSelected = false;
        selectEdge.enabled = isSelected;
    }
}
