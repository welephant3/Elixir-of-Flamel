using UnityEngine;

public class StartPickUpItem : MonoBehaviour
{
    [SerializeField]
    public new string name;
    public string info;

    private void Start()
    {
        name = gameObject.GetComponent<ItemObject>().data.displayName;
        info = gameObject.GetComponent<ItemObject>().data.description;
    }

    public void ClosePrompt()
    {
        if (PlayerManager.Instance.promptPanel.activeSelf)
        {
            //판넬 활성화 되어있으면 끄기
            PlayerManager.Instance.promptPanel.SetActive(false);
        }
    }

    public void GetInteractPrompt()
    {
        PlayerManager.Instance.promptPanel.SetActive(true);
        string str = $"[{name}]\n{info}"; //아이템의 이름 및 설명 
        PlayerManager.Instance.promptText.text = str;
    }

    public void OnInteract()
    {
        gameObject.SetActive(false);
    }
}
