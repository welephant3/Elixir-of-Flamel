using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float speed = 10f; // 총알의 속도
    private Transform target; // 총알의 목표 타겟
    private float attackPower; // 총알의 공격력

    private ObjectPool objectPool; // 오브젝트 풀의 참조

    private void Awake()
    {
        // 오브젝트 풀의 참조를 가져옴
        objectPool = FindObjectOfType<ObjectPool>();
    }

    // 총알을 초기화
    public void Initialize(Transform target, float attackPower)
    {
        this.target = target;
        this.attackPower = attackPower;
        SetDirection();
    }

    private void Update()
    {
        // 타겟이 없다면 총알을 풀로 반환
        if (target == null)
        {
            ReturnToPool();
            return;
        }

        // 타겟을 향해 이동
        MoveTowardsTarget();

        // 타겟에 근접했는지 확인
        if (IsCloseToTarget())
        {
            // 타겟을 공격
            HitTarget();
        }
    }

    private void SetDirection()
    {
        Vector3 direction = (target.position - transform.position).normalized;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle -90));
    }

    // 타겟을 향해 이동하는 로직
    private void MoveTowardsTarget()
    {
        transform.position = Vector3.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
    }

    // 타겟에 근접했는지 확인하는 로직
    private bool IsCloseToTarget()
    {
        return Vector3.Distance(transform.position, target.position) < 0.1f;
    }

    // 타겟을 공격하는 로직
    private void HitTarget()
    {
        EnemyAI enemyAI = target.GetComponent<EnemyAI>();
        if (enemyAI != null)
        {
            // 타겟의 체력을 공격력만큼 감소
            enemyAI.TakeDamage(attackPower);
        }
        // 총알을 풀로 반환
        ReturnToPool();
    }

    // 총알을 오브젝트 풀로 반환
    private void ReturnToPool()
    {
        if (objectPool != null)
        {
            objectPool.ReturnObject(gameObject);
        }
        else
        {            
            Destroy(gameObject);
        }
    }
}
