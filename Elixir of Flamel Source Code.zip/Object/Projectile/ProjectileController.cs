using UnityEngine;

public class ProjectileController : MonoBehaviour
{
    [SerializeField] private LayerMask hitLayer;
    [SerializeField] private string particleTag;

    private Rigidbody2D _rigidbody;
    private SpriteRenderer _spriteRenderer;
    private TrailRenderer _trailRenderer;
    private ObjectStatData _objectStatData;
    private ParticleSystem _particleSystem;

    private Vector2 _direction;
    private float _currentDuration;
    private bool isReady;

    public bool IsOnDestroyFx = true;

    private void Awake()
    {
        _rigidbody = GetComponent<Rigidbody2D>();
        _spriteRenderer = GetComponent<SpriteRenderer>();
        _trailRenderer = GetComponent<TrailRenderer>();        
    }

    private void Update()
    {
        if (!isReady)
        { return; }

        _currentDuration += Time.deltaTime;

        if (_currentDuration > _objectStatData.Delay)
        {
            DestroyProjectile(transform.position, false);
        }

        _rigidbody.velocity = _direction * _objectStatData.ProjectileSpeed;        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (IsLayerMatched(hitLayer.value, collision.gameObject.layer))
        {
            Vector2 destroyPosition = collision.ClosestPoint(transform.position) - _direction * .2f;
            DestroyProjectile(destroyPosition, IsOnDestroyFx);
        }
        else if (IsLayerMatched(_objectStatData.Target.value, collision.gameObject.layer))
        {
            HealthSystem healthSystem = collision.GetComponent<HealthSystem>();
            if (healthSystem != null)
            {
                bool isAttacked = healthSystem.ChangeHealth(-_objectStatData.DamageValue);
                if (isAttacked && _objectStatData.IsOnKnockback)
                { ApplyKnockback(collision); }
            }
            DestroyProjectile(collision.ClosestPoint(transform.position), IsOnDestroyFx);
        }
    }

    private bool IsLayerMatched(int layerMask, int objectLayer)
    {
        return layerMask == (layerMask | (1 << objectLayer));
    }

    private void ApplyKnockback(Collider2D collision)
    {
        EntityMovement movement = collision.GetComponent<EntityMovement>();
        if (movement != null)
        {
            movement.ApplyKnockback(transform, _objectStatData.KnockbackDistance, _objectStatData.KnockbackTime);
        }
    }

    //발사체 초기화 메서드
    public void InitializeAttack(Vector2 direction, ObjectStatData data)
    { 
        this._objectStatData = data;
        this._direction = direction;

        UpdateProjectileSprite();
        _trailRenderer.Clear();
        _currentDuration = 0;
        _spriteRenderer.color = _objectStatData.ProjectileColor;

        transform.right = this._direction;

        isReady = true;
    }

    private void UpdateProjectileSprite()
    {
        transform.localScale = Vector3.one * _objectStatData.Size;
    }
        
    private void DestroyProjectile(Vector3 position, bool createFx)
    {
        if (createFx)
        {
            _particleSystem = GameObject.FindGameObjectWithTag(particleTag).GetComponent<ParticleSystem>();
            _particleSystem.transform.position = position;
            ParticleSystem.EmissionModule em = _particleSystem.emission;
            em.SetBurst(0, new ParticleSystem.Burst(0, Mathf.Ceil(_objectStatData.Size * 5)));
            ParticleSystem.MainModule mm = _particleSystem.main;
            mm.startSpeedMultiplier = _objectStatData.Size * 10f;
            _particleSystem.Play();
        }
        gameObject.SetActive(false);
    }
}