using UnityEngine;

public class RecipeCheck : MonoBehaviour , IInteractable
{
    [SerializeField]
    public new string name;
    public string info;
    public int kind;

    public void ClosePrompt()
    {
        if (PlayerManager.Instance.promptPanel.activeSelf)
        {
            //판넬 활성화 되어있으면 끄기
            PlayerManager.Instance.promptPanel.SetActive(false);
        }
    }

    public void GetInteractPrompt()
    {
            PlayerManager.Instance.promptPanel.SetActive(true);
            string str = $"[{name}]\n{info}"; //아이템의 이름 및 설명 
            PlayerManager.Instance.promptText.text = str;
    }

    public void OnInteract()
    {
        if(kind == 0)
        {
            UIController.Instance.ShowUI<RecipeUI>(UIs.Popup);
            for (int i = 0; i < RecipeManager.Instance.recipePage.recipePages.Length; i++)
            {
                RecipeManager.Instance.recipePage.recipePages[i].gameObject.SetActive(false);
            }
            RecipeManager.Instance.recipePage.recipePages[0].gameObject.SetActive(true);
            GameManager.Instance.DisconnectMoveEvent();
            TutorialController.Instance.TutorialUIOn(ref TutorialController.Instance.IsRecipe, (int)eFunctionName.RECIPE);
        }
        else if(kind == 1)
        {
            UIController.Instance.ShowUI<RecipeUI>(UIs.Popup);
            for (int i = 0; i < RecipeManager.Instance.recipePage.recipePages.Length; i++)
            {
                RecipeManager.Instance.recipePage.recipePages[i].gameObject.SetActive(false);
            }
            RecipeManager.Instance.recipePage.recipePages[0].gameObject.SetActive(true);
            UIController.Instance.HideUI<RecipeUI>();
            UIController.Instance.ShowUI<AlchemyUI>(UIs.Popup);
            CraftingManager.Instance.DisplayInventoryItemsInCrafting();
            CraftingManager.Instance.CheckMaterialSlot();
        }
        else if(kind == 2)
        {
            UIController.Instance.ShowUI<RestUI>(UIs.Popup);
            PlayerManager.Instance.interaction.isPortal = true;
        }

        ClosePrompt();
    }

    public void OnExitBtnClick()
    {
        PlayerManager.Instance.interaction.swicthbool();
    }
}
