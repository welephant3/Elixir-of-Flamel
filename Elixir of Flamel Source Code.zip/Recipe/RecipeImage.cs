using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class RecipeImage : MonoBehaviour
{
    [SerializeField] public ItemData resultItemData; // 아이템 데이터에서 이미지 텍스트를 뽑아오고 알아서 부여함.
    [SerializeField] public ItemData[] materialItemData;
    public string itemId;

    [SerializeField] public Image resultImage; // 조합 아이템 이미지
    [SerializeField] public TextMeshProUGUI resultName; // 조합 아이템 이름
    [SerializeField] public TextMeshProUGUI resultText; // 조합 아이템 설명

    [SerializeField] public Image[] materialImages; // 재료 1, 2, 3
    private Sprite[] originalSprites; //  재료 이미지
    private Sprite emptySprites; // 기본 ? 이미지

    [SerializeField] public TextMeshProUGUI[] materialTexts; // 재료 1, 2, 3
    private string[] originalTexts; // 재료들 이름
    private string emptyTexts = ""; // 기본 ? 텍스트

    public bool isItemObtained = false; //아이템을 얻었을시 true

    private void Awake()
    {
        originalSprites = new Sprite[materialItemData.Length];
        originalTexts = new string[materialItemData.Length];
        emptySprites = RecipeManager.Instance.emptySprite;
        itemId = resultItemData.itemId;
        for(int i = 0;i < materialItemData.Length; i++)
        {
            originalSprites[i] = materialItemData[i].icon;
        }
        for(int i = 0; i < materialItemData.Length; i++)
        {
            originalTexts[i] = materialItemData[i].description;
        }

        if (isItemObtained == true)
        {
            UpdatePageState();
        }
        else
        {
            SetPageToUnknown();
        }
    }
    public void ItemObtainCheck()
    {
        if (isItemObtained == true)
        {
            UpdatePageState();
        }
        else
        {
            SetPageToUnknown();
        }
    }
    public void ItemObtain()
    {
        //아이템 얻었을시 아이템 레시피 활성화
        isItemObtained = true;

        if (isItemObtained == true)
        {
            UpdatePageState();
        }
        else
        {
            SetPageToUnknown();
        }
    }
    private void SetPageToUnknown()
    {
        // 페이지의 이미지들을 "?" 상태로 변경
        for (int i = 0; i < materialImages.Length; i++)
        {
            materialImages[i].sprite = emptySprites;
        }
        // 페이지의 텍스트들을 "?" 상태로 변경
        for (int i = 0; i < materialTexts.Length; i++)
        {
            materialTexts[i].text = emptyTexts;
        }
        resultImage.sprite = emptySprites;
        resultName.text = emptyTexts;
        resultText.text = emptyTexts;
    }
    private void UpdatePageState()
    {
        // 아이템을 얻었을 때 설정한 이미지와 텍스트로 변경
        for (int i = 0; i < originalSprites.Length; i++)
        {
            materialImages[i].sprite = originalSprites[i];
        }

        for (int i = 0; i < originalTexts.Length; i++)
        {
            materialTexts[i].text = originalTexts[i];
        }

        resultImage.sprite = resultItemData.icon;
        resultName.text = resultItemData.displayName;
        resultText.text = resultItemData.description;
    }
}
