using UnityEngine;

public class RecipeManager : Singleton<RecipeManager>
{
    public RecipeUI recipeUI;
    public RecipeImage[] recipes;
    public RecipePage recipePage;
    public Sprite emptySprite;

    public bool[] saveData;

    public void SaveRecipe(int num)
    {
        saveData[num] = true;
    }


    public void CheckItemObtain(ItemData data) // 아이템 획득시 해당 아이템 레시피 활성화
    {
        for(int i = 0; i < recipes.Length; i++)
        {
            if(data.itemId == recipes[i].itemId)
            {
                recipes[i].ItemObtain();
                SaveRecipe(i);
                return;
            }
        }
    }
}
