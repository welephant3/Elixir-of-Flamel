using UnityEngine;
using UnityEngine.UI;

public class RecipePage : MonoBehaviour
{
    public Image[] recipePages; // 레시피 페이지들

    private int currentIndex = 0; // 현재 페이지

    public void OnNextBtn() //다음 페이지로 넘어가는 버튼
    {
        int nextIndex = (currentIndex + 1) % recipePages.Length;
        SetActiveObject(nextIndex);
        currentIndex = nextIndex;
    }

    public void OnPreviousBtn() //이전 페이지로 넘어가는 버튼
    {
        int previousIndex = (currentIndex - 1 + recipePages.Length) % recipePages.Length;
        SetActiveObject(previousIndex);
        currentIndex = previousIndex;
    }

    private void SetActiveObject(int index) //현재 페이지를 보여주고, 변경 전 페이지를 숨김
    {
        for(int i = 0; i < recipePages.Length; i++)
        {
            recipePages[i].gameObject.SetActive(i == index);
        }
    }
}
