using System.Collections;
using TMPro;
using UnityEngine;

public class TextEffect : MonoBehaviour
{
    public TextMeshProUGUI textObject;

    public float textDelay = 0.2f; // 한 글자가 나타나는 간격

    public string fullText;

    public void OnEnable()
    {
        fullText = textObject.text; 
        StartCoroutine(ShowText());
    }

    IEnumerator ShowText()
    {
        for (int i = 0; i <= fullText.Length; i++)
        {
            textObject.text = fullText.Substring(0, i); // i까지의 글자만 표시

            yield return new WaitForSecondsRealtime(textDelay);
        }
        fullText = null;
    }
}
