using UnityEngine;
using UnityEngine.UI;

public class CanvasManager : MonoBehaviour
{
    private void Start()
    {
        Button button = transform.Find("RecipeButton").GetComponent<Button>();        
    }
}
