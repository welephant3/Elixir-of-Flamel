using TMPro;
using UnityEngine.UI;

public class AcceptableQuestUI : PopupUI
{
    private NPCData data;
    public TextMeshProUGUI titleTxt;
    public TextMeshProUGUI descriptionTxt;
    public Button AcceptBtn;
    public TextMeshProUGUI AcceptBtnTxt;

    public int curQuestindex;


    private void OnEnable()
    {
        data = NPCManager.Instance.data;
        AcceptBtn.gameObject.SetActive(true);
        CheckAceeptableQuest();
    }
    public void OnAcceptBtnClick()
    {
        if (QuestManager.Instance.questList.data[curQuestindex].isAcceptable)
        {
            QuestManager.Instance.Logic.AddQuest(curQuestindex);

        }
        else if (QuestManager.Instance.questList.data[curQuestindex].isSatisfy)
        {
            QuestManager.Instance.Logic.ClearQuest(curQuestindex);
        }
        UIController.Instance.HideUI<AcceptableQuestUI>();
    }

    public void OnExitBtnClick()
    {
        UIController.Instance.HideUI<AcceptableQuestUI>();
    }

    void CheckAceeptableQuest()
    {
        for (int i = 0; i < QuestManager.Instance.questList.data.Length; i++)
        {
            if (QuestManager.Instance.questList.data[i].isAcceptable == false && QuestManager.Instance.questList.data[i].isSatisfy == false)
                continue;

            if ((int)QuestManager.Instance.questList.data[i].type == (int)data.NPCFunc)
            {
                curQuestindex = i;
                titleTxt.text = QuestManager.Instance.questList.data[i].title;
                descriptionTxt.text = QuestManager.Instance.questList.data[i].descriptionTxt;

                if(QuestManager.Instance.questList.data[i].isAcceptable)
                {
                    AcceptBtnTxt.text = "수락하기";
                }
                else
                {
                    AcceptBtnTxt.text = "완료하기";
                }
                return;
            }
        }

        titleTxt.text = "퀘스트 없음";
        descriptionTxt.text = "현재 수락할 퀘스트가 없습니다";
        AcceptBtn.gameObject.SetActive(false);
    }
}