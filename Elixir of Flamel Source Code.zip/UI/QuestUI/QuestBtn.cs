using TMPro;
using UnityEngine;

public class QuestBtn : MonoBehaviour
{
    public TextMeshProUGUI title;
    public QuestDatas questData;

    public QuestPanelUI PanelUI;

    private void Start()
    {
        PanelUI = GetComponentInParent<QuestPanelUI>();
    }

    public void SetData(QuestDatas data)
    {
        questData = data;
        title.text = data.title;
    }

    public void OnbtnClick()
    {
        PanelUI.UpdateUI(questData);
    }
}
