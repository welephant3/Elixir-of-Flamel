using UnityEngine;

public class QuestLogic : MonoBehaviour
{
    public ItemData[] FinalRecipe;

    public void AddQuest(int index)
    {
        var questData = QuestManager.Instance.questList.data[index];
        QuestManager.Instance.curQuest.Add(questData);
        questData.isAcceptable = false;
        questData.isProgress = true;
        int curQuestType = (int)questData.type;

        switch (curQuestType)
        {
            case 0:
                NPCManager.Instance.Product += CheckProductQuestProgress;
                 break;
            case 1:
                NPCManager.Instance.Relief += CheckReliefQuestProgress;
                break;
            case 2:
                NPCManager.Instance.Grow += CheckGrowQuestProgress;
                break;
        }
    }


    public void ClearQuest(int index)
    {
        var questData = QuestManager.Instance.questList.data[index];
        questData.isSatisfy = false;
        questData.isSucess = true;

        QuestManager.Instance.curQuest.Remove(questData);

        int curQuestType = (int)questData.type;

        switch (curQuestType)
        {
            case 0:
                NPCManager.Instance.Product -= CheckProductQuestProgress;
                break;
            case 1:
                NPCManager.Instance.Relief -= CheckReliefQuestProgress;
                break;
            case 2:
                NPCManager.Instance.Grow -= CheckGrowQuestProgress;
                break;
        }
        QuestReward(index);
        ActivateQuest(index);

        //퀘스트 데이터를 받아와 curQuest 리스트에서 삭제
        //Action 구독 해제
    }

    public void ActivateQuest(int index)
    {
        if (QuestManager.Instance.questList.data[index].ActivateQuestindex != null)
        {
            for(int i = 0; i< QuestManager.Instance.questList.data[index].ActivateQuestindex.Length; i++)
            {
                int curindex = QuestManager.Instance.questList.data[index].ActivateQuestindex[i];

                QuestManager.Instance.questList.data[curindex].isAcceptable = true;
            }
        }
    }

    public void QuestReward(int index)
    {
        if(index == 6)
        {
            PlayerManager.Instance.itemData = FinalRecipe[0];
            PlayerManager.Instance.inventory.AddItem();
        }
        else if (index == 7)
        {
            PlayerManager.Instance.itemData = FinalRecipe[1];
            PlayerManager.Instance.inventory.AddItem();
        }
        else if(index == 8)
        {
            PlayerManager.Instance.itemData = FinalRecipe[2];
            PlayerManager.Instance.inventory.AddItem();
        }
    }

    private void CheckProductQuestProgress(ItemData data, int quantitiy)
    {
        for (int i = 0; i < QuestManager.Instance.curQuest.Count; i++)
        {
            if((int)QuestManager.Instance.curQuest[i].type == 0)
            {
                for (int j = 0; j < QuestManager.Instance.curQuest[i].targetData.Length; j++)
                {
                    if (data.name == QuestManager.Instance.curQuest[i].targetData[j].targetData.name)
                    {
                        QuestManager.Instance.curQuest[i].targetData[j].targetCurCount += quantitiy;
                    }
                }
                break;
            }
        }
        CheckQuestSatisfy();
    }

    private void CheckReliefQuestProgress(ItemData data, int quantitiy)
    {
        for (int i = 0; i < QuestManager.Instance.curQuest.Count; i++)
        {
            if ((int)QuestManager.Instance.curQuest[i].type == 1)
            {
                if (data.name == QuestManager.Instance.curQuest[i].targetData[0].targetData.name)
                {
                    QuestManager.Instance.curQuest[i].targetData[0].targetCurCount += quantitiy;
                }
                break;
            }
        }
        CheckQuestSatisfy();
    }

    private void CheckGrowQuestProgress(ItemData data, int quantitiy)
    {
        for (int i = 0; i < QuestManager.Instance.curQuest.Count; i++)
        {
            if ((int)QuestManager.Instance.curQuest[i].type == 2)
            {
                if (data.name == QuestManager.Instance.curQuest[i].targetData[0].targetData.name)
                {
                    if (QuestManager.Instance.curQuest[i].targetData[0].targetCurCount + quantitiy > QuestManager.Instance.curQuest[i].targetData[0].targetCount)
                    {
                        QuestManager.Instance.curQuest[i].targetData[0].targetCurCount = QuestManager.Instance.curQuest[i].targetData[0].targetCount;
                    }
                    else
                    {
                        QuestManager.Instance.curQuest[i].targetData[0].targetCurCount += quantitiy;
                    }
                }
                break;
            }
        }
        CheckQuestSatisfy();
    }

    //void checkQuestProgress(ItemData data, int quantitiy)
    //{
    //    //퀘스트가 여러 개일 경우 다른 퀘스트마저 Data를 맞추는 상황인데 수정할 방법이 없을까?
    //    for(int i = 0; i < QuestManager.Instance.curQuest.Count; i++)
    //    {
    //        if (QuestManager.Instance.curQuest[i].isSatisfy)
    //            continue;

    //        switch((int)QuestManager.Instance.curQuest[i].type)
    //        {
    //            case 0:
    //                for (int j = 0; j< QuestManager.Instance.curQuest[i].targetData.Length; j++)
    //                {
    //                    if(data.name == QuestManager.Instance.curQuest[i].targetData[j].targetData.name)
    //                    {
    //                        QuestManager.Instance.curQuest[i].targetData[j].targetCurCount += quantitiy;
    //                    }
    //                }
    //                break;
    //            case 1:
    //                if (data.name == QuestManager.Instance.curQuest[i].targetData[0].targetData.name)
    //                {
    //                    QuestManager.Instance.curQuest[i].targetData[0].targetCurCount += quantitiy;
    //                }
    //                break;
    //            case 2:
    //                if (data.name == QuestManager.Instance.curQuest[i].targetData[0].targetData.name)
    //                {                        
    //                    if (QuestManager.Instance.curQuest[i].targetData[0].targetCurCount + quantitiy > QuestManager.Instance.curQuest[i].targetData[0].targetCount)
    //                    {
    //                        QuestManager.Instance.curQuest[i].targetData[0].targetCurCount = QuestManager.Instance.curQuest[i].targetData[0].targetCount;
    //                    }
    //                    else
    //                    {
    //                        QuestManager.Instance.curQuest[i].targetData[0].targetCurCount += quantitiy;
    //                    }
    //                }
    //                break;
    //        }
    //    }

    //    CheckQuestSatisfy();
    //}

    void CheckQuestSatisfy()
    {
        for(int i = 0; i< QuestManager.Instance.curQuest.Count; i++)
        {
            if (QuestManager.Instance.curQuest[i].isSatisfy)
                continue;

            bool isSatisfyed = true;

            for (int j = 0; j < QuestManager.Instance.curQuest[i].targetData.Length; j++)
            {
                if (QuestManager.Instance.curQuest[i].targetData[j].targetCurCount != QuestManager.Instance.curQuest[i].targetData[j].targetCount)
                {
                    isSatisfyed = false;
                    break; //같지 않다면 
                }
            }

            if(isSatisfyed)
            {
                QuestManager.Instance.curQuest[i].isProgress = false;
                QuestManager.Instance.curQuest[i].isSatisfy = true;
            }
        }
    }
}
