public class StartUI : SceneUI
{
    public void OnButtonClick()
    {
        UIController.Instance.ShowUI<MenuUI>(UIs.Popup);
    }
}
