using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CommonUI : SceneUI
{
    private HealthSystem _healthSystem;
    private StaminaSystem _staminaSystem;

    public float currentHealth => _healthSystem.CurrentHealth;
    float maxHealth => _healthSystem.MaxHealth;
    public float currentStamina => _staminaSystem.CurrentStamina;
    float maxStamina => _staminaSystem.MaxStamina;
    [SerializeField] private Slider HPSlider;
    [SerializeField] private Slider StaminaSlider;
    [SerializeField] public TextMeshProUGUI DayText;
    [SerializeField] public TextMeshProUGUI TimeText;
    [SerializeField] public TextMeshProUGUI isDayText;
    [SerializeField] public Image PopUp;    
    public Button button;
    public Button button2;        

    public int hour;
    public float min;
    public int day;
    public bool is_Pop_Up = false;    

    private void Start()
    {        
        _healthSystem = PlayerManager.Instance.PlayerInstance.GetComponent<HealthSystem>();
        _staminaSystem = PlayerManager.Instance.PlayerInstance.GetComponent<StaminaSystem>();
        
        _healthSystem.OnDamage += UpdateHealthUI;
        _healthSystem.OnHeal += UpdateHealthUI;
        _staminaSystem.OnStaminaChanged += UpdateStaminaUI;

        EventUIManager.Instance.commonUI = this;
        EndingManager.Instance.commonUI = this;

        UpdateHealthUI();
        UpdateStaminaUI(currentStamina);
    }

    private void Update()
    {     
        TimeSystem.Instance.UpdateTime();
        TimeSystem.Instance.UpdateDay();
        UpdateUI();
        if (!is_Pop_Up)
        {
            Pop_Up();
        }
    }

    private void UpdateUI()
    {
        hour = TimeSystem.Instance.hour;
        min = TimeSystem.Instance.min;
        day = TimeSystem.Instance.day;

        TimeText.text = hour.ToString("00") + ":" + min.ToString("00");
        DayText.text = "D+" + day.ToString();
        isDayText.text = TimeSystem.Instance.isDayText.ToString();
    }

    public void Pop_Up() // 팝업 시 시간 멈춤
    {
        if (hour == 18f && (min >= 00f && min <= 01f))
        {
            PopUp.gameObject.SetActive(true);
            is_Pop_Up = true;
            Time.timeScale = 0;
            TutorialController.Instance.TutorialUIOn(ref TutorialController.Instance.IsDefense, (int)eFunctionName.DEFENSE);
        }
        if (hour == 12f && (min >= 00f && min <= 01f))
        {
            if (day == 5 || day == 10)
            {
                EventUIManager.Instance.StartStoryEvent();
            }
            else
            {
                EventUIManager.Instance.StartRandomEvent();
            }
            is_Pop_Up = true;
            Time.timeScale = 0;
            TutorialController.Instance.TutorialUIOn(ref TutorialController.Instance.IsEvent, (int)eFunctionName.EVENT);
        }
        if (day == 15)
        {
            EndingManager.Instance.PlayEnding("Bad");
            is_Pop_Up = true;
        }
    }

    public void Pop_UpBtn() // 팝업 버튼 , 누르면 팝업이 사라지고 디펜스 씬으로 이동
    {
        var defenseManager = FindObjectOfType<DefenseManager>();
        if (defenseManager != null)
        {
            defenseManager.LoadDefenseData(); // 데이터 저장
        }

        PlayerManager.Instance.PlayerInstance.SetActive(false);
        PopUp.gameObject.SetActive(false);
        PlayerManager.Instance.interaction.curInteractGameObject = null; // 인식한 오브젝트가 있을 경우 생기는 버그 때문에 임시적으로 추가함
        PlayerManager.Instance.interaction.curInteractable = null; // 차후 리팩토링 필요할 수 있음
        
        SceneManager.LoadScene(6);
    }

    public void OnOpenOptionWindowBtn()
    {
        UIController.Instance.ShowUI<OptionUI>(UIs.Popup);
    }

    public void UpdateHealthUI()
    {
        HPSlider.value = currentHealth / maxHealth; // 플레이어 현재 체력에 따라 HP바가 유동적으로 바뀜
    }

    public void UpdateStaminaUI(float signature)
    {
        StaminaSlider.value = currentStamina / maxStamina; // 플레이어 현재 스테미나에 따라 스테미나바가 유동적으로 바뀜        
    }
}