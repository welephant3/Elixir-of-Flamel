using System.Collections.Generic;
using UnityEngine;

public enum UIs
{
    Popup,
    Scene,
}

public class ResourcesManager : Singleton<ResourcesManager>
{
    // 오브젝트 풀 처럼 캐싱을 한다.
    private Dictionary<string, BaseUI> uiDictionary = new Dictionary<string, BaseUI>();
    // 리소스로드는 아무튼 성능부하가 있다.
    // A씬, B씬, C씬,

    public GameObject GetUI(UIs type, string uiName)
    {
        return Resources.Load<GameObject>($"Prefabs/{type.ToString()}/{uiName}");
    }

    public BaseUI GetUIInDic(string uiName)
    {
        return uiDictionary[uiName];
    }

    public bool CheckUIDictionary(string uiName)
    {
        return uiDictionary.ContainsKey(uiName);
    }

    public void AddUIInDic(string uiName, BaseUI obj)
    {
        uiDictionary.Add(uiName, obj);
    }

    // 씬 전환 때 한번 호출
    public void ClearDic()
    {
        uiDictionary.Clear();
        UIController.Instance.curSortingOrder = 10;
    }
}
