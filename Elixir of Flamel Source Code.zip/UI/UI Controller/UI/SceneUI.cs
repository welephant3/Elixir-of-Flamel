﻿// 모든 PopupUI의 부모
public class SceneUI : BaseUI
{ }