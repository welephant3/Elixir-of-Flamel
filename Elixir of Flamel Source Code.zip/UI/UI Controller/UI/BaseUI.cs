using UnityEngine;

// 모든 UI들의 부모
public class BaseUI : MonoBehaviour
{
    // 모든 UI에 공통으로 있어야하는 로직을 작성.

    public int mySortingOrder;

    public void SetOrder(int order)
    {
        mySortingOrder = order;
        GetComponent<Canvas>().sortingOrder = order;
    }
}