using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class TutorialUIManager : MonoBehaviour
{
    public List<Button> SwicthImgBtns = new List<Button>(); // 한 튜토리얼 내의 이미지 변경 왼쪽, 오른쪽 순으로 등록
    public List<Button> SwicthPanelBtns = new List<Button>();
    public List<TutorialPanel> TutorialPanels = new List<TutorialPanel>();
    public TutorialPanel curPanel;
    public TextMeshProUGUI numberOfPages;

    public Transform scrollviewport;
    public GameObject btnPrefab;
    public Button ExitBtn;

    public int curindex = 0;
    public int curpage = 1;        

    public void Addtutorial(int panelIndex)
    {
        int index = curindex;
        GameObject newButtonObject = Instantiate(btnPrefab, scrollviewport);
        Button newButton = newButtonObject.GetComponent<Button>();
        TextMeshProUGUI tmp = newButtonObject.GetComponentInChildren<TextMeshProUGUI>();

        eFunctionName ePanelName = (eFunctionName)panelIndex;
        string panelName = ePanelName.ToString();

        SwicthPanelBtns.Add(newButton);
        newButton.onClick.AddListener(() => SwicthPanel(panelIndex));
        tmp.text = $"{panelName}";

        SwicthPanel(panelIndex);

        curindex++;
    }

    public void SwicthPanel(int index)
    {        
        SwicthImgBtns[0].onClick.RemoveAllListeners();
        SwicthImgBtns[1].onClick.RemoveAllListeners();
        curpage = 1;
        if (curPanel != null && curPanel != TutorialPanels[index])
        {
            curPanel.gameObject.SetActive(false);
        }

        Initialize();

        curPanel = TutorialPanels[index];        
        curPanel.gameObject.SetActive(true);
        curPanel.SetPanel();      

        ChangePageTxt();

        SwicthImgBtns[0].onClick.AddListener(() => curPanel.SwicthPanel(true));
        SwicthImgBtns[1].onClick.AddListener(() => curPanel.SwicthPanel(false));
    }

    private void Initialize()
    {
        foreach (TutorialPanel obj in TutorialPanels)
        {
            if (obj != null)
            {
                obj.gameObject.SetActive(false);
            }
        }
    }

    public void SwicthPage(bool up)
    {
        if (up)
        {
            curpage++;
            ChangePageTxt();
            if (curpage == curPanel.Panels.Length)
            { ExitBtn.gameObject.SetActive(true); }
        }
        else
        {
            curpage--;
            ChangePageTxt();
        }
    }

    private void ChangePageTxt()
    {
        int PageLength = curPanel.Panels.Length;
        numberOfPages.text = $" {curpage} / {PageLength.ToString()}";       
    }
}
