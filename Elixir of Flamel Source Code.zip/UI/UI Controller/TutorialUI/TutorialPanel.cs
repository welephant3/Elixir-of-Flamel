using UnityEngine;
using UnityEngine.UI;

public class TutorialPanel : MonoBehaviour
{
    public TutorialUIManager manager;
    public Image[] Panels;
    public int curindex;

    private void Awake()
    {
        Panels = GetComponentsInChildren<Image>();

        ClearPanel();
    }

    public void SetPanel()
    {
        curindex = 0;
        Panels[curindex].gameObject.SetActive(true);
    }

    public void SwicthPanel(bool isLeft)
    {
        if(isLeft)
        {
            if (curindex == 0)
                return;

            Panels[curindex].gameObject.SetActive(false);
            curindex--;
            Panels[curindex].gameObject.SetActive(true);

            manager.SwicthPage(false);
        }
        else if(!isLeft)
        {
            if (curindex == Panels.Length -1)
                return;

            Panels[curindex].gameObject.SetActive(false);
            curindex++;
            Panels[curindex].gameObject.SetActive(true);

            manager.SwicthPage(true);
        }
    }

    private void OnDisable()
    {
        ClearPanel();
    }

    void ClearPanel()
    {
        for (int i = curindex; i < Panels.Length; i++)
        {
            Panels[i].gameObject.SetActive(false);
        }
    }
}
