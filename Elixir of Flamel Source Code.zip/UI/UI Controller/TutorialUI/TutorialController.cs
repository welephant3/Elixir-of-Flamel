using UnityEngine;
using UnityEngine.SceneManagement;

public enum eFunctionName
{ 
    MOVE,
    COMBINATION,
    RECIPE,
    INVENTORY,
    CULTIVATE,
    AIDSTATION,
    CRAFT,
    COLLECT,
    EVENT,
    DEFENSE,
    QUEST,
    REST,
}

public class TutorialController : Singleton<TutorialController>
{
    public GameObject TutorialPrefab;
    public GameObject TutorialInstance;

    private TutorialUIManager _tutorialUI;

    public bool IsMove;
    public bool IsCombination;
    public bool IsRecipe;
    public bool IsInventory;
    public bool IsCultivate;
    public bool IsAidStation;
    public bool IsCraft;
    public bool IsCollect;
    public bool IsEvent;
    public bool IsDefense;
    public bool IsQuest;
    public bool IsRest;

    private void OnEnable()
    {
        TutorialInstance = Instantiate(TutorialPrefab);
        DontDestroyOnLoad(TutorialInstance);
        TutorialInstance.SetActive(false);
        _tutorialUI = TutorialInstance.GetComponent<TutorialUIManager>();

        SceneManager.sceneLoaded += OnSceneLoad;
    }

    private void OnSceneLoad(Scene scene, LoadSceneMode mode)
    {
        if (scene.buildIndex == (int)eSceneName.LAB)
        {
            TutorialUIOn(ref IsMove, (int)eFunctionName.MOVE);
            SceneManager.sceneLoaded -= OnSceneLoad;
        }
    }

    public void TutorialUIOn(ref bool IsSomething, int tutorialIndex)
    {        
        if (IsSomething == false)
        {            
            IsSomething = true;
            TutorialInstance.SetActive(true);            
            _tutorialUI.Addtutorial(tutorialIndex);
        }
    }
}