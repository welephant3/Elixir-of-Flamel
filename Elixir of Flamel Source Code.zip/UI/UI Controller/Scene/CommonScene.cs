// Scene에 기본적으로 항상 존재하는 UI들의 부모
public class CommonScene : BaseUI
{
    private void Start()
    {
        UIController.Instance.ShowUI<CommonUI>(UIs.Scene);
        UIController.Instance.ShowUI<OptionUI>(UIs.Popup);
    }
}