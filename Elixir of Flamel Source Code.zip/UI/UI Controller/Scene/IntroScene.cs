public class IntroScene : BaseScene
{
    private void OnEnable()
    {
        UIController.Instance.ShowUI<StartUI>(UIs.Scene);
    }
}
