using UnityEngine.UI;

public class GatheringScene : BaseUI
{
    private void Start()
    {
        UIController.Instance.ShowUI<CommonUI>(UIs.Scene);
        CommonUI.FindObjectOfType<Button>().gameObject.SetActive(false);
    }        
}