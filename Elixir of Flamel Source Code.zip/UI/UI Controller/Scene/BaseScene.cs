using UnityEngine;

//기타 씬들은 이걸 상속받을 것!
public class BaseScene : MonoBehaviour
{  
}