public class TownScene : CommonScene
{

}
