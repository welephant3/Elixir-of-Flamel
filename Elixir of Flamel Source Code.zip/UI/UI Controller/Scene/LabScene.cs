public class LabScene : CommonScene
{
    private void Start()
    {
        UIController.Instance.ShowUI<AlchemyUI>(UIs.Popup);
        UIController.Instance.ShowUI<LabBtnUI>(UIs.Popup);
    }
}
