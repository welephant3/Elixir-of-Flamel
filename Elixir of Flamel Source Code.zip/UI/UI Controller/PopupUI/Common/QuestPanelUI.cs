using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;

public class QuestPanelUI : PopupUI
{
    public List<GameObject> Btns = new List<GameObject>();
    public GameObject questbtn;
    public Transform Content;

    public TextMeshProUGUI descriptionTxt;
    public TextMeshProUGUI ProgressTxt;
    public TextMeshProUGUI rewardTxt;

    private void OnEnable()
    {
        descriptionTxt.text = null;
        ProgressTxt.text = null;
        rewardTxt.text = null;
        SetQuestList();
    }

    public void UpdateUI(QuestDatas data)
    {
        if (data.isAcceptable)
        {
            descriptionTxt.text = data.beforeAcceptTxt;
            ProgressTxt.text = null;
            rewardTxt.text = null;
        }
        else if (data.isProgress || data.isSatisfy)
        {
            StringBuilder sb = new StringBuilder();
            descriptionTxt.text = data.descriptionTxt;
            for(int i =0; i < data.targetData.Length; i++)
            {
                sb.Append($"{data.targetData[i].targetData.displayName} : {data.targetData[i].targetCurCount} / {data.targetData[i].targetCount}\n");
            }
            ProgressTxt.text = sb.ToString();
            rewardTxt.text = data.rewardTxt;
        }
    }

    public void OnExitBtnClick()
    {
        UIController.Instance.HideUI<QuestPanelUI>();
        QuestManager.Instance._isPanelActive = false;
    }

    public void SetQuestList()
    {
        for (int i = 0; i < Btns.Count; i++)
        {
            Destroy(Btns[i]);
        }
        Btns.Clear();

        for (int i = 0; i < QuestManager.Instance.questList.data.Length; i++)
        {
            if (QuestManager.Instance.questList.data[i].isAcceptable == false && QuestManager.Instance.questList.data[i].isProgress == false && QuestManager.Instance.questList.data[i].isSatisfy == false)
                continue;

            GameObject obj = Instantiate(questbtn, Content);
            QuestBtn btn = obj.GetComponent<QuestBtn>();
            btn.SetData(QuestManager.Instance.questList.data[i]);
            Btns.Add(obj);
        }
    }
}
