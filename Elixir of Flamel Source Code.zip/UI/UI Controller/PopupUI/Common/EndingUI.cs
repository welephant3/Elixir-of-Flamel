using UnityEngine;
using UnityEngine.UI;

public class EndingUI : PopupUI
{
    public Image happyEndPanel;
    public GameObject[] happyEndTexts;
    public Image badEndPanel;
    public GameObject[] badEndTexts;

    private void OnEnable()
    {
        EndingManager.Instance.happyEndPanel = happyEndPanel;
        EndingManager.Instance.happyEndTexts = happyEndTexts;
        EndingManager.Instance.badEndPanel = badEndPanel;
        EndingManager.Instance.badEndTexts = badEndTexts;
    }
}
