using System.IO;
using TMPro;
using UnityEngine.UI;

public class MenuUI : PopupUI
{
    public Button[] menuSlotButtons;
    public Button menuDelButton;
    public Button menuLoadButton;
    public TextMeshProUGUI[] menuSaveText;
    public Button startBtn;

    private void Start()
    {
        foreach (var button in menuSlotButtons)
        {
            button.onClick.AddListener(() => SaveManager.Instance.SetCurrentSlot(int.Parse(button.name.Substring(button.name.Length - 1)) - 1));
        }
        menuDelButton.onClick.AddListener(() => DeleteSaveData(SaveManager.Instance.currentSlot));
        menuLoadButton.onClick.AddListener(() => SaveManager.Instance.LoadGame(SaveManager.Instance.currentSlot));
        for (int i = 0; i < SaveManager.Instance.saveData.Length; i++)
        {
            if (SaveManager.Instance.saveData[i] != null)
            {
                menuSaveText[i].text = "Save Slot" + (i + 1) + " " + SaveManager.Instance.saveData[i].day.ToString() + "일차 " + SaveManager.Instance.saveData[i].hour.ToString() + "시 " + ((int)SaveManager.Instance.saveData[i].min).ToString() + "분";
            }
        }
        startBtn.onClick.AddListener(() => SaveManager.Instance.StartGame());
    }

    public void DeleteSaveData(int slotIndex)
    {
        string filePath = SaveManager.Instance.saveFileName[slotIndex];
        if (File.Exists(filePath))
        {
            File.Delete(filePath);
            menuSaveText[slotIndex].text = "Save Slot" + (slotIndex + 1);
        }
    }

    public void GameExit()
    {
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #else
            //Application.Quit();
        #endif
    }
}
