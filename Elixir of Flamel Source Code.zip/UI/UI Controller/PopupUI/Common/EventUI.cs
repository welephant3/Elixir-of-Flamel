using UnityEngine.UI;

public class EventUI : PopupUI
{
    public Button leftChooseButton;
    public Button rightChooseButton;
    public EventDetail eventDetail;

    private void Awake()
    {
        UIController.Instance.ShowUI<EventRewardUI>(UIs.Popup);
        leftChooseButton.onClick.AddListener(() => EventUIManager.Instance.OnButtonClick(1));
        rightChooseButton.onClick.AddListener(() => EventUIManager.Instance.OnButtonClick(2));
        EventUIManager.Instance.eventDetail = eventDetail;
    }
}
