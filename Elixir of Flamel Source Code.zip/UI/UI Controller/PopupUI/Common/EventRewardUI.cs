public class EventRewardUI : PopupUI
{
    public EventReward eventReward;
    private void Start()
    {
        EventUIManager.Instance.eventReward = eventReward;
        if (this.gameObject.activeSelf)
        {
            UIController.Instance.HideUI<EventRewardUI>();
        }
    }
}
