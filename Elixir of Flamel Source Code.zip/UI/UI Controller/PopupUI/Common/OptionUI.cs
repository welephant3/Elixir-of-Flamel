using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class OptionUI : PopupUI
{
    public Slider backgroundMusicSlider;
    public Slider soundEffectSlider;
    public Slider masterAudioSlider;
    public TextMeshProUGUI[] saveSlotText;
    public Button saveBtn;
    public Button loadBtn;
    public Button[] slotButtons;
    public GameObject optionUI;

    public AudioManager audioManager;

    private void Start()
    {
        audioManager = AudioManager.Instance;

        backgroundMusicSlider.value = audioManager.GetBackgroundMusicVolume();
        soundEffectSlider.value = audioManager.GetSoundEffectVolume();
        masterAudioSlider.value = audioManager.GetMasterAudioVolume();

        backgroundMusicSlider.onValueChanged.AddListener(OnBackgroundMusicVolumeChanged);

        soundEffectSlider.onValueChanged.AddListener(OnSoundEffectVolumeChanged);

        masterAudioSlider.onValueChanged.AddListener(OnMasterAudioVolumeChanged);
        if(saveBtn != null && loadBtn != null && slotButtons != null)
        {
            saveBtn.onClick.AddListener(() => SaveGameBtn());
            loadBtn.onClick.AddListener(() => SaveManager.Instance.LoadGame(SaveManager.Instance.currentSlot));
            foreach (var button in slotButtons)
            {
                button.onClick.AddListener(() => SaveManager.Instance.SetCurrentSlot(int.Parse(button.name.Substring(button.name.Length - 1)) - 1));
            }
            if (SaveManager.Instance.saveData != null)
            {
                for (int i = 0; i < SaveManager.Instance.saveData.Length; i++)
                {
                    saveSlotText[i].text = "Save Slot" + (i + 1) + " " + SaveManager.Instance.saveData[i].day.ToString() + "일차 " + SaveManager.Instance.saveData[i].hour.ToString() + "시 " + ((int)SaveManager.Instance.saveData[i].min).ToString() + "분";
                }
            }
            optionUI.SetActive(false);
        }
        
    }

    private void OnMasterAudioVolumeChanged(float volume)
    {
        audioManager.SetMasterAudioVolume(volume);
    }
    private void OnBackgroundMusicVolumeChanged(float volume)
    {
        audioManager.SetBackgroundMusicVolume(volume);
    }
    private void OnSoundEffectVolumeChanged(float volume)
    {
        audioManager.SetSoundEffectVolume(volume);
    }

    public void SaveGameBtn()
    {
        SaveManager.Instance.SaveGame(SaveManager.Instance.currentSlot);
        saveSlotText[SaveManager.Instance.currentSlot].text = "Save Slot " + TimeSystem.Instance.day.ToString() + "일차 " + TimeSystem.Instance.hour.ToString() + "시 " + ((int)TimeSystem.Instance.min).ToString() + "분";
    }
    public void GameExit()
    {
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #else
            Application.Quit();
        #endif
    }
}
