using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SmithPanel : PopupUI
{
    // Todo 아이템 플레이어 스탯 적용 - 플레이어 스탯관련 먼저 제대로 정립

    [SerializeField] private EquipData[] equipdata;

    public Transform ItemPanel;
    public TextMeshProUGUI DescriptionPanel;
    public EquipData data;
    private Inventory inventory;
    public List<NPCPanelSlots> slots = new List<NPCPanelSlots>();
    public List<ItemSlot> inventoryslots = new List<ItemSlot>();
    public Button ProductionBtn;
    public int curindex = 0;

    private void Start()
    {
        inventory = PlayerManager.Instance.inventory;
        NPCPanelSlots obj;

        for(int index = 0; index< ItemPanel.childCount; index++)
        {
            Transform slot  = ItemPanel.GetChild(index);
            obj = slot.GetComponentInChildren<NPCPanelSlots>();
            slots.Add(obj);
            int localIndex = index;
            obj.btn.onClick.AddListener(() => OnClick(localIndex));
            if (NPCManager.Instance.townData.productLists[index].isMaked)
            {
                obj.image.sprite = null;
                obj.btn.interactable = false;
                obj.tmp.enabled = true;
            }
            else
            {
                obj.image.sprite = equipdata[localIndex].icon;
                obj.tmp.enabled = false;
            }
        }
    }

    private void OnEnable()
    {
        DescriptionPanel.text = null;
        ProductionBtn.interactable = false;

        //NPCManager.Instance.Product += Product;
    }

    void OnClick(int index)
    {
        data = equipdata[index];
        curindex = index;

        StringBuilder ResourceTxt = CaculateResource(data);

        DescriptionPanel.text = $"{data.displayName}\n{data.description}\n{data.equipStats[0].type}:{data.equipStats[0].value}\n {ResourceTxt}";
    }

    //public void OnProduction()
    //{
    //    NPCManager.Instance.Product?.Invoke(data, 1);
    //}

    public void Product()
    {
        PlayerManager.Instance.itemData = data;
        PlayerManager.Instance.addItem?.Invoke();

        if(PlayerManager.Instance.isPickuped == true) //아이템 제작이 성공했다면
        {
            for (int i = 0; i < data.recipe.Length; i++)
            {
                inventory.selectedSlot = inventoryslots[i];
                inventory.RemoveSelectedItem(data.recipe[i].value);
            }

            slots[curindex].image.sprite = null;
            slots[curindex].btn.interactable = false;
            slots[curindex].tmp.enabled = true;
            NPCManager.Instance.townData.productLists[curindex].isMaked = true;
            DescriptionPanel.text = null;
            NPCManager.Instance.Product?.Invoke(data, 1);
        }
        else
        {
            DescriptionPanel.text = "인벤토리에 빈 공간이 없습니다";
            return;
        }
    }

    StringBuilder CaculateResource(EquipData data)
    {
        ProductionBtn.interactable = true;
        inventoryslots.Clear();
        StringBuilder resource = new StringBuilder();

        for (int i = 0; i < data.recipe.Length; i++)
        {
            bool itemFound = false;
            for (int j = 0; j < inventory.slots.Length; j++)
            {
                if (inventory.slots[j].item != null && inventory.slots[j].item.itemId == data.recipe[i].itemId)
                {
                    inventoryslots.Add(inventory.slots[j]);
                    itemFound = true;

                    string color = "";
                    switch (inventory.slots[j].quantity.CompareTo(data.recipe[i].value)) //인벤토리의 아이템과 요구치를 비교
                    {
                        case 1: //인벤토리의 아이템이 많을 경우
                            color = "blue";
                            break;
                        case 0: // 같을 경우
                            color = "green";
                            break;
                        case -1: // 모자를 경우
                            color = "red";
                            ProductionBtn.interactable = false;
                            break;
                    }
                    resource.Append($"<color={color}>{inventory.slots[j].item.displayName} : {inventory.slots[j].quantity} / {data.recipe[i].value}</color>\n");
                    break;
                }
            }

            if (!itemFound) // 레시피에 필요한 아이템이 인벤토리에 없는 경우
            {
                ProductionBtn.interactable = false;
                resource.Append($"<color=red>{data.recipe[i].data.displayName} : 0 / {data.recipe[i].value}</color>\n");
            }
        }
        return resource;
    }

    public void OnExitBtnClick()
    {
        UIController.Instance.HideUI<SmithPanel>();
    }

    private void OnDisable()
    {
        //NPCManager.Instance.Product -= Product;
    }
}
