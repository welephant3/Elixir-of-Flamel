using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ReliefPanel : PopupUI
{
    //Todo 사과 요구치를 날짜별로 증가시키는 것에서 난민수만큼 증가시키는 형식으로 변경
    //Todo 당일날 아이템 지원을 하지 못하였을 경우 다음 날 패널티 도입 (주민이 떠난다던지- 자원감소)
    public Inventory inventory;
    [SerializeField] private ItemData itemData; //Todo 추후 요구아이템을 늘리거나 랜덤하게 변경할 수 있는 로직도 생성 가능
    public Button ReliefBtn;
    public TextMeshProUGUI RequireTxt;
    public Slider ReliefSlider;
    public TextMeshProUGUI curReliefAmount;

    public ResourceData resourcedata;

    private int RequiredValue;
    int curReliefAmountValue;

    bool itemFound = false;

    
    private void OnEnable()
    {
        inventory = PlayerManager.Instance.inventory;
        ReliefSlider.gameObject.SetActive(true);
        curReliefAmount.gameObject.SetActive(true);
        ReliefBtn.interactable = true;
        curReliefAmountValue = 1;
        if (NPCManager.Instance.PlzchangeReliefPanel)
        {
            UpdateReliefData();
            NPCManager.Instance.PlzchangeReliefPanel = false;
        }
        if (NPCManager.Instance.townData.isReliefed)
        {
            iscleared();
        }
        else
        {
            RequiredValue = Mathf.RoundToInt((float)resourcedata.totalResources * 0.1f) + NPCManager.Instance.townData.curDays;
            SetMaxValue();

            if(!itemFound)
            {
                RequireTxt.text = "자네는 사과를 가지고 있지 않군";
                ReliefSlider.gameObject.SetActive(false);
                curReliefAmount.gameObject.SetActive(false);
                ReliefBtn.interactable = false;
            }
            else
            {
                RequireTxt.text = $"사과가 {RequiredValue}개 만큼 필요하다네";
            }
        }
    }

    public void OnExitBtn()
    {
        UIController.Instance.HideUI<ReliefPanel>();
    }

    // 초과지원/미달지원 로직, ScrollBar로 세팅함
    public void OnReliefBtn()
    {
        inventory.RemoveSelectedItem(curReliefAmountValue);
        if(curReliefAmountValue < RequiredValue)
        {
            NPCManager.Instance.townData.isNotEnough = true;
        }
        else if(curReliefAmountValue > RequiredValue)
        {
            NPCManager.Instance.Relief?.Invoke(itemData, 1);
        }
        iscleared();
    }

    private void iscleared()
    {
        RequireTxt.text = "고맙네";
        ReliefBtn.interactable = false;
        NPCManager.Instance.townData.isReliefed = true;
        ReliefSlider.gameObject.SetActive(false);
        curReliefAmount.gameObject.SetActive(false);
    }

    void UpdateReliefData()
    {
        if (NPCManager.Instance.townData.isNotEnough == true || NPCManager.Instance.townData.isReliefed == false)
        {
            NPCManager.Instance.ReductionResource = Mathf.RoundToInt((float)resourcedata.totalResources * 0.1f);
            resourcedata.totalResources = resourcedata.totalResources - NPCManager.Instance.ReductionResource;
            //인구수의 10% 증발

            UIController.Instance.ShowUI<InsufficientPanel>(UIs.Popup);
            NPCManager.Instance.townData.isNotEnough = false;
        }
        NPCManager.Instance.townData.isReliefed = false;
    }

    public void OnSliderValueChanged(float value)
    {
        int curvalue = (int)ReliefSlider.value;
        curReliefAmount.text = curvalue.ToString();
        curReliefAmountValue = curvalue;
    }

    void SetMaxValue()
    {
        foreach (var slot in inventory.slots)
        {
            if (slot.item == itemData)
            {
                inventory.selectedSlot = slot;

                ReliefSlider.maxValue = slot.quantity;

                itemFound = true; //아이템을 찾았다면 실행하고 true로 변경 및 루프 중단
                break;
            }
        }
    }
}
