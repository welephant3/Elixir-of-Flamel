using TMPro;
using UnityEngine.UI;

public class OnInteractNPCUI : SceneUI
{
    private NPCData data;

    public Image NPCImg;
    public TextMeshProUGUI promptName;
    public TextMeshProUGUI promptTxt;
    public TextMeshProUGUI promptBtnTxt;

    private void OnEnable()
    {
        GameManager.Instance.DisconnectMoveEvent();
        data = NPCManager.Instance.data;
        promptName.text = data.name;
        promptTxt.text = data.ScriptTxt[UnityEngine.Random.Range(0, data.ScriptTxt.Length)];
        promptBtnTxt.text = data.btntxt;
        NPCImg.sprite = data.NPCImg;
    }

    public void OnEnterBtnClick()
    {
        switch (data.id)
        {
            case 0:
                UIController.Instance.ShowUI<SmithPanel>(UIs.Popup);
                TutorialController.Instance.TutorialUIOn(ref TutorialController.Instance.IsCraft, (int)eFunctionName.CRAFT);
                break;
            case 1:
                UIController.Instance.ShowUI<ReliefPanel>(UIs.Popup);
                TutorialController.Instance.TutorialUIOn(ref TutorialController.Instance.IsAidStation, (int)eFunctionName.AIDSTATION);
                break;
            case 2:
                UIController.Instance.ShowUI<GrowPanel>(UIs.Popup);
                TutorialController.Instance.TutorialUIOn(ref TutorialController.Instance.IsCultivate, (int)eFunctionName.CULTIVATE);
                break;
        }
    }

    public void OnQeustBtnClick()
    {
        UIController.Instance.ShowUI<AcceptableQuestUI>(UIs.Popup);
    }

    public void OnExitBtnClick()
    {
        UIController.Instance.HideUI<OnInteractNPCUI>();
    }

    public void OnDisable()
    {
        GameManager.Instance.ConnectMoveEvent();
    }
}