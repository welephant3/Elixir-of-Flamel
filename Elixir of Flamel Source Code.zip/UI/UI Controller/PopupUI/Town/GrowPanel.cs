using System;
using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class GrowPanel : PopupUI
{    
    public Transform ResourceSlots;
    public Transform GrowSlots;
    public Button growbtn;
    private Inventory inventory;
    private List<int> slotnum = new List<int>();

    public List<ItemData> Resourcedata = new List<ItemData>(); // 재료 슬롯의 아이템 데이터
    public List<ItemData> GrowData;
    public List<NPCPanelSlots> RSlot = new List<NPCPanelSlots>(); // 재료 슬롯의 아이템 이미지 슬롯
    public List<NPCPanelSlots> GSlot = new List<NPCPanelSlots>(); // 재배 슬롯의 아이템 이미지 슬롯, 추후 날짜 혹은 난민수에 따른 슬롯 개방 로직

    public GameObject rslot;
    public List<GameObject> rslots = new List<GameObject>();

    public GameObject resultPanel;
    public TextMeshProUGUI resultTxt;

    private bool isupdated = false;

    int gSuccessPer = 20;
    int successPer = 50;
    int failPer = 30;

    int successAmount = 3;
    int gSuccessAmount = 5;

    private void OnEnable()
    {
        if (isupdated)
        {
            SetSlot();
        }
    }

    private void Start()
    {
        isupdated = true;
        GrowData = NPCManager.Instance.townData.GrowData;
        inventory = PlayerManager.Instance.inventory;
        NPCPanelSlots obj;

        if (QuestManager.Instance.questList.data[2].isSucess)
        {
            gSuccessPer += 5;
            successPer += 5;
            failPer -= 10;
        }
        if (QuestManager.Instance.questList.data[5].isSucess)
        {
            successAmount += 2;
            gSuccessAmount += 2;
        }
        //for (int index = 0; index < ResourceSlots.childCount; index++)
        //{
        //    Transform slot = ResourceSlots.GetChild(index);
        //    obj = slot.GetComponentInChildren<NPCPanelSlots>();
        //    int localIndex = index;
        //    RSlot.Add(obj);
        //    obj.btn.onClick.AddListener(() => OnBtnClick(localIndex, true));
        //}


        for (int index = 0; index < GrowSlots.childCount; index++)
        {
            Transform slot = GrowSlots.GetChild(index);
            obj = slot.GetComponentInChildren<NPCPanelSlots>();
            int localIndex = index;
            GSlot.Add(obj);
            obj.btn.interactable = true;
            obj.btn.onClick.AddListener(() => OnBtnClick(localIndex, false));
        }

        growbtn.onClick.AddListener(() => OnGrowClick());

        SetSlot();

        if (NPCManager.Instance.PlzchangeGrowPanel)
        {
            UpdateGrowData();
            NPCManager.Instance.PlzchangeGrowPanel = false;
        }
    }

    void SetSlot()
    {
        int curindex = 0;
        ResetResource();

        for (int i = 0; i < inventory.slots.Length; i++)
        {
            if (inventory.slots[i].item != null && (int)inventory.slots[i].item.itemType == 0)
            {
                GameObject obj = Instantiate(rslot, ResourceSlots);
                NPCPanelSlots panelslot = obj.GetComponent<NPCPanelSlots>();
                int Localindex = curindex;
                panelslot.btn.onClick.AddListener(() => OnBtnClick(Localindex, true));
                RSlot.Add(panelslot);
                rslots.Add(obj);
                if (NPCManager.Instance.townData.isGrowed == true)
                {
                    RSlot[curindex].btn.interactable = false;
                }
                else
                {
                    RSlot[curindex].btn.interactable = true;
                }
                Resourcedata.Add(inventory.slots[i].item);
                RSlot[curindex].image.sprite = Resourcedata[curindex].icon;
                RSlot[curindex].tmp.text = inventory.slots[i].quantity.ToString();
                slotnum.Add(i);
                curindex++;
            }
        }
        for (int i = curindex; i < RSlot.Count; i++)
        {
            RSlot[i].image.sprite = null;
            RSlot[i].btn.interactable = false;
            RSlot[i].tmp.text = "0";
        }

        curindex = 0;
        if (GrowData.Count > 0)
        {
            for (int i = 0; i < GrowData.Count; i++)
            {
                GSlot[i].image.sprite = GrowData[i].icon;
                if (NPCManager.Instance.townData.isGrowed)
                {
                    GSlot[i].btn.interactable = false;
                    GSlot[i].tmp.fontSize = 36;
                    GSlot[i].tmp.text = "재배중........";
                    growbtn.interactable = false;
                }
                else
                {
                    GSlot[i].tmp.fontSize = 20;
                    GSlot[i].tmp.text = $"{GrowData[i].displayName}\n대성공 확률 : {gSuccessPer}%\n성공 확률 : {successPer}%\n실패 확률: {failPer}%";
                }
                curindex++;
            }
        }
        for (int i = curindex; i < GSlot.Count; i++)
        {
            if(NPCManager.Instance.townData.isGrowed)
            {
                GSlot[i].btn.interactable = false;
            }
            GSlot[i].image.sprite = null;
            GSlot[i].tmp.text = null;
        }
    }

    private void ResetResource()
    {
        Resourcedata.Clear();
        slotnum.Clear();
        RSlot.Clear();
        for (int i = 0; i < rslots.Count;i++)
        {
            Destroy(rslots[i]);
        }
        for (int i = 0; i < GSlot.Count; i++)
        {
            GSlot[i].btn.interactable = true;
        }
        rslots.Clear();
        growbtn.interactable = true;

    }

    void OnBtnClick(int index, bool isResourcebtn)
    {
        if (NPCManager.Instance.townData.isGrowed == true)
        {
            return;
        }
        if (isResourcebtn)
        {
            bool isSatck = false;
            for (int i = 0; i < GSlot.Count; i++) //빈 슬롯을 찾아 이미지 스프라이트를 등록하고 데이터를 리스트에 저장
            {
                if (GSlot[i].image.sprite == null)
                {
                    GSlot[i].image.sprite = RSlot[index].image.sprite;
                    GrowData.Add(Resourcedata[index]);
                    isSatck = true;
                    break;
                }
            }

            if(isSatck)
            {
                inventory.selectedSlot = inventory.slots[slotnum[index]];
                inventory.RemoveSelectedItem(1);
            }
        }
        else
        {
            if (GSlot[index].image.sprite == null)
            {
                return;
            }
            PlayerManager.Instance.itemData = GrowData[index];
            inventory.AddItem();

            GSlot[index].image.sprite = null;
            GrowData.RemoveAt(index);
        }

        SetSlot();
    }

    public void OnGrowClick()
    {
        if (GrowData.Count == 0)
        {
            return;
        }
        for (int i = 0;i < GSlot.Count;i++)
        {
            if (GSlot[i].image.sprite != null)
            {
                GSlot[i].btn.interactable = false;
                GSlot[i].tmp.fontSize = 36;
                GSlot[i].tmp.text = "재배중........";
                NPCManager.Instance.Gress[i].SetActive(true);
                NPCManager.Instance.townData.isGrowed = true;                
                NPCManager.Instance.Grow?.Invoke(GrowData[i], 1);
            }
            else
            {
                GSlot[i].btn.interactable = false;
            }
        }
        for (int i = 0; i < RSlot.Count; i++)
        {
            RSlot[i].btn.interactable = false;
        }

        growbtn.interactable = false;
    }
    
    void UpdateGrowData()
    {
        StringBuilder GrowTxt = new StringBuilder();
        for(int i = 0; i < GrowData.Count; i++ )
        {
            int Randomacquire = UnityEngine.Random.Range(1, 100);
            int numberofherb = 0;
            if (Randomacquire < failPer+1)
            {
                GrowTxt.Append($"{GrowData[i].displayName}재배 실패!\n획득 수량 : {numberofherb}\n");
            }
            else if (Randomacquire > failPer && Randomacquire < failPer+successPer+1)
            {
                numberofherb = successAmount;
                GrowTxt.Append($"{GrowData[i].displayName}재배 성공!\n획득 수량 : {numberofherb}\n");
            }
            else
            {
                numberofherb = gSuccessAmount;
                GrowTxt.Append($"{GrowData[i].displayName}재배 대성공!\n획득 수량 : {numberofherb}\n");
            }

            if(Randomacquire != 0)
            {
                for (int j = 0; j < numberofherb; j++)
                {
                    PlayerManager.Instance.itemData = GrowData[i];
                    inventory.AddItem();
                }
            }
            NPCManager.Instance.Gress[i].SetActive(false);
        }

        resultTxt.text = GrowTxt.ToString();
        resultPanel.SetActive(true);

        GrowData.Clear();
        NPCManager.Instance.townData.isGrowed = false;
        SetSlot();
    }

    void AddItem(int i)
    {
        PlayerManager.Instance.itemData = GrowData[i];
        inventory.AddItem();
    }

    public void OnExitBtn()
    {
        UIController.Instance.HideUI<GrowPanel>();
    }

    public void OnResultPanelExit()
    {
        resultPanel.SetActive(false);
    }
}
