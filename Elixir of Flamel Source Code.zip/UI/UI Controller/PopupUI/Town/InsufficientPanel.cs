using TMPro;

public class InsufficientPanel : PopupUI
{
    public TextMeshProUGUI DescriptionPanel;

    private void OnEnable()
    {
        DescriptionPanel.text = $"식량의 지원이 충분하지 않아 마을 사람이 떠났습니다\n떠난 난민 수 : {NPCManager.Instance.ReductionResource}";

        NPCManager.Instance.ReductionResource = 0;
    }
    public void OnExitBtnClick()
    {
        UIController.Instance.HideUI<InsufficientPanel>();
    }
}
