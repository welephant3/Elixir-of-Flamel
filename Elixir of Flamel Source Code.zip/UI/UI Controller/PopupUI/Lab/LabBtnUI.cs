using UnityEngine.UI;

public class LabBtnUI : PopupUI
{
    public Button CraftBtn;
    public Button RecipeBtn;

    private void Start()
    {
        CraftBtn.onClick.AddListener(() => CraftUIShow());
        RecipeBtn.onClick.AddListener(() => RecipeUIShow());
    }

    public void CraftUIShow()
    {
        UIController.Instance.ShowUI<RecipeUI>(UIs.Popup);
        for (int i = 0; i < RecipeManager.Instance.recipePage.recipePages.Length; i++)
        {
            RecipeManager.Instance.recipePage.recipePages[i].gameObject.SetActive(false);
        }
        RecipeManager.Instance.recipePage.recipePages[0].gameObject.SetActive(true);
        UIController.Instance.HideUI<RecipeUI>();
        UIController.Instance.ShowUI<AlchemyUI>(UIs.Popup);
    }
    public void RecipeUIShow()
    {
        UIController.Instance.ShowUI<RecipeUI>(UIs.Popup);
        for (int i = 0; i < RecipeManager.Instance.recipePage.recipePages.Length; i++)
        {
            RecipeManager.Instance.recipePage.recipePages[i].gameObject.SetActive(false);
        }
        RecipeManager.Instance.recipePage.recipePages[0].gameObject.SetActive(true);
        GameManager.Instance.DisconnectMoveEvent();
        TutorialController.Instance.TutorialUIOn(ref TutorialController.Instance.IsRecipe, (int)eFunctionName.RECIPE);
    }
}
