using UnityEngine.UI;

public class RestUI : PopupUI
{
    public Button yesBtn;
    public Button noBtn;

    private void Start()
    {
        yesBtn.onClick.AddListener(() => YesBtn());
        noBtn.onClick.AddListener(() => NoBtn());
    }

    private void OnEnable()
    {
        GameManager.Instance.DisconnectMoveEvent();
        TutorialController.Instance.TutorialUIOn(ref TutorialController.Instance.IsRest, (int)eFunctionName.REST);
    }
        public void YesBtn()
    {
        TimeSystem.Instance.hour = 17;
        TimeSystem.Instance.min = 59;
        UIController.Instance.HideUI<RestUI>();
        ResourcesManager.Instance.ClearDic();
    }

    public void NoBtn()
    {
        UIController.Instance.HideUI<RestUI>();
        ResourcesManager.Instance.ClearDic();
        PlayerManager.Instance.interaction.isPortal = false;
    }

    public void OnDisable()
    {
        GameManager.Instance.ConnectMoveEvent();
    }
}
