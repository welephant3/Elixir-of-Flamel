using TMPro;
using UnityEngine.UI;

public class AlchemyUI : PopupUI
{
    public Button craftBtn;
    public CraftingItemSlot[] craftingSlots;
    public ItemSlot[] materialSlot;
    public CraftingItemSlot resultSlot;
    public TextMeshProUGUI successOrFailText;
    public Button closeBtn;

    private void Awake()
    {
        craftBtn.onClick.AddListener(() => CraftingManager.Instance.OnCraftItemAddBtn());
        closeBtn.onClick.AddListener(() => CloseBtn());
        CraftingManager.Instance.craftingSlots = craftingSlots;
        CraftingManager.Instance.materialSlot = materialSlot;
        CraftingManager.Instance.resultSlot = resultSlot;
        CraftingManager.Instance.successOrFailText = successOrFailText;
        for (int i = 0; i < materialSlot.Length; i++)
        {
            materialSlot[i].inventory = CraftingManager.Instance.inventory;
            materialSlot[i].slotIndex = i;
        }
        CraftingManager.Instance.CheckMaterialSlot();
    }
    private void OnEnable()
    {
        CraftingManager.Instance.CheckMaterialSlot();
        GameManager.Instance.DisconnectMoveEvent();
        TutorialController.Instance.TutorialUIOn(ref TutorialController.Instance.IsCombination, (int)eFunctionName.COMBINATION);
    }
    public void CloseBtn()
    {
        UIController.Instance.HideUI<AlchemyUI>();
    }
    public void OnClickItem(ItemSlot slot)
    {
        CraftingManager.Instance.OnMouseDownItem(slot);
    }

    public void OnClickSlotItme(CraftingItemSlot slot)
    {
        CraftingManager.Instance.OnClickSlot(slot);
    }

    public void OnDisable()
    {
        GameManager.Instance.ConnectMoveEvent();
    }
}
