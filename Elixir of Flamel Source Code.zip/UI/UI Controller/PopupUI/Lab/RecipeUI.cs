using UnityEngine.UI;

public class RecipeUI : PopupUI
{
    public RecipeImage[] recipes;
    public Button nextBtn;
    public Button prevBtn;
    public RecipePage recipePage;
    public Button closeBtn;

    private void Start()
    {
        nextBtn.onClick.AddListener(() => recipePage.OnNextBtn());
        prevBtn.onClick.AddListener(() => recipePage.OnPreviousBtn());
    }
    private void OnEnable()
    {
        if (RecipeManager.Instance.recipeUI == null)
        {
            RecipeManager.Instance.recipeUI = this;
            RecipeManager.Instance.recipes = recipes;
            RecipeManager.Instance.recipePage.recipePages = recipePage.recipePages;
            for (int i = 0; i < recipes.Length; i++)
            {
                recipes[i].isItemObtained = RecipeManager.Instance.saveData[i];
            }
        }
    }
    private void OnDisable()
    {
        for (int i = 0; i < RecipeManager.Instance.saveData.Length; i++)
        {
            RecipeManager.Instance.saveData[i] = recipes[i].isItemObtained;
        }
    }

    public void CloseBtn()
    {
        UIController.Instance.HideUI<RecipeUI>();
    }
    public void ClosePanel()
    {
        GameManager.Instance.ConnectMoveEvent();
    }
}