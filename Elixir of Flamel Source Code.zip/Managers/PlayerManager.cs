using System;
using TMPro;
using UnityEngine;

public class PlayerManager : Singleton<PlayerManager>
{
    public Interaction interaction;
    public Action addItem;
    public event Action OpenInventory;
    public event Action<EquipData> equip;
    public event Action<EquipData> unequip;   

    public ItemData itemData;
    public GameObject PlayerPrefab;
    public GameObject PlayerInstanceOrigin;
    public GameObject PlayerInstance;
    public GameObject uiPrefab;
    public GameObject uiInstance;
    public Inventory inventory;
    public GameObject promptPanel;
    public TextMeshProUGUI promptText;
    public Transform PlayerPosition { get; private set; }  //EnemyController 거리 방향 확인용도

    public bool isPickuped = false;

    protected override void Awake()
    {
        base.Awake();
    }

    private void OnEnable()
    {
        PlayerInstanceOrigin = Instantiate(PlayerPrefab);
        PlayerInstance = PlayerInstanceOrigin.GetComponentInChildren<PlayerInputController>().gameObject;//수정됨
        uiInstance = Instantiate(uiPrefab);
        DontDestroyOnLoad(PlayerInstanceOrigin);
        DontDestroyOnLoad(uiInstance); // UI 인스턴스도 파괴되지 않도록 설정               

        promptPanel = uiInstance.transform.Find("DescriptionPanel").gameObject;
        promptText = promptPanel.GetComponentInChildren<TextMeshProUGUI>();

        interaction = PlayerInstance.GetComponent<Interaction>();
        inventory = uiInstance.GetComponentInChildren<Inventory>();
        promptPanel.gameObject.SetActive(false);
    }

    public void Equip(EquipData equipData)
    {
        equip?.Invoke(equipData);
    }

    public void UnEquip(EquipData equipData)
    {
        unequip?.Invoke(equipData);
    }
}