using UnityEngine;

public class GridManager : MonoBehaviour
{
    public int width, height;           // 그리드의 너비와 높이
    public float cellSize;              // 각 셀의 크기
    public GameObject gridCellPrefab;   // 그리드 셀의 프리팹
    public GameObject[,] grid;          // 그리드 셀을 저장할 2차원 배열
    private Color[,] originalColors;    // 각 셀의 원래 색상을 저장할 2차원 배열
    public float offsetX, offsetY;      // 그리드의 전체 위치를 조정하기 위한 오프셋

    void Start()
    {
        CreateGrid();                 // 그리드 생성
        ToggleGrid(false);            // 시작 시 그리드를 숨김
    }

    // 그리드를 생성하는 메서드
    void CreateGrid()
    {
        grid = new GameObject[width, height];  // 그리드 배열 초기화
        originalColors = new Color[width, height];  // 원래 색상 배열 초기화

        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                Vector3 position = CalculateCellPosition(x, y);  // 셀의 위치 계산
                GameObject cell = Instantiate(gridCellPrefab, position, Quaternion.identity);  // 셀 프리팹 생성
                cell.transform.parent = transform;  // GridManager의 자식으로 설정
                grid[x, y] = cell;  // 그리드에 셀 저장

                // 셀의 원래 색상 저장
                originalColors[x, y] = cell.GetComponent<SpriteRenderer>().color;
            }
        }
    }

    // 주어진 그리드 인덱스에 따라 셀의 위치를 계산하는 메서드
    Vector3 CalculateCellPosition(int x, int y)
    {
        return new Vector3(
            x * cellSize + cellSize / 2 + offsetX,
            y * cellSize + cellSize / 2 + offsetY,
            0
        );
    }

    // 주어진 위치에서 가장 가까운 그리드 셀의 중심점을 반환하는 메서드
    public Vector3 GetNearestPointOnGrid(Vector2 position)
    {
        (int x, int y) = GetClampedGridIndex(position);  // 그리드 인덱스 계산 및 클램핑

        // 셀의 가운데 위치 반환
        return grid[x, y].transform.position;
    }

    // 주어진 위치에서 그리드 인덱스를 계산하는 메서드
    (int, int) GetGridIndex(Vector2 position)
    {
        int x = Mathf.RoundToInt((position.x - offsetX - cellSize / 2) / cellSize);
        int y = Mathf.RoundToInt((position.y - offsetY - cellSize / 2) / cellSize);
        return (x, y);
    }

    // 주어진 위치가 그리드 내부에 있는지 확인하는 메서드
    public bool IsPositionInsideGrid(Vector2 position)
    {
        return position.x >= offsetX && position.x < offsetX + width * cellSize &&
               position.y >= offsetY && position.y < offsetY + height * cellSize;
    }

    // 그리드의 모든 셀의 활성화 여부를 설정하는 메서드
    public void ToggleGrid(bool isActive)
    {
        foreach (GameObject cell in grid)
        {
            cell.SetActive(isActive);  // 셀 활성화 상태 설정
        }
    }

    // 주어진 위치의 셀을 하이라이트하는 메서드
    public void HighlightCell(Vector2 position, Color color)
    {
        (int x, int y) = GetClampedGridIndex(position);  // 그리드 인덱스 계산 및 클램핑
        grid[x, y].GetComponent<SpriteRenderer>().color = color;  // 셀 색상 변경
    }

    // 주어진 위치의 셀의 하이라이트를 제거하는 메서드
    public void ClearHighlight(Vector2 position)
    {
        (int x, int y) = GetClampedGridIndex(position);  // 그리드 인덱스 계산 및 클램핑
        grid[x, y].GetComponent<SpriteRenderer>().color = originalColors[x, y];  // 원래 색상으로 복원
    }

    // 주어진 위치에서 그리드 인덱스를 계산하고 범위를 제한하는 메서드
    (int, int) GetClampedGridIndex(Vector2 position)
    {
        (int x, int y) = GetGridIndex(position);
        x = Mathf.Clamp(x, 0, width - 1);
        y = Mathf.Clamp(y, 0, height - 1);
        return (x, y);
    }
}
