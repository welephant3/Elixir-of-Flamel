using UnityEngine;
using System.Collections;
using System.IO;

public class DefenseManager : MonoBehaviour
{
    private WallManager wallManager;
    private TowerManager towerManager;
    private DefenseResourceManager resourceManager;
    private PlacementManager placementManager;
    private NavMeshManager navMeshManager;
    private DefenseUIManager defenseUIManager;
    private DefenseEnemyManager defenseEnemyManager;

    public DefenseData defenseData;
    private string saveFilePath;

    void Start()
    {
        PlayerManager.Instance.interaction.isPortal = false;
        wallManager = FindObjectOfType<WallManager>();
        towerManager = FindObjectOfType<TowerManager>();
        resourceManager = FindObjectOfType<DefenseResourceManager>();
        placementManager = FindObjectOfType<PlacementManager>();
        navMeshManager = FindObjectOfType<NavMeshManager>();
        defenseUIManager = FindObjectOfType<DefenseUIManager>();
        defenseEnemyManager = FindObjectOfType<DefenseEnemyManager>();

        // 저장 파일 경로 설정
        saveFilePath = Path.Combine(Application.persistentDataPath, "defenseData.json");

        // `TimeSystem`에서 1일차인지 확인하여 게임을 초기화
        if (TimeSystem.Instance.day == 1)
        {
            ResetGameData();
        }
        else
        {
            LoadDefenseData();
        }

        Time.timeScale = 0;
        defenseUIManager?.ShowStartButton();
    }

    private void ResetGameData()
    {
        // 모든 데이터를 초기화
        defenseData.walls.Clear();
        defenseData.towers.Clear();
        defenseData.maxEnemies = defenseData.baseMaxEnemies;

        SaveDefenseData();  // 초기화된 데이터를 저장
    }

    public void OnStartButtonClicked()
    {
        // 스타트 버튼을 눌렀을 때 데이터를 저장합니다.
        SaveDefenseData();

        StartCoroutine(BuildNavMeshAndStartGame());
        placementManager.DisableAllModes();
        GridManager gridManager = FindObjectOfType<GridManager>();
        gridManager?.ToggleGrid(false);
    }

    IEnumerator BuildNavMeshAndStartGame()
    {
        yield return navMeshManager.Surface2D.BuildNavMeshAsync();

        Time.timeScale = 1;
        DefenseEnemyManager enemyManager = FindObjectOfType<DefenseEnemyManager>();
        enemyManager?.StartEnemies();

        defenseUIManager?.HideButton();
    }

    public void SaveDefenseData()
    {
        defenseData.walls.Clear();
        defenseData.towers.Clear();

        Wall[] walls = FindObjectsOfType<Wall>();
        foreach (Wall wall in walls)
        {
            WallPositionData wallData = new WallPositionData
            {
                position = wall.transform.position
            };
            defenseData.walls.Add(wallData);
        }

        Tower[] towers = FindObjectsOfType<Tower>();
        foreach (Tower tower in towers)
        {
            TowerPositionData towerData = new TowerPositionData
            {
                position = tower.transform.position,
                upgradeLevel = tower.GetUpgradeLevel(),
                towerType = tower.GetTowerType(),
            };
            defenseData.towers.Add(towerData);
        }

        //ResourceData를 defenseData에 저장
        defenseData.resourceData.totalResources = resourceManager.resourceData.totalResources;
        defenseData.resourceData.usedResources = resourceManager.resourceData.usedResources;

        // JSON으로 저장
        string jsonData = JsonUtility.ToJson(defenseData, true);
        File.WriteAllText(saveFilePath, jsonData);

        navMeshManager.BuildNavMesh();
    }

    public void LoadDefenseData()
    {
        if (File.Exists(saveFilePath))
        {
            // JSON 파일로부터 데이터를 로드
            string jsonData = File.ReadAllText(saveFilePath);
            JsonUtility.FromJsonOverwrite(jsonData, defenseData);

            resourceManager.LoadResources(resourceManager.resourceData.totalResources, resourceManager.resourceData.usedResources);

            foreach (WallPositionData wallData in defenseData.walls)
            {
                wallManager.LoadWall(wallData.position);
            }

            foreach (TowerPositionData towerData in defenseData.towers)
            {
                GameObject loadedTower = towerManager.LoadTower(towerData.position, towerData.towerType, towerData.upgradeLevel);
                Tower towerComponent = loadedTower?.GetComponent<Tower>();
                if (towerComponent != null)
                {
                    towerComponent.SetUpgradeLevel(towerData.upgradeLevel);
                    towerComponent.SetTowerType(towerData.towerType);

                    Animator animator = towerComponent.GetComponent<Animator>();
                }
            }

            // defenseEnemyManager에서 maxEnemies 값을 로드
            defenseEnemyManager.defenseData.maxEnemies = defenseData.maxEnemies;

            navMeshManager.BuildNavMesh();
        }
    }
}
