using NavMeshPlus.Components;
using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class NavMeshManager : MonoBehaviour
{
    public NavMeshSurface navMeshSurface; // 2D NavMesh
    public NavMeshSurface Surface2D; // 3D NavMesh

    // NavMesh를 빌드하는 메서드
    public void BuildNavMesh()
    {
        BuildSurfaceNavMesh(navMeshSurface);
        BuildSurfaceNavMesh(Surface2D);
    }

    // 주어진 NavMeshSurface를 빌드
    private void BuildSurfaceNavMesh(NavMeshSurface surface)
    {
        if (surface != null)
        {
            surface.BuildNavMesh();
        }
    }

    // 벽 배치 후 경로 유효성 확인
    public bool IsPathAvailableAfterWallPlacement(Vector2 position, Transform startPoint, Transform endPoint)
    {
        GameObject tempWall = CreateTempWall(position); // 임시 벽 생성
        bool pathExists = CheckPathAvailability(startPoint, endPoint); // 경로 유효성 검사

        Destroy(tempWall); // 임시 벽 제거
        RebuildNavMesh(); // NavMesh를 다시 빌드하여 변경 사항 적용

        return pathExists;
    }

    // 임시 벽을 생성하고 설정
    private GameObject CreateTempWall(Vector2 position)
    {
        GameObject tempWall = new GameObject { transform = { position = new Vector3(position.x, position.y, 0) } };
        NavMeshObstacle tempObstacle = tempWall.AddComponent<NavMeshObstacle>();
        tempObstacle.carving = true;
        tempObstacle.size = new Vector3(0.1f, 0.1f, 1f);
        BuildNavMesh(); // 벽 배치 후 NavMesh 빌드
        return tempWall;
    }

    // 경로 유효성 검사
    private bool CheckPathAvailability(Transform startPoint, Transform endPoint)
    {
        NavMeshAgent agent = new GameObject().AddComponent<NavMeshAgent>();
        agent.Warp(startPoint.position);
        NavMeshPath path = new NavMeshPath();
        agent.CalculatePath(endPoint.position, path);
        bool pathExists = path.status == NavMeshPathStatus.PathComplete;
        Destroy(agent.gameObject); // NavMeshAgent 제거
        return pathExists;
    }

    // 물리 업데이트 후 NavMesh를 업데이트
    public IEnumerator UpdateNavMeshAfterPhysics()
    {
        yield return new WaitForFixedUpdate();
        RebuildNavMesh();
    }

    // NavMesh를 다시 빌드
    private void RebuildNavMesh()
    {
        BuildNavMesh();
    }
}
