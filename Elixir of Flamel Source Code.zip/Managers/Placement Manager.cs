using UnityEngine;

public class PlacementManager : MonoBehaviour
{
    private bool isCancelMode = false; // 삭제 모드 활성화 여부
    private Vector2 lastHighlightedCell; // 마지막으로 하이라이트된 셀

    private WallManager wallManager;
    private TowerManager towerManager;
    private GridManager gridManager;
    private NavMeshManager navMeshManager;

    void Start()
    {
        wallManager = FindObjectOfType<WallManager>();
        towerManager = FindObjectOfType<TowerManager>();
        gridManager = FindObjectOfType<GridManager>();
        navMeshManager = FindObjectOfType<NavMeshManager>();
    }

    void Update()
    {
        if (isCancelMode)
        {
            HandleCancelMode();
        }

        if (Input.GetMouseButtonDown(1))
        {
            DisableAllModes();
        }
    }

    // 삭제 모드 처리
    private void HandleCancelMode()
    {
        Vector2 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        if (Input.GetMouseButtonDown(0))
        {
            CancelObjectAtPosition(mousePosition);
        }

        if (gridManager != null)
        {
            HighlightCell(mousePosition);
        }
    }

    // 특정 위치의 벽과 타워를 취소
    private void CancelObjectAtPosition(Vector2 position)
    {
        Collider2D[] colliders = Physics2D.OverlapCircleAll(position, 0.1f);
        GameObject[] objectsToCancel = FindClosestObjects(colliders);

        foreach (GameObject obj in objectsToCancel)
        {
            if (obj != null)
            {
                if (obj.CompareTag("Wall"))
                {
                    obj.GetComponent<Wall>().CancelWall();
                }
                else if (obj.CompareTag("Tower"))
                {
                    obj.GetComponent<Tower>().CancelTower();
                }
            }
        }
    }

    // 셀을 하이라이트
    private void HighlightCell(Vector2 mousePosition)
    {
        if (lastHighlightedCell != mousePosition)
        {
            gridManager.ClearHighlight(lastHighlightedCell);
            gridManager.HighlightCell(mousePosition, new Color(1f, 0.5f, 0f, 1f)); // 오렌지색
            lastHighlightedCell = mousePosition;
        }
    }

    // 가장 가까운 벽과 타워 찾기
    private GameObject[] FindClosestObjects(Collider2D[] colliders)
    {
        GameObject closestWall = null;
        GameObject closestTower = null;
        float closestWallDistance = Mathf.Infinity;
        float closestTowerDistance = Mathf.Infinity;
        Vector2 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        foreach (var collider in colliders)
        {
            if (collider.CompareTag("Wall"))
            {
                float distance = Vector2.Distance(collider.transform.position, mousePosition);
                if (distance < closestWallDistance)
                {
                    closestWallDistance = distance;
                    closestWall = collider.gameObject;
                }
            }
            else if (collider.CompareTag("Tower"))
            {
                float distance = Vector2.Distance(collider.transform.position, mousePosition);
                if (distance < closestTowerDistance)
                {
                    closestTowerDistance = distance;
                    closestTower = collider.gameObject;
                }
            }
        }

        return new GameObject[] { closestWall, closestTower };
    }

    // 삭제 모드 토글
    public void ToggleCancelMode()
    {
        DisableAllModes();
        isCancelMode = !isCancelMode;
        gridManager.ToggleGrid(isCancelMode);
        if (!isCancelMode)
        {
            gridManager.ClearHighlight(lastHighlightedCell);
        }
    }

    // 벽 설치 모드 토글
    public void TogglePlaceWallMode()
    {
        DisableAllModes();
        wallManager.ToggleWallPlacement();
        isCancelMode = false;
    }

    // 일반 타워 설치 모드 토글
    public void TogglePlaceNormalTowerMode()
    {
        DisableAllModes();
        towerManager.ToggleNormalTowerPlacement();
        isCancelMode = false;
    }

    // 중형 타워 설치 모드 토글
    public void TogglePlaceMediumTowerMode()
    {
        DisableAllModes();
        towerManager.ToggleMediumTowerPlacement();
        isCancelMode = false;
    }

    // 모든 모드를 비활성화
    public void DisableAllModes()
    {
        wallManager.DisableWallPlacement();
        towerManager.DisableTowerPlacement();
        isCancelMode = false;
    }

    public bool PlaceWall(Vector2 position, GameObject wallPrefab)
    {
        // 벽을 배치
        Collider2D[] colliders = Physics2D.OverlapCircleAll(position, 0.1f);
        foreach (var collider in colliders)
        {
            if (collider.gameObject.CompareTag("Wall"))
            {
                return false;
            }
        }

        Vector3 gridPosition = new Vector3(position.x, position.y, 0);
        GameObject newWall = Instantiate(wallPrefab, gridPosition, Quaternion.identity);
        newWall.tag = "Wall";

        StartCoroutine(navMeshManager.UpdateNavMeshAfterPhysics());
        return true;
    }
}
