using System.Collections.Generic;
using UnityEngine;

public class TowerManager : MonoBehaviour
{
    public GameObject towerPrefab1;  // 첫 번째 타워의 프리팹
    public GameObject towerPrefab2;  // 두 번째 타워의 프리팹
    public GridManager gridManager;     // 그리드 매니저 객체
    public GameObject gridVisual;       // 그리드를 표시할 게임 오브젝트
    public int towerCost = 2;           // 타워의 기본 코스트
    private Vector2 lastHighlightedCell; // 마지막으로 하이라이트된 셀
    public DefenseData defenseData; // 타워 관련 데이터(Scriptable Object)

    private DefenseResourceManager resourceManager;
    public bool isPlacingNormalTower = false; // 첫 번째 타워 설치 모드 활성화 여부
    public bool isPlacingMediumTower = false; // 두 번째 타워 설치 모드 활성화 여부

    void Start()
    {
        resourceManager = FindObjectOfType<DefenseResourceManager>();
    }

    void Update()
    {
        // 타워 설치 모드가 활성화된 경우에만 타워 배치 처리
        if (isPlacingNormalTower || isPlacingMediumTower)
        {
            HandleTowerPlacement();
        }
    }

    private void HandleTowerPlacement()
    {
        // 마우스 위치를 월드 좌표로 변환하고, 가장 가까운 그리드 포인트를 찾음
        Vector2 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector3 gridPosition = gridManager.GetNearestPointOnGrid(mousePosition);

        // 이전에 하이라이트된 셀을 지움
        gridManager.ClearHighlight(lastHighlightedCell);

        // 타워나 벽이 현재 위치에 있는지 확인
        bool hasWall = false;
        bool hasTower = false;
        Collider2D[] colliders = Physics2D.OverlapCircleAll(gridPosition, 0.1f);
        foreach (var collider in colliders)
        {
            if (collider.gameObject.CompareTag("Wall"))
            {
                hasWall = true;
            }
            if (collider.gameObject.CompareTag("Tower"))
            {
                hasTower = true;
            }
        }

        // 타워 설치 비용 결정
        int currentTowerCost = isPlacingNormalTower ? 2 : 4;

        // 자원 확인 및 셀 하이라이트
        bool canPlaceTower = hasWall && !hasTower && resourceManager.CanPlaceTower(currentTowerCost);
        gridManager.HighlightCell(mousePosition, canPlaceTower ? Color.green : Color.red);
        lastHighlightedCell = mousePosition;

        // 타워 배치 처리
        if (Input.GetMouseButtonDown(0))
        {
            if (canPlaceTower)
            {
                if (PlaceTower(gridPosition))
                {
                    resourceManager.UseResources(currentTowerCost);

                    // 타워 데이터 저장
                    TowerPositionData data = new TowerPositionData
                    {
                        position = gridPosition,
                        upgradeLevel = 0,
                        towerType = isPlacingNormalTower ? 0 : 1 // 타워 종류 저장
                    };
                    defenseData.towers.Add(data);
                }
            }
        }

        // 설치 모드 비활성화
        if (Input.GetMouseButtonDown(1))
        {
            DisableTowerPlacement();
        }
    }

    // 타워 설치 모드를 토글하는 메서드
    public void ToggleNormalTowerPlacement()
    {
        isPlacingNormalTower = !isPlacingNormalTower;
        if (isPlacingNormalTower)
        {
            isPlacingMediumTower = false; // 다른 타워 설치 모드 비활성화
            EnableGridVisual();
        }
        else
        {
            DisableGridVisual();
        }
    }

    public void ToggleMediumTowerPlacement()
    {
        isPlacingMediumTower = !isPlacingMediumTower;
        if (isPlacingMediumTower)
        {
            isPlacingNormalTower = false; // 다른 타워 설치 모드 비활성화
            EnableGridVisual();
        }
        else
        {
            DisableGridVisual();
        }
    }

    private void EnableGridVisual()
    {
        gridVisual.SetActive(true);
        gridManager.ToggleGrid(true);
    }

    private void DisableGridVisual()
    {
        gridVisual.SetActive(false);
        gridManager.ToggleGrid(false);
        gridManager.ClearHighlight(lastHighlightedCell);
    }

    private bool PlaceTower(Vector3 position)
    {
        // 현재 타워 설치 모드에 따라 적절한 타워 프리팹 선택
        GameObject towerPrefab = isPlacingNormalTower ? towerPrefab1 : towerPrefab2;
        Vector3 adjustedPosition = new Vector3(position.x, position.y + 0.3f, position.z);
        GameObject newTower = Instantiate(towerPrefab, adjustedPosition, Quaternion.identity);
        newTower.tag = "Tower";

        // 타워의 설치 및 업그레이드 비용 설정
        Tower towerComponent = newTower.GetComponent<Tower>();
        if (towerComponent != null)
        {
            towerComponent.towerCost = isPlacingNormalTower ? 2 : 4;
            towerComponent.upgradeCosts = isPlacingNormalTower ? new List<int> { 1, 2 } : new List<int> { 2, 4 };
        }

        return true;
    }

    public void DisableTowerPlacement()
    {
        isPlacingNormalTower = false;
        isPlacingMediumTower = false;
        DisableGridVisual();
    }

    public void DeleteTower(Vector2 position)
    {
        // 주어진 위치에 타워가 있는 경우 제거
        Collider2D[] colliders = Physics2D.OverlapCircleAll(position, 0.1f);
        foreach (var collider in colliders)
        {
            if (collider.gameObject.CompareTag("Tower"))
            {
                Tower tower = collider.gameObject.GetComponent<Tower>();
                if (tower != null)
                {
                    tower.CancelTower();
                }
                break;
            }
        }
    }

    public GameObject LoadTower(Vector3 position, int towerType, int upgradeLevel)
    {
        // 주어진 타워 타입과 업그레이드 레벨로 타워 인스턴스화
        GameObject towerPrefab = towerType == 0 ? towerPrefab1 : towerPrefab2;
        GameObject tower = Instantiate(towerPrefab, position, Quaternion.identity);
        Tower towerComponent = tower.GetComponent<Tower>();
        if (towerComponent != null)
        {
            towerComponent.SetUpgradeLevel(upgradeLevel);
            towerComponent.SetTowerType(towerType);
        }
        return tower;
    }
}