using UnityEngine;

public class WallManager : MonoBehaviour
{
    public GameObject wallPrefab; // 벽 프리팹
    public GridManager gridManager; // 그리드 매니저
    public GameObject gridVisual; // 그리드 시각화 오브젝트
    public Transform startPoint; // 시작 포인트
    public Transform endPoint; // 종료 포인트
    public int wallCost = 1; // 벽 설치 비용

    public bool isPlacingWall = false; // 벽 설치 모드 활성화 여부
    private Vector2 lastHighlightedCell; // 마지막으로 하이라이트된 셀
    private bool isProcessingClick = false; // 클릭 중복 방지 플래그
    public DefenseData defenseData; // 디펜스 데이터

    private NavMeshManager navMeshManager;
    private DefenseResourceManager resourceManager;
    private PlacementManager placeManager;

    void Start()
    {
        navMeshManager = FindObjectOfType<NavMeshManager>();
        resourceManager = FindObjectOfType<DefenseResourceManager>();
        placeManager = FindObjectOfType<PlacementManager>();
    }

    void Update()
    {
        if (isPlacingWall)
        {
            HandleWallPlacement();
        }
    }

    private void HandleWallPlacement()
    {
        // 마우스 위치를 월드 좌표로 변환하고, 가장 가까운 그리드 포인트를 찾음
        Vector2 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector3 gridPosition = gridManager.GetNearestPointOnGrid(mousePosition);

        // 마지막으로 하이라이트된 셀을 지움
        gridManager.ClearHighlight(lastHighlightedCell);

        // 벽을 설치할 수 있는지, 경로가 유효한지 확인
        bool canPlaceWall = resourceManager.CanPlaceWall(wallCost);
        bool isPathAvailable = canPlaceWall && navMeshManager.IsPathAvailableAfterWallPlacement(gridPosition, startPoint, endPoint);
        Color highlightColor = isPathAvailable ? Color.green : Color.red;
        gridManager.HighlightCell(mousePosition, highlightColor);
        lastHighlightedCell = mousePosition;

        // 클릭이 발생하면 벽을 설치
        if (Input.GetMouseButtonDown(0) && canPlaceWall && !isProcessingClick)
        {
            isProcessingClick = true;
            ProcessWallPlacement(gridPosition, mousePosition, isPathAvailable);
            isProcessingClick = false;
        }

        // 우클릭 시 벽 설치 모드를 비활성화
        if (Input.GetMouseButtonDown(1))
        {
            DisableWallPlacement();
        }
    }

    private void ProcessWallPlacement(Vector3 gridPosition, Vector2 mousePosition, bool isPathAvailable)
    {
        if (gridManager.IsPositionInsideGrid(mousePosition))
        {
            if (isPathAvailable)
            {
                if (placeManager.PlaceWall(gridPosition, wallPrefab))
                {
                    resourceManager.UseResources(wallCost);

                    // 벽 데이터 저장
                    WallPositionData data = new WallPositionData { position = gridPosition };
                    defenseData.walls.Add(data);
                }
            }           
        }        
    }

    public void ToggleWallPlacement()
    {
        // 벽 설치 모드를 토글
        isPlacingWall = !isPlacingWall;
        gridVisual.SetActive(isPlacingWall);
        gridManager.ToggleGrid(isPlacingWall);

        // 벽 설치 모드가 비활성화될 때 하이라이트 제거
        if (!isPlacingWall)
        {
            gridManager.ClearHighlight(lastHighlightedCell);
        }
    }

    public void DisableWallPlacement()
    {
        // 벽 설치 모드를 비활성화
        isPlacingWall = false;
        gridVisual.SetActive(false);
        gridManager.ToggleGrid(false);
        gridManager.ClearHighlight(lastHighlightedCell);
    }

    //private bool IsNearEndPoint(Vector2 position)
    //{
    //    // 특정 위치가 종료 포인트 근처인지 확인
    //    float distanceThreshold = 1.5f * gridManager.cellSize;
    //    return Vector2.Distance(position, endPoint.position) < distanceThreshold;
    //}

    public void LoadWall(Vector3 position)
    {
        // 주어진 위치에 벽을 인스턴스화
        Instantiate(wallPrefab, position, Quaternion.identity);
    }
}