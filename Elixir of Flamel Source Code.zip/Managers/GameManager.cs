public enum eSceneName
{
    INTRO,
    LAB,
    TOWN,
    GATHERING,
    DEFENSE,
    COUNT
}

public class GameManager : Singleton<GameManager>
{  
    public bool IsCanShoot;  //인벤토리 창 on/off 여부를 파악하여 플레이어의 공격을 허용
    
    private Shooting _shooting;    
    private EntityMovement _entityMovement;    
    private PlayerScaleController _playerScale;
    private EntityAnimationController _animationController;

    protected override void Awake()
    {
        base.Awake();
    }

    private void Start()
    {
        IsCanShoot = false;        
        _shooting = PlayerManager.Instance.PlayerInstance.GetComponent<Shooting>();        
        _entityMovement = PlayerManager.Instance.PlayerInstance.GetComponent<EntityMovement>();
        _playerScale = PlayerManager.Instance.PlayerInstanceOrigin.GetComponent<PlayerScaleController>();
        _animationController = PlayerManager.Instance.PlayerInstance.GetComponent<EntityAnimationController>();
    }

    public void ConnectShootEvent()
    {
        _shooting.CanShoot();
        _animationController.AttackConnect();
    }

    public void DisconnectShootEvent()
    {
        _shooting.DontShoot();
        _animationController.AttackDisconnect();
    }

    public void ConnectMoveEvent()
    {
        _entityMovement.CanMove();
        _animationController.MoveConnect();
    }

    public void DisconnectMoveEvent()
    {
        _entityMovement.CantMove();
        _animationController.MoveDisconnect();
    }

    public void MakeBigSize()
    {
        _playerScale.MakeBigSize();
    }

    public void MakeSmallSize()
    {
        _playerScale.MakeSmallSize();
    }
}