using System.Collections.Generic;
using System.IO;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.AI;

public class DefenseEnemyManager : MonoBehaviour
{
    public ObjectPool objectPool; // ObjectPool 컴포넌트 참조
    public Transform[] spawnPoints; // 적이 생성될 위치
    public float spawnInterval; // 적 생성 주기
   public DefenseData defenseData;

    private float spawnTimer; // 다음 적 생성까지 남은 시간
    private int currentEnemyCount = 0; // 현재 생성된 적 수
    private int totalSpawnedEnemies = 0; // 총 스폰된 적 수
    private List<Transform> validSpawnPoints = new List<Transform>(); // 유효한 스폰 포인트 목록
    public TMP_Text maxEnemiesText; // 적 수 텍스트 추가
    public TMP_Text remainingEnemiesText; // 남은 적 수 텍스트 추가

    private string defenseDataFilePath;

    private void Start()
    {
        // JSON 파일 경로 설정
        defenseDataFilePath = Path.Combine(Application.persistentDataPath, "defenseData.json");

        Initialize(); // 초기화 메서드 호출
        TimeSystem.Instance.OnDayChange += IncreaseMaxEnemies; // 날짜 변경 이벤트 구독
    }

    private void OnDestroy()
    {
        // 이벤트 구독 해제
        TimeSystem.Instance.OnDayChange -= IncreaseMaxEnemies;
    }

    private void Update()
    {
        HandleEnemySpawn(); // 적 생성 처리       
        UpdateUI(); // UI 업데이트
    }

    // 초기화 메서드
    private void Initialize()
    {
        objectPool = FindObjectOfType<ObjectPool>(); // ObjectPool 컴포넌트 찾기
        spawnTimer = spawnInterval; // 생성 주기 타이머 설정

        // 처음 씬이 로드될 때만 defenseData.maxEnemies를 baseMaxEnemies로 설정합니다.
        if (totalSpawnedEnemies == 0) // totalSpawnedEnemies가 0일 때만 초기화
        {
            defenseData.maxEnemies = Mathf.Max(defenseData.maxEnemies, defenseData.baseMaxEnemies); // 첫 날 스폰될 최대 적 수 설정
        }

        UpdateSpawnPoints(); // 유효한 스폰 포인트 업데이트
        currentEnemyCount = 0; // 현재 적 수 초기화
        totalSpawnedEnemies = 0; // 총 스폰된 적 수 초기화
    }

    // defenseData를 JSON으로 저장
    public void SaveDefenseData()
    {
        defenseData.SaveToJson(defenseDataFilePath);
    }

    // defenseData를 JSON에서 로드
    public void LoadDefenseData()
    {
        defenseData.LoadFromJson(defenseDataFilePath);
    }

    // 적 생성 타이머 및 생성 처리 메서드
    private void HandleEnemySpawn()
    {
        if (currentEnemyCount >= defenseData.maxEnemies || totalSpawnedEnemies >= defenseData.maxEnemies) return; // 최대 적 수 도달 시 생성 중지

        spawnTimer -= Time.deltaTime; // 타이머 감소
        if (spawnTimer <= 0)
        {
            SpawnEnemy(); // 적 생성
            spawnTimer = spawnInterval; // 타이머 재설정
        }
    }

    // 적을 생성하는 메서드
    private void SpawnEnemy()
    {
        if (currentEnemyCount >= defenseData.maxEnemies || totalSpawnedEnemies >= defenseData.maxEnemies) return; // 최대 적 수 도달 시 생성 중지

        GameObject defenseEnemy = objectPool.SpawnFromPool("DefenseEnemy"); // 풀에서 적 오브젝트 가져오기
        if (defenseEnemy != null)
        {
            Vector3 spawnPoint = GetValidSpawnPoint(); // 유효한 스폰 포인트 가져오기
            if (spawnPoint != Vector3.zero)
            {
                defenseEnemy.transform.position = spawnPoint; // 적 위치 설정
                defenseEnemy.SetActive(true); // 적 활성화
                defenseEnemy.GetComponent<EnemyAI>().Initialize(); // 적 초기화
                currentEnemyCount++; // 현재 적 수 증가
                totalSpawnedEnemies++; // 총 스폰된 적 수 증가
                UpdateUI(); // UI 업데이트
                SaveDefenseData(); // 적 생성 후 데이터 저장
            }
            else
            {
                // 유효한 스폰 포인트가 없으면 오브젝트를 풀로 반환합니다.
                objectPool.ReturnObject(defenseEnemy);
            }
        }
    }

    // 모든 적의 NavMeshAgent를 활성화하는 메서드
    public void StartEnemies()
    {
        foreach (GameObject enemy in objectPool.PoolDictionary["DefenseEnemy"])
        {
            if (enemy.activeInHierarchy)
            {
                enemy.GetComponent<NavMeshAgent>().isStopped = false; // 이동 재개
            }
        }
    }

    // 모든 적이 패배했는지 확인하는 메서드
    public bool AreAllEnemiesDefeated()
    {
        // 현재 적 수가 0인지 확인
        if (currentEnemyCount > 0 || totalSpawnedEnemies < defenseData.maxEnemies)
        {
            return false;
        }

        // 모든 적이 비활성화되어 있는지 확인
        bool allEnemiesInactive = objectPool.PoolDictionary["DefenseEnemy"].All(enemy => !enemy.activeInHierarchy);

        // 모든 적이 비활성화되어 있고, 스폰된 적이 없는 경우
        return allEnemiesInactive;
    }

    // 적을 제거하고 오브젝트 풀에 반환하는 메서드
    public void RemoveEnemy(GameObject enemy)
    {
        if (enemy.activeInHierarchy)
        {
            enemy.SetActive(false); // 적 비활성화
            currentEnemyCount--; // 현재 적 수 감소
            objectPool.ReturnObject(enemy); // 오브젝트 풀에 반환
            CheckAllEnemiesDefeated(); // 적이 모두 처치되었는지 확인
        }
    }

    public void CheckAllEnemiesDefeated()
    {
        if (AreAllEnemiesDefeated())
        {
            DefenseUIManager uiManager = FindObjectOfType<DefenseUIManager>();
            uiManager?.ShowWinPanel(); // 모든 적이 처치되었으면 승리 패널 표시
        }
    }

    // 유효한 스폰 포인트를 업데이트하는 메서드
    public void UpdateSpawnPoints()
    {
        validSpawnPoints.Clear(); // 유효한 스폰 포인트 목록 초기화
        foreach (var spawnPoint in spawnPoints)
        {
            if (IsSpawnPointValid(spawnPoint)) // 스폰 포인트 유효성 검사
            {
                validSpawnPoints.Add(spawnPoint); // 유효한 포인트 추가
            }
        }
    }

    // 스폰 포인트의 유효성을 검사하는 메서드
    private bool IsSpawnPointValid(Transform spawnPoint)
    {
        return NavMesh.SamplePosition(spawnPoint.position, out NavMeshHit hit, 1.0f, NavMesh.AllAreas) &&
               Vector3.Distance(spawnPoint.position, hit.position) < 0.1f; // 스폰 포인트가 NavMesh에 유효한지 확인
    }

    // 유효한 스폰 포인트를 반환하는 메서드
    public Vector3 GetValidSpawnPoint()
    {
        foreach (var spawnPoint in validSpawnPoints)
        {
            if (IsSpawnPointValid(spawnPoint)) // 유효한 스폰 포인트 반환
            {
                return spawnPoint.position;
            }
        }
        return Vector3.zero; // 유효한 스폰 포인트가 없으면 Vector3.zero 반환
    }

    // 최대 적 수를 증가시키는 메서드
    private void IncreaseMaxEnemies()
    {
        defenseData.maxEnemies += 5; // 날짜가 지날수록 최대 적 수 5 증가
        totalSpawnedEnemies = 0; // 새로운 날이 시작되면 스폰된 적 수 초기화
        SaveDefenseData(); // 최대 적 수 증가 후 데이터 저장
    }

    // 추가로 적을 생성하는 메서드
    public void AddExtraEnemies(int extraEnemies)
    {
        defenseData.maxEnemies += extraEnemies; // 최대 적 수 증가
        for (int i = 0; i < extraEnemies; i++)
        {
            SpawnEnemy(); // 적 추가 생성
        }
        SaveDefenseData(); // 적 추가 후 데이터 저장
    }

    // 적 정보 업데이트 메서드 추가
    public void UpdateEnemyCount(int spawnedEnemies, int maxEnemies)
    {
        maxEnemiesText.text = $"최대 적의 수: {maxEnemies}";
        remainingEnemiesText.text = $"남은 적의 수: {maxEnemies - spawnedEnemies}";
    }

    // UI를 업데이트하는 메서드 추가
    private void UpdateUI()
    {
        UpdateEnemyCount(totalSpawnedEnemies, defenseData.maxEnemies);
    }
}
