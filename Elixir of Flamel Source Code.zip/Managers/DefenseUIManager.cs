using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DefenseUIManager : MonoBehaviour
{
    // UI 요소들
    public GameObject WinPanel;
    public GameObject gameOverPanel;
    public GameObject startButton;
    public GameObject wallButton;
    public GameObject normaltowerButton;
    public GameObject mediumtowerButton;
    public GameObject cancelButton;

    private DefenseManager defenseManager;

    void Start()
    {
        defenseManager = FindObjectOfType<DefenseManager>();
    }

    // 시작 버튼을 표시
    public void ShowStartButton()
    {
        SetButtonsActive(true);
    }

    // 버튼을 숨김
    public void HideButton()
    {
        SetButtonsActive(false);
    }

    // 버튼 클릭 시 DefenseManager의 OnStartButtonClicked 호출
    public void OnStartButtonClicked()
    {
        defenseManager?.OnStartButtonClicked(); // DefenseManager가 있을 때만 호출
        HideButton(); // 버튼 숨김
    }

    // 승리 패널을 표시하고 게임 일시 정지
    public void ShowWinPanel()
    {
        WinPanel.SetActive(true);
        Time.timeScale = 0;
    }

    // 게임 오버 패널을 표시하고 게임 일시 정지
    public void ShowGameOverPanel()
    {
        gameOverPanel.SetActive(true);
        Time.timeScale = 0;
        ResourcesManager.Instance.ClearDic();
    }

    // 게임을 다시 시작
    public void RestartGame()
    {
        SceneManager.LoadScene(6); // 씬 인덱스 6으로 로드
        Time.timeScale = 0; // 타임스케일 재설정
    }

    // 게임을 백투워크 상태로 전환하고 씬을 다시 로드
    public void BackToWork()
    {
        defenseManager?.SaveDefenseData(); // DefenseManager가 있을 때 데이터 저장

        StartCoroutine(ReloadSceneWithTimeScaleReset(1, true)); // 씬 재로드
    }

    // 씬을 재로드하고 타임스케일을 리셋
    private IEnumerator ReloadSceneWithTimeScaleReset(int sceneIndex, bool resetPlayerState)
    {
        Time.timeScale = 1; // 씬 전환 전에 타임스케일을 1로 설정

        yield return new WaitForSecondsRealtime(0.1f); // 다음 프레임까지 대기

        if (resetPlayerState)
        {
            // 플레이어 상태 및 시간 시스템 초기화
            PlayerManager.Instance.PlayerInstance.SetActive(true);
            TimeSystem.Instance.ChangeDay();
        }

        SceneManager.LoadScene(sceneIndex); // 씬 로드
    }

    // 버튼 활성화 상태를 설정하는 메서드
    private void SetButtonsActive(bool isActive)
    {
        startButton.SetActive(isActive);
        cancelButton.SetActive(isActive);
        wallButton.SetActive(isActive);
        normaltowerButton.SetActive(isActive);
        mediumtowerButton.SetActive(isActive);
    }
}
