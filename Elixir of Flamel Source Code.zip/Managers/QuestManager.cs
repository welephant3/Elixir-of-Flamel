using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class QuestManager : Singleton<QuestManager>
{
    public QuestData questList;
    public List<QuestDatas> curQuest = new List<QuestDatas>();

    public QuestLogic Logic;

    public bool _isPanelActive = false;
    private bool _isIntroScene = false;

    private void Start()
    {
        Logic = GetComponent<QuestLogic>();
        _isIntroScene = SceneManager.GetActiveScene().buildIndex == (int)eSceneName.INTRO;
        SceneManager.sceneLoaded += OnSceneLoad;
    }

    private void Update()
    {
        QuestPanelActivate();
    }

    private void QuestPanelActivate()
    {
        if (_isIntroScene)
        {
            return;
        }

        if (Input.GetKeyDown(KeyCode.Q))
        {
            if (!_isPanelActive)
            {
                UIController.Instance.ShowUI<QuestPanelUI>(UIs.Popup);
                _isPanelActive = true;
                TutorialController.Instance.TutorialUIOn(ref TutorialController.Instance.IsQuest, (int)eFunctionName.QUEST);
            }
            else
            {
                UIController.Instance.HideUI<QuestPanelUI>();
                _isPanelActive = false;
            }
        }
    }

    private void OnSceneLoad(Scene scene, LoadSceneMode mode)
    {
        if (scene.buildIndex == (int)eSceneName.INTRO)
        { _isIntroScene = true; }
        else
        { _isIntroScene = false; }
    }
}
