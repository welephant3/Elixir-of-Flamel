using UnityEngine;
using TMPro;
using System.IO;

public class DefenseResourceManager : MonoBehaviour
{
    public ResourceData resourceData; // ResourceData ScriptableObject를 참조

    public TMP_Text totalResourcesText; // 총 자원을 표시할 UI 텍스트
    public TMP_Text usedResourcesText; // 사용된 자원을 표시할 UI 텍스트

    private string resourceDataFilePath;
    private void Start()
    {
        // JSON 파일 경로 설정
        resourceDataFilePath = Path.Combine(Application.persistentDataPath, "resourceData.json");

        // 1일차인지 확인하여 데이터 초기화
        if (TimeSystem.Instance.day == 1)
        {
            ResetResources();  // 자원 초기화
        }
        else
        {
            LoadResourcesFromDefenseData(); // 기존 자원 데이터 로드
        }

        TimeSystem.Instance.UpdateSystem += IncrementDailyResources;

        // 자원 데이터 로드
        
    }

    private void OnDestroy()
    {
        // 메모리 누수를 방지하기 위해 이벤트 구독 해제
        TimeSystem.Instance.UpdateSystem -= IncrementDailyResources;
    }

    private void LoadResourcesFromDefenseData()
    {
        if (resourceData != null)
        {
            resourceData.LoadFromJson(resourceDataFilePath); // JSON에서 자원 데이터 로드
            UpdateResourceUI();
        }
    }

    // 벽을 배치할 수 있는지 확인
    public bool CanPlaceWall(int cost) => resourceData.totalResources - resourceData.usedResources >= cost;

    // 타워를 배치할 수 있는지 확인
    public bool CanPlaceTower(int cost) => resourceData.totalResources - resourceData.usedResources >= cost;

    // 자원을 사용
    public void UseResources(int amount)
    {
        resourceData.usedResources += amount;
        UpdateResourceUI();
        resourceData.SaveToJson(resourceDataFilePath); // 자원 사용 후 데이터 저장
    }

    // 자원을 환불
    public void RefundResources(int amount)
    {
        resourceData.usedResources -= amount;
        resourceData.usedResources = Mathf.Max(resourceData.usedResources, 0); // 음수가 되지 않도록 설정
        UpdateResourceUI();
        resourceData.SaveToJson(resourceDataFilePath); // 자원 환불 후 데이터 저장
    }

    // 자원 데이터를 로드
    public void LoadResources(int total, int used)
    {
        resourceData.totalResources = total;
        resourceData.usedResources = used;
        UpdateResourceUI();
        ResourcesManager.Instance.ClearDic();
    }

    // 자원 UI를 업데이트
    private void UpdateResourceUI()
    {
        totalResourcesText.text = $"총 자원: {resourceData.totalResources}";
        usedResourcesText.text = $"사용된 자원: {resourceData.usedResources}";
    }

    // 매일 자원을 증가시키는 메서드
    private void IncrementDailyResources()
    {
        int dailyIncrease = Random.Range(3, 5); // 3~4 랜덤 증가

        for (int i = 1; i < 5; i = i + 3)
        {
            if (QuestManager.Instance.questList.data[i].isSucess)
            {
                dailyIncrease++;
            }
        }
        resourceData.totalResources += dailyIncrease;
        UpdateResourceUI();
        resourceData.SaveToJson(resourceDataFilePath); // 자원 증가 후 데이터 저장
    }

    public void ResetResources()
    {
        resourceData.totalResources = 30;  // 초기값으로 설정
        resourceData.usedResources = 0;
        UpdateResourceUI();
        resourceData.SaveToJson(resourceDataFilePath);
    }
}
