using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class EndingManager : Singleton<EndingManager>
{
    public Image happyEndPanel;
    public GameObject[] happyEndTexts;
    public Image badEndPanel;
    public GameObject[] badEndTexts;

    public Image endingImage;
    public GameObject[] textUI;

    public CommonUI commonUI;

    private int currentTextIndex = 0;
   
    public void PlayEnding(string End) // 차례대로 텍스트를 활성화
    {
        UIController.Instance.ShowUI<EndingUI>(UIs.Popup);
        PlayerManager.Instance.PlayerInstance.SetActive(false);
        if(End == "Happy")
        {
            textUI = happyEndTexts;
            endingImage = happyEndPanel;
            PlayTextAnimation();
        }
        else if(End == "Bad")
        {
            textUI = badEndTexts;
            endingImage = badEndPanel;
            PlayTextAnimation();
        }
    }

    public void PlayTextAnimation()
    {
        endingImage.gameObject.SetActive(true);
        if (currentTextIndex < textUI.Length)
        {
            textUI[currentTextIndex].SetActive(true);
            StartCoroutine(OnTextAnimationEnd());
        }
        else
        {
            // 텍스트가 끝난 뒤 추가 이벤트
            AudioManager.Instance.backgroundMusicSource.Stop();
            AudioManager.Instance.backgroundMusicSource.Play();
            SaveManager.Instance._isGameStarted = false;
            SceneManager.LoadScene(0);
            PlayerManager.Instance.PlayerInstance.SetActive(true);
            ResourcesManager.Instance.ClearDic();
            commonUI.is_Pop_Up = false;
        }
    }

    IEnumerator OnTextAnimationEnd() //텍스트 애니메이션 대체 코루틴
    { 
        yield return new WaitForSeconds(3.2f);
        currentTextIndex++;
        PlayTextAnimation();
    }
}
