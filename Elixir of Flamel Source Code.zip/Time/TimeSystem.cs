using System;
using UnityEngine;
using UnityEngine.Rendering.Universal;

public class TimeSystem : Singleton<TimeSystem>
{
    [Range(0, 23)] public int hour = 6;
    [Range(0, 59)] public float min = 0;
    public int day = 1;
    public bool isDay = true;
    public bool is_Pop_Up = false;    
    [SerializeField] public string isDayText;    
    [SerializeField] public Color nightColor;
    [SerializeField] public AnimationCurve TimeCurve;
    [SerializeField] public Color dayColor;
    [SerializeField] public Light2D globalLight;

    public Action UpdateSystem;
    public Action OnDayChange;

    public void UpdateTime()
    {
        if (isDay == true)
        {
            min += Time.deltaTime;
        }
        else if (isDay == false)
        {
            min += Time.deltaTime * 2;
        }
        if (min >= 59f)
        {
            hour += 1;
            min = 0;
        }
        else if (hour >= 24f)
        {
            day += 1;
            hour = 0;
        }
        
        float v = TimeCurve.Evaluate(hour);
        Color c = Color.Lerp(dayColor, nightColor, v);
        globalLight.color = c; //연구소 씬외에 없어서 다른 씬에서 작동 오류를 일으킴(팝업창이 안뜨는 문제)
    }
    public void UpdateDay()
    {
        // 예시 현재 날짜, 날짜 관리 로직으로 변경 해야함
        if (hour >= 6f && hour <= 17f)
        {
            isDay = true;
            isDayText = "낮";
        }
        else
        {
            isDay = false;
            isDayText = "밤";
        }
    }    

    public void ChangeDay()
    {
        is_Pop_Up = false;
        hour = 6;
        min = 0;
        day += 1;

        UpdateSystem?.Invoke();

        OnDayChange?.Invoke(); // 새로운 이벤트 트리거
    }
}
