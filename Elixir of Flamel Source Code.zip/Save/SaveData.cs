using UnityEngine;

[System.Serializable]
public class SaveData
{
    public string sceneName;
    public float playerHealth;
    public float playerStamina;
    public Vector3 playerPosition;
    public int hour;
    public float min;
    public int day;
    public bool[] recipeStates;
    public ItemData[] itemData;
    public int[] quantity;

    public SaveData(string sceneName, float playerHealth, float playerStamina, Vector3 playerPosition, int hour, float min, int day, bool[] recipeStates, ItemData[] itemData, int[] quantity)
    {
        this.sceneName = sceneName;
        this.playerHealth = playerHealth;
        this.playerStamina = playerStamina;
        this.playerPosition = playerPosition;
        this.hour = hour;
        this.min = min;
        this.day = day;
        this.recipeStates = recipeStates;
        this.itemData = itemData;
        this.quantity = quantity;
    }
    public SaveData() 
    {
        this.sceneName = "1.LabScene";
        this.playerHealth = 100;
        this.playerStamina = 100;
        this.playerPosition = new Vector3(0,0,0);
        this.hour = 6;
        this.min = 0;
        this.day = 1;
        this.recipeStates = new bool[RecipeManager.Instance.recipeUI.recipes.Length];
        this.itemData = new ItemData[16];
        this.quantity = new int[16];
    }
}
