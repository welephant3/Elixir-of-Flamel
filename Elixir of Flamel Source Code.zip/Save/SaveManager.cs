using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SaveManager : Singleton<SaveManager>
{    
    private int saveSlotCount = 3;
    public string[] saveFileName;
    public SaveData[] saveData;
    public int currentSlot = 0;
    public bool _isGameStarted;//

    public PlayerManager playerManager;
    public HealthSystem health;//
    public StaminaSystem stamina;//
    public TimeSystem timeSystem;
    public RecipeManager recipeManager;
    public Inventory inventory;

    protected override void Awake()
    {
        base.Awake();
        saveFileName = new string[saveSlotCount];
        saveData = new SaveData[saveSlotCount];
        UIController.Instance.ShowUI<RecipeUI>(UIs.Popup);
        for (int i = 0; i < saveSlotCount; i++)
        {
            saveFileName[i] = Application.persistentDataPath + $"/save_slot_{i + 1}.json";
            string filePath = saveFileName[i];
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                saveData[i] = JsonUtility.FromJson<SaveData>(json);
            }
        }
        UIController.Instance.HideUI<RecipeUI>();
        ResourcesManager.Instance.ClearDic();
    }

    private void Start()
    {
        playerManager = PlayerManager.Instance;  
        health = playerManager.PlayerInstanceOrigin.GetComponentInChildren<HealthSystem>();//
        stamina = playerManager.PlayerInstanceOrigin.GetComponentInChildren<StaminaSystem>();//
        timeSystem = TimeSystem.Instance; 
        inventory = playerManager.inventory;
        recipeManager = RecipeManager.Instance;
    }

    public void SetCurrentSlot(int slotIndex)
    {
        currentSlot = slotIndex;
    }

    public void StartGame()
    {
        SaveData savedata = new SaveData();    

        health.LoadHealthData((int)savedata.playerHealth);//
        stamina.LoadStaminaData((int)savedata.playerStamina);//
        timeSystem.hour = savedata.hour;
        timeSystem.min = savedata.min;
        timeSystem.day = savedata.day;
        for (int i = 0; i < savedata.recipeStates.Length; i++)
        {
            recipeManager.saveData[i] = savedata.recipeStates[i];
        }
        for (int i = 0; i < savedata.itemData.Length; i++)
        {
            inventory.slots[i].item = savedata.itemData[i];
        }
        for (int i = 0; i < savedata.quantity.Length; i++)
        {
            inventory.slots[i].quantity = savedata.quantity[i];
        }
        playerManager.PlayerInstance.transform.position = savedata.playerPosition;
        inventory.UpdateUI();
        SceneManager.LoadScene(savedata.sceneName);
        _isGameStarted = true;// 
        ResourcesManager.Instance.ClearDic();
    }

    public void SaveGame(int slotIndex)
    {
        UIController.Instance.ShowUI<RecipeUI>(UIs.Popup);
        bool[] recipeStates = new bool[recipeManager.recipes.Length];
        ItemData[] itemData = new ItemData[inventory.slots.Length];
        int[] quantity = new int[inventory.slots.Length];
        Transform transform = playerManager.PlayerInstance.transform;

        // scene 이름 가져오기
        string sceneName = SceneManager.GetActiveScene().name;
        // Player 스텟 가져오기
        float playerHealth = health.CurrentHealth;//
        float playerStamina = stamina.CurrentStamina;//
        // Player 위치 가져오기
        Vector3 playerPosition = new Vector3(transform.position.x, transform.position.y, transform.position.z);
        // 게임 시간 가져오기
        int hour = timeSystem.hour;
        float min = timeSystem.min;
        int day = timeSystem.day;
        // 획득한 레시피 가져오기
        for (int i = 0; i < recipeManager.recipes.Length; i++) 
        {
            recipeStates[i] =  recipeManager.saveData[i];
        }
        UIController.Instance.HideUI<RecipeUI>();
        ResourcesManager.Instance.ClearDic();
        // 인벤토리 가져오기
        for (int i = 0;i < inventory.slots.Length;i++)
        {
            itemData[i] = inventory.slots[i].item;
            quantity[i] = inventory.slots[i].quantity;
        }        

        SaveData saveData = new SaveData(sceneName,playerHealth,playerStamina,playerPosition,hour,min,day,recipeStates,itemData,quantity);

        string json = JsonUtility.ToJson(saveData);
        File.WriteAllText(saveFileName[slotIndex], json);
    }

    public void LoadGame(int slotIndex)
    {
        string filePath = saveFileName[slotIndex];
        if (File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);
            saveData[slotIndex] = JsonUtility.FromJson<SaveData>(json);
            var savedata = saveData[currentSlot];
            health.LoadHealthData((int)savedata.playerHealth);//
            stamina.LoadStaminaData((int)savedata.playerStamina);//
            timeSystem.hour = savedata.hour;
            timeSystem.min = savedata.min;
            timeSystem.day = savedata.day;
            for (int i = 0; i < savedata.recipeStates.Length; i++)
            {
                recipeManager.saveData[i] = savedata.recipeStates[i];
            }
            for (int i = 0; i < savedata.itemData.Length; i++)
            {
                inventory.slots[i].item = savedata.itemData[i];
            }
            for (int i = 0; i < savedata.quantity.Length; i++)
            {
                inventory.slots[i].quantity = savedata.quantity[i];
            }
            playerManager.PlayerInstance.transform.position = savedata.playerPosition;
            inventory.UpdateUI();
            SceneManager.LoadScene(saveData[slotIndex].sceneName);
            _isGameStarted = true;//
            ResourcesManager.Instance.ClearDic();
        }
    }
}
