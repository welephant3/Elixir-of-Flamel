using UnityEngine;

public class CraftingItemSlot : MonoBehaviour
{
    public ItemSlot Item;
    public int SlotIndex;
    public ItemData data;
}
