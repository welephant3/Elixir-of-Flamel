using UnityEngine.UI;

public class CustomCursorManager : Singleton<CustomCursorManager>
{
    public Image customCursor;
}
