using System.Collections;
using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class CraftingManager : Singleton<CraftingManager>
{
    public ItemSlot explosionPotion;
    public Sprite noRecipeImage;
    public RecipeManager recipeManager;
    public TextMeshProUGUI[] materialCountText;
    public Image customCursor;
    public Inventory inventory;
    public PlayerManager playerManager;
    public CraftingItemSlot[] craftingSlots;
    public ItemSlot[] materialSlot;
    public List<ItemSlot> itemList;
    public string[] recipes;
    public ItemSlot[] recipeResults;
    public CraftingItemSlot resultSlot;
    public TextMeshProUGUI successOrFailText;

    private ItemSlot currentItem;

    private void Start()
    {
        recipeManager = RecipeManager.Instance;
        playerManager = PlayerManager.Instance;
        customCursor = CustomCursorManager.Instance.customCursor;
        //Refact 필요
        inventory = playerManager.inventory;//인벤토리 가져오기
    }

    private void Update()
    {
        CheckCraftPossible();
    }

    public void CheckCraftPossible()
    {
        if (Input.GetMouseButtonUp(0)) // 3개의 조합창에 마우스커서를 갖다댄 창에 재료를 놓음
        {
            if (currentItem != null)
            {
                customCursor.gameObject.SetActive(false);
                CraftingItemSlot nearestSlot = null;
                float shortestDistance = float.MaxValue;

                foreach (CraftingItemSlot slot in craftingSlots)
                {
                    float dist = Vector2.Distance(Input.mousePosition, slot.transform.position);

                    if (dist < shortestDistance)
                    {
                        shortestDistance = dist;
                        nearestSlot = slot;
                    }
                }
                if (nearestSlot != null)
                {
                    if (nearestSlot.Item != null)
                    {
                        ReturnToSlot(nearestSlot.Item);
                        CheckMaterialSlot();
                        CheckForCreatedRecipes();
                    }
                }
                nearestSlot.GetComponent<Image>().sprite = currentItem.GetComponent<Image>().sprite;
                nearestSlot.gameObject.SetActive(true);
                nearestSlot.Item = currentItem;
                nearestSlot.data = currentItem.item;
                itemList[nearestSlot.SlotIndex] = currentItem;

                currentItem = null;

                CheckForCreatedRecipes();
            }
        }
    }

    public void ReturnToSlot(ItemSlot slot)
    {
        foreach(ItemSlot item in inventory.slots)
        {
            if(item.item != null && item.item.itemId == slot.item.itemId)
            {
                item.quantity += 1;
                break;
            }
        }
    }

    void CheckForCreatedRecipes() // 레시피가 맞는지 itemId에 비교하여 확인함
    {
        resultSlot.gameObject.SetActive(false);
        resultSlot.Item = null;

        string currentRecipeString = "";
        StringBuilder sb = new StringBuilder();

        int ItemCount = 0;
        foreach (ItemSlot item in itemList)
        {
            if (item != null)
            {
                sb.Append(item.item.itemId);
                sb.Append(",");
                ItemCount++;
            }
            else
            {
                sb.Append("null");
                sb.Append(",");
            }
        }

        // 마지막 쉼표와 공백 제거
        if (sb.Length > 0)
        {
            sb.Length -= 1; // 마지막 두 문자(쉼표와 공백) 제거
        }

        currentRecipeString = sb.ToString();

        bool recipeFound = false;
        for (int i = 0; i < recipes.Length; i++)
        {
            if (recipes[i] == currentRecipeString)
            {
                resultSlot.gameObject.SetActive(true);
                resultSlot.Item = recipeResults[i];
                resultSlot.data = recipeResults[i].item;
                successOrFailText.text = recipeResults[i].item.displayName + "\r\n조합성공!";
                for (int j = 0; j < recipeManager.recipes.Length; j++)
                {
                    if (recipeManager.recipes[j].itemId == recipeResults[i].item.itemId)
                    {
                        if(recipeManager.recipes[j].isItemObtained == true)
                        {
                            resultSlot.GetComponent<Image>().sprite = recipeResults[i].GetComponent<SpriteRenderer>().sprite;
                            break;
                        }
                        else
                        {
                            resultSlot.GetComponent<Image>().sprite = noRecipeImage;
                        }
                        
                    }
                }
                recipeFound = true;
                break;
            }
        }
        if(!recipeFound)//레시피를 찾지 못하고 아이템이 2개 이상 들어갔을 시
        {
            if (ItemCount >= 2)
            {
                resultSlot.gameObject.SetActive(true);
                resultSlot.GetComponent<Image>().sprite = noRecipeImage;
                resultSlot.Item = explosionPotion;
                resultSlot.data = explosionPotion.item;
                successOrFailText.text = "조합 실패...";
            }            
        }
    }

    public void OnClickSlot(CraftingItemSlot slot) // 조합창위에 올려놓은 재료들을 클릭시 취소함
    {
        for (int i = 0; i < inventory.slots.Length; i++)
        {
            if (inventory.slots[i].item == slot.data)
            {
                inventory.slots[i].quantity += 1;
                inventory.slots[i].GetComponentInChildren<Image>().gameObject.SetActive(true);
            }
        }
        slot.Item = null;
        itemList[slot.SlotIndex] = null;
        slot.gameObject.SetActive(false);
        CheckForCreatedRecipes();
        CheckMaterialSlot();
    }

    public void OnMouseDownItem(ItemSlot item) // 조합 재료 아이템 드래그시 데이터를 마우스커서에 따라가게함
    {
        if(currentItem == null)
        {
            currentItem = item;
            currentItem.item = item.item;
            customCursor.gameObject.SetActive(true);
            customCursor.sprite = currentItem.GetComponent<Image>().sprite;
            if (SetActiveTrueDelay(successOrFailText.gameObject) != null)
            {
                StopCoroutine(SetActiveTrueDelay(successOrFailText.gameObject));
                successOrFailText.gameObject.SetActive(false );
            }
            for (int i = 0; i < inventory.slots.Length; i++)
            {
                if (inventory.slots[i].item != null && inventory.slots[i].item.itemId == item.item.itemId)
                {
                    if (item.quantity > 1)
                    {
                        inventory.slots[i].quantity -= 1;
                        CheckMaterial(item);
                    }
                    else if (item.quantity == 1)
                    {
                        inventory.slots[i].quantity = 0;
                        CheckMaterial(item);
                    }
                    break;
                }
            }
        }
    }

    public void OnCraftItemAddBtn() // 조합된 아이템 클릭시 인벤토리에 획득하는 버튼
    {

        if(resultSlot.data.displayName == "역병의 치료제")
        {
            EndingManager.Instance.PlayEnding("Happy");
        }
        PlayerManager.Instance.itemData = resultSlot.data;
        PlayerManager.Instance.addItem?.Invoke();        //아이템 조합시 인벤토리에 적용
        if(PlayerManager.Instance.isPickuped == true)
        {
            recipeManager.CheckItemObtain(resultSlot.data);
            for (int i = 0; i < craftingSlots.Length; i++)
            {
                if (craftingSlots[i].Item != null)
                {
                    for (int j = 0; j < inventory.slots.Length; j++)
                    {
                        if (inventory.slots[j].item != null && inventory.slots[j].item.itemId == craftingSlots[i].data.itemId)
                        {
                            inventory.slots[j].quantity++;
                            inventory.selectedSlot = inventory.slots[j];
                            inventory.RemoveSelectedItem(1);
                        }
                    }
                    inventory.selectedSlot = craftingSlots[i].Item;
                    inventory.RemoveSelectedItem(1);
                }
                craftingSlots[i].gameObject.SetActive(false);
                craftingSlots[i].GetComponent<Image>().sprite = null;
                craftingSlots[i].Item = null;
                craftingSlots[i].data = null;
                itemList[craftingSlots[i].SlotIndex] = null;
            }
            resultSlot.Item = null; // 조합시 조합창 초기화
            resultSlot.data = null;
            resultSlot.gameObject.SetActive(false);
            resultSlot.GetComponent<Image>().sprite = null;
            CheckMaterialSlot();
            StartCoroutine(SetActiveTrueDelay(successOrFailText.gameObject));
        }
        else
        {
            successOrFailText.text = "인벤토리가\r\n가득 찼습니다.";
            StartCoroutine(SetActiveTrueDelay(successOrFailText.gameObject));
            return;
        }
    }

    IEnumerator SetActiveTrueDelay(GameObject obj)
    {
        obj.SetActive(true);
        yield return new WaitForSeconds(3);
        if (obj != null)
        {
            obj.SetActive(false);
        }
    }
    public void CheckMaterialSlot()
    {
        DisplayInventoryItemsInCrafting();

        foreach (ItemSlot list in materialSlot)
        {
            CheckMaterial(list);
        }
    }

    public void CheckMaterial(ItemSlot item)
    {
        // 인벤토리가 설정되지 않았거나 슬롯이 비어있는 경우 처리
        if (item.inventory == null || item.inventory.slots == null)
        {
            item.gameObject.SetActive(false);
            return;
        }

        bool foundMatchingItem = false;

        foreach (ItemSlot inventorySlot in item.inventory.slots)
        {
            // 인벤토리 슬롯에 아이템이 없거나 아이템 자체가 null인 경우 스킵
            if (inventorySlot.item == null)
                continue;

            // 같은 아이템 ID를 가진 인벤토리 슬롯 찾기
            if (inventorySlot.item != null && item.item != null && inventorySlot.item.itemId == item.item.itemId && inventorySlot.quantity > 0)
            {
                item.quantity = inventorySlot.quantity;
                TextMeshProUGUI materialSlotText = item.GetComponentInChildren<TextMeshProUGUI>();
                materialSlotText.text = item.quantity.ToString();
                item.gameObject.SetActive(true);
                foundMatchingItem = true;
                break; // 일치하는 첫 번째 아이템을 찾으면 루프 중단
            }
        }

        // 일치하는 아이템이 없으면 비활성화 처리
        if (!foundMatchingItem)
        {
            item.gameObject.SetActive(false);
        }
    }

    public void DisplayInventoryItemsInCrafting()
    {
        for(int i = 0; i < inventory.slots.Length; i++)
        {
            if (inventory.slots[i].item != null && inventory.slots[i].quantity > 0 && (inventory.slots[i].item.itemType == 0 || inventory.slots[i].item.description == "레시피가 쓰여져있는듯 하다. 찢어져서 읽히지 않는다.") && inventory.slots[i].item.itemId != "21")
            {
                bool itemAdded = false;

                for (int j = 0; j < materialSlot.Length; j++)
                {
                    if (materialSlot[j] != null)
                    {
                        if (materialSlot[j].item == null)
                        {
                            materialSlot[j].item = inventory.slots[i].item;
                            materialSlot[j].quantity = inventory.slots[i].quantity;
                            materialSlot[j].GetComponent<Image>().sprite = materialSlot[j].item.icon;
                            itemAdded = true;
                            break;
                        }
                        else if (materialSlot[j].item == inventory.slots[i].item)
                        {
                            materialSlot[j].quantity = inventory.slots[i].quantity;
                            itemAdded = true;
                            break;
                        }
                    }
                }
                if (itemAdded)
                {
                    continue;
                }
            }
        }
        for (int j = 0; j < materialSlot.Length; j++)
        {
            if (materialSlot[j] != null && materialSlot[j].item != null)
            {
                for (int k = j + 1; k < materialSlot.Length; k++)
                {
                    if (materialSlot[k].item != null && materialSlot[j].item == materialSlot[k].item)
                    {
                        materialSlot[k].item = null;
                        materialSlot[k].quantity = 0;
                        materialSlot[k].GetComponent<Image>().sprite = null;
                    }
                }
            }
        }
    }
}
