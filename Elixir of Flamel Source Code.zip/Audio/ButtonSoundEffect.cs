using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ButtonSoundEffect : MonoBehaviour ,IPointerClickHandler
{
    public AudioClip buttonClickSound; // 버튼 클릭 시 재생할 효과음

    private Button button;
    private void Start()
    {
        button = GetComponent<Button>();

    }
    public void OnPointerClick(PointerEventData eventData)
    {
          AudioManager.Instance.PlaySound(buttonClickSound);
    }
}
