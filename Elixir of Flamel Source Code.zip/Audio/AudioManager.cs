using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class AudioManager : Singleton<AudioManager>
{
    public AudioClip backgroundMusicClip;
    public AudioClip labBackgroundMusicClip;
    public AudioClip townBackgroundMusicClip;
    public AudioClip gatheringBackgroundMusicClip;
    public AudioClip defenseBackgroundMusicClip;
    public AudioSource backgroundMusicSource; // 배경음악
    public List<AudioSource> soundEffectSources = new List<AudioSource>(); //효과음
    private int maxAudioSources = 10;

    private float masterAudioVolume = 1.0f;
    private float backgroundMusicVolume = 1.0f; //배경음악 볼륨
    private float soundEffectVolume = 1.0f; //효과음 볼륨

    private Dictionary<string, AudioClip> sceneBackgroundMusicMap = new Dictionary<string, AudioClip>();

    private void Start()
    {
        backgroundMusicSource.clip = backgroundMusicClip;
        backgroundMusicSource.loop = true; // 반복 재생 설정
        backgroundMusicSource.Play(); // 배경음악 재생
        SetMasterAudioVolume(masterAudioVolume);
        for (int i = 0; i < maxAudioSources; i++)
        {
            AudioSource audioSource = gameObject.AddComponent<AudioSource>();
            soundEffectSources.Add(audioSource);
        }

        InitializeSceneBackgroundMusic();

        SceneManager.sceneLoaded += OnSceneLoaded;
        OnSceneLoaded(SceneManager.GetActiveScene(), LoadSceneMode.Single);
    }

    private void OnDestroy()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }
    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (sceneBackgroundMusicMap.TryGetValue(scene.name, out AudioClip clip))
        {
            SetBackgroundMusic(clip);
        }
        else
        {
            SetBackgroundMusic(backgroundMusicClip);
        }
    }
    public void SetMasterAudioVolume(float volume)
    {
        masterAudioVolume = volume;
        SetBackgroundMusicVolume(backgroundMusicVolume);
        SetSoundEffectVolume(soundEffectVolume);
    }
    public void SetBackgroundMusicVolume(float volume) // 배경음악 볼륨조절
    {
        backgroundMusicVolume = volume ;
        backgroundMusicSource.volume = backgroundMusicVolume * masterAudioVolume;
    }
    public void SetSoundEffectVolume(float volume) // 효과음 볼륨조절
    {
        soundEffectVolume = volume;
        foreach (AudioSource source in soundEffectSources)
        {
            source.volume = soundEffectVolume * masterAudioVolume;
        }
    }

    public float GetBackgroundMusicVolume() // 볼륨 가져오기
    {
        return backgroundMusicVolume;
    }
    public float GetSoundEffectVolume()
    {
        return soundEffectVolume;
    }
    public float GetMasterAudioVolume()
    {
        return masterAudioVolume;
    }
    public void PlaySound(AudioClip clip)
    {
        if (clip != null)
        {
            AudioSource source = GetAvailableSoundEffect();
            if(source != null)
            {
                source.clip = clip;
                source.Play();
            }
        }
    }
    public void SetBackgroundMusic(AudioClip clip)
    {
        backgroundMusicSource.clip = clip;
        backgroundMusicSource.Play();
    }

    private AudioSource GetAvailableSoundEffect()
    {
        foreach (AudioSource source in soundEffectSources)
        {
            if (!source.isPlaying)
            {
                return source; // 재생 중이지 않은 AudioSource를 반환
            }
        }
        return null;
    }
    private void InitializeSceneBackgroundMusic()
    {
        sceneBackgroundMusicMap.Add("1.LabScene", labBackgroundMusicClip);
        sceneBackgroundMusicMap.Add("2.TownScene", townBackgroundMusicClip);
        sceneBackgroundMusicMap.Add("3.GatheringScene - Easy", gatheringBackgroundMusicClip);
        sceneBackgroundMusicMap.Add("4.GatheringScene - Normal", gatheringBackgroundMusicClip);
        sceneBackgroundMusicMap.Add("5.GatheringScene - Hard", gatheringBackgroundMusicClip);
        sceneBackgroundMusicMap.Add("6.DefenseScene", defenseBackgroundMusicClip);
    }
}
