using UnityEngine;

public class AnimationController : MonoBehaviour
{
    protected Animator animator;
    protected EntityController controller;

    protected virtual void Awake()
    { 
        animator = GetComponent<Animator>();
        controller = GetComponent<EntityController>();
    }
}
