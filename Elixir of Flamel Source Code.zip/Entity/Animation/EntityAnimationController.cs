using UnityEngine;

public class EntityAnimationController : AnimationController
{
    private static readonly int _isWalking = Animator.StringToHash("_isWalking");    
    private static readonly int _isHit = Animator.StringToHash("_isHit");
    private static readonly int _isAttacking = Animator.StringToHash("_isAttacking");
    private static readonly int _isDeath = Animator.StringToHash("_isDeath");

    private readonly float magnituteThreshold = 0.5f;
       
    private HealthSystem _healthSystem;

    protected override void Awake()
    {
        base.Awake();        
        _healthSystem = GetComponent<HealthSystem>();
    }

    void Start()
    {
        controller.OnMoveEvent += Move;

        if (!transform.CompareTag("Player"))
        {
            controller.OnAttackEvent += Attack;
        }

        if (_healthSystem != null)
        {
            _healthSystem.OnDamage += Hit;
            _healthSystem.OnInvincibilityEnd += InvincibilityEnd;
            _healthSystem.OnDeath += Death;
        }
    }

    public void MoveConnect()
    {
        controller.OnMoveEvent += Move;
    }

    public void MoveDisconnect()
    {
        controller.OnMoveEvent -= Move;
        animator.SetBool(_isWalking, false);
    }

    public void AttackConnect()
    {
        controller.OnAttackEvent += Attack;
    }

    public void AttackDisconnect()
    {
        controller.OnAttackEvent -= Attack;
    }

    private void Move(Vector2 obj)
    {
        animator.SetBool(_isWalking, obj.magnitude > magnituteThreshold);
    }

    private void Attack(ObjectStatData statData)
    {
        animator.SetTrigger(_isAttacking);        
    }

    private void Hit()
    {
        animator.SetBool(_isHit, true);
    }

    private void InvincibilityEnd()
    {
        animator.SetBool(_isHit, false);
    }

    private void Death()
    {
        animator.SetBool(_isDeath, true);
    }
}
