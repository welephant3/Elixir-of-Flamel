using System;
using UnityEngine;

public class EntityController : MonoBehaviour
{
    public event Action<Vector2> OnMoveEvent;   
    public event Action<Vector2> OnLookEvent;
    public event Action<bool> OnRunEvent;
    public event Action<ObjectStatData> OnAttackEvent;

    private float _timeSinceLastAttack = float.MaxValue;
    protected ObjectStatHandler stats { get; private set; }    
    protected bool isAttacking;
    protected bool isRunning;

    protected virtual void Awake()
    { 
        stats = GetComponent<ObjectStatHandler>();
    }

    protected virtual void Update()
    {
        HandleAttackDelay();
    }
    
    // 공격 딜레이 판단 및 체크 메서드
    private void HandleAttackDelay()
    {
        if (_timeSinceLastAttack <= stats.CurrentStat.StatDataSO.Delay)
        { 
            _timeSinceLastAttack += Time.deltaTime;
        }

        if (isAttacking && _timeSinceLastAttack > stats.CurrentStat.StatDataSO.Delay)
        {
            _timeSinceLastAttack = 0;
            CallAttackEvent(stats.CurrentStat.StatDataSO);
        }
    }

    public void CallMoveEvent(Vector2 direction)
    { 
        OnMoveEvent?.Invoke(direction);
    }

    public void CallRunEvent(bool isrunnig)
    {
        OnRunEvent?.Invoke(isrunnig);
    }

    public void CallLookEvent(Vector2 direction)
    { 
        OnLookEvent?.Invoke(direction);
    }

    public void CallAttackEvent(ObjectStatData statData)
    {
        OnAttackEvent?.Invoke(statData);
    }
}