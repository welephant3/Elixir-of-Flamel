using UnityEngine;

public class Shooting : MonoBehaviour
{ 
    private EntityController _controller;    

    [SerializeField] private Transform projectileSpawnPosition;
    private Vector2 _aimDirectiion = Vector2.down;  //투사체 방향 조정 변수    
    private bool _isEventConnected = false;

    private void Awake()
    {
        _controller = GetComponent<EntityController>();        
    }

    private void Start()
    {
        if (!gameObject.CompareTag("Player"))
        { _controller.OnAttackEvent += OnShoot; }
        _controller.OnLookEvent += OnAim;
    }

    // 투사체 방향 조정 메서드
    private void OnAim(Vector2 aimDirection)
    {
        _aimDirectiion = aimDirection;
    }

    // 발사 메서드
    public void OnShoot(ObjectStatData statData)
    {
        CreateProjectile(_aimDirectiion, statData);
    }

    // 투사체 생성 메서드
    private void CreateProjectile(Vector2 dir, ObjectStatData statData)
    {
        GameObject obj = GameObject.Find("ObjectPoolManager").GetComponent<ObjectPool>().SpawnFromPool(statData.ProjectileTag);//ProjectilePool.Instance.ObjectPool.SpawnFromPool(statData.ProjectileTag);
        obj.transform.position = projectileSpawnPosition.position;
        ProjectileController projectile = obj.GetComponent<ProjectileController>();
        projectile.InitializeAttack(dir, statData);
        RotateSprite(obj, dir);
        obj.SetActive(true);        
    }

    private void RotateSprite(GameObject obj, Vector2 direction)//
    {
        SpriteRenderer _spriteRenderer = obj.GetComponent<SpriteRenderer>();
        float rotz = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        if (Mathf.Abs(rotz) < 90f)
        {
            _spriteRenderer.flipY = false;
        }
        else
        {
            _spriteRenderer.flipY = true;
        }
    }

    public void CanShoot()
    {
        if (!_isEventConnected)
        {
            _controller.OnAttackEvent += OnShoot;
            _isEventConnected = true;
        }
        else { return; }
    }

    public void DontShoot()
    {
        if (_isEventConnected)
        {
            _controller.OnAttackEvent -= OnShoot;
            _isEventConnected = false;
        }
        else { return; }
    }
}