using UnityEngine;

public class AimRotation : MonoBehaviour
{
    private EntityController _controller;
    private Transform _spriteRenderer;

    private void Awake()
    {
        _controller = GetComponentInParent<EntityController>();        
        _spriteRenderer = GetComponent<Transform>();
    }

    private void Start()
    {
        _controller.OnLookEvent += OnAim;
    }

    // 마우스 위치값으로 방향 설정
    private void OnAim(Vector2 targetPosition)
    {
        RotateSprite(targetPosition);
    }
        
    private void RotateSprite(Vector2 direction)
    {
        float rotz = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        if (Mathf.Abs(rotz) < 90f)
        {
            _spriteRenderer.localScale = new Vector3(-1, 1, 1);
        }
        else
        {
            _spriteRenderer.localScale = new Vector3(1, 1, 1);
        }
    }
}