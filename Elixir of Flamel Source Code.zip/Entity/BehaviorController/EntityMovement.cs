using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EntityMovement : MonoBehaviour
{
    private Rigidbody2D _rigidbody;
    private EntityController _controller;
    private ObjectStatHandler _objectStatHandler;
    private StaminaSystem _staminaSystem;

    private Vector2 _movementDirection = Vector2.zero;           
    private Vector2 _knockbackDirection = Vector2.zero;
    private float _knockbackDuration = 0f;
    private bool _isKnockback = false;
    private bool _isRunning = false;

    private float _speedMultiplier = 1f;

    private void Awake()
    {
        _rigidbody = GetComponent<Rigidbody2D>();
        _controller = GetComponent<EntityController>();   
        _objectStatHandler = GetComponent<ObjectStatHandler>();
        _staminaSystem = GetComponent<StaminaSystem>();

        if (CompareTag("Player"))
        {
            SceneManager.sceneLoaded += OnSceneLoaded;
        }
    }

    void Start()
    {
        _controller.OnMoveEvent += Move;    
        _controller.OnRunEvent += Run;
    }

    void FixedUpdate()
    {
        if (_knockbackDuration > 0.0f)
        {
            _knockbackDuration -= Time.fixedDeltaTime;
            if (_knockbackDuration <= 0.0f)
            {
                _isKnockback = false;
            }
        }

        ApplyMovement(_movementDirection);
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.buildIndex <= (int)eSceneName.TOWN)
        {
            _speedMultiplier = 1.5f;
        }
        else
        {
            _speedMultiplier = 1f;
        }
    }
        
    private void Move(Vector2 direction)
    {
        if (_isKnockback)
        {
            return;
        }
        _movementDirection = direction;        
    }

    private void Run(bool isRunning)
    {
        if (_isKnockback || _staminaSystem == null)
        {
            return;
        }

        _isRunning = isRunning;

        if (_isRunning)
        {
            _staminaSystem.StartRunning();
        }
        else
        {
            _staminaSystem.StopRunning();
        }
    }

    public void ApplyKnockback(Transform other, float distance, float duration)
    {        
        _knockbackDuration = duration;
        _knockbackDirection = (transform.position - other.position).normalized;
        StartCoroutine(ApplyKnockbackCoroutine(_knockbackDirection, distance, duration));
    }

    private IEnumerator ApplyKnockbackCoroutine(Vector2 direction, float distance, float duration)
    {
        _isKnockback = true;
        float knockbackSpeed = distance / duration;

        float timeElapsed = 0f;        

        while (timeElapsed < duration)
        {
            _rigidbody.velocity = direction * knockbackSpeed; 
            timeElapsed += Time.deltaTime;
            yield return null;
        }

        _movementDirection = Vector2.zero;
        _rigidbody.velocity = Vector2.zero;        
        _isKnockback = false;
    }
 
    // 실제 이동 기능 작동 메서드
    private void ApplyMovement(Vector2 direction)
    {
        float speed = _objectStatHandler.CurrentStat.StatDataSO.Speed * _speedMultiplier;

        if (_isRunning && _staminaSystem != null)
        {
            if (_staminaSystem.CanRun())
            {
                _staminaSystem.DecreaseStamina(Time.fixedDeltaTime);
                speed *= 1.5f;
            }
            else
            {
                _isRunning = false;
                _staminaSystem.StopRunning();
            }
        }

        if (_knockbackDuration > 0.0f)
        {
            direction = _knockbackDirection;
        }
        else
        {
            direction *= speed;
        }

        _rigidbody.velocity = direction;
    }

    public void CanMove()
    {
        _controller.OnMoveEvent += Move;
        _controller.OnRunEvent += Run;
    }

    public void CantMove()
    {
        _movementDirection = Vector2.zero;
        _rigidbody.velocity = Vector2.zero;
        _isRunning = false;
        _staminaSystem.StopRunning();
        _controller.OnMoveEvent -= Move;
        _controller.OnRunEvent -= Run;
    }
}