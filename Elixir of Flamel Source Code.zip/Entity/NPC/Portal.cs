using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Portal : MonoBehaviour, IInteractable
{
    // Todo 필드 포탈은 하루에 한 번 씩만 접근할 수 있도록 할 예정 (입장하면 카운트 체크 뒤 비활성화)
    public enum InteractionType
    {
        Lab, // 바로 씬 전환
        Field // 판넬 표시 후 버튼 클릭으로 씬 전환
    }
    public InteractionType type;
    public Canvas canvas;
    public GameObject FieldPanel;
    public int loadSceneNumber;
    public List<Button> buttons;

    private void OnEnable()
    {
        if (type == InteractionType.Field)
        {
            // 각 버튼에 클릭 이벤트를 설정
            for (int i = 0; i < buttons.Count; i++)
            {
                int index = i;
                buttons[i].onClick.AddListener(() => OnButtonClick(index)); //채집씬이 3,4,5번씬이라면 +3 해줘야함

                //if (NPCManager.Instance.townData.VisitFeild[i] == true)
                //{
                //    buttons[i].interactable = false;
                //}
                //if(i > 0)
                //{
                //    if (QuestManager.Instance.questList.data[(i-1)*3].isSucess == false) // 0번 인덱스, 3번 인덱스 퀘스트 클리어 되지 않았다면
                //    {
                //        buttons[i].interactable = false;
                //    }
                //}
            }
        }
    }
    public void ClosePrompt()
    {
        canvas.gameObject.SetActive(false);
    }

    public void GetInteractPrompt()
    {
        canvas.gameObject.SetActive(true);
    }

    public void OnInteract()
    {       
        switch (type)
        {
            case InteractionType.Lab:
                // Lab 타입인 경우 바로 씬 전환                
                LoadScene(1); //현재 연구소 씬은 1번
                break;

            case InteractionType.Field:
                // Field 타입인 경우 오픈. 필드 클릭 대기
                GameManager.Instance.DisconnectMoveEvent();
                TutorialController.Instance.TutorialUIOn(ref TutorialController.Instance.IsCollect, (int)eFunctionName.COLLECT);
                SetActivePanel();
                FieldPanel.SetActive(true);
                break;
        }
    }

    private void SetActivePanel()
    {
        for (int i = 0; i < buttons.Count; i++)
        {
            buttons[i].interactable = true;
            if (NPCManager.Instance.townData.VisitFeild[i] == true)
            {
                buttons[i].interactable = false;
            }
            if (i > 0)
            {
                if (QuestManager.Instance.questList.data[(i - 1) * 3].isSucess == false) // 0번 인덱스, 3번 인덱스 퀘스트 클리어 되지 않았다면
                {
                    buttons[i].interactable = false;
                }
            }
        }
    }

    private void LoadScene(int loadSceneNumber)
    {
        // 씬 전환 로직
        ResourcesManager.Instance.ClearDic();
        SceneManager.LoadScene(loadSceneNumber);
        PlayerManager.Instance.interaction.swicthbool();
    }

    private void OnButtonClick(int index)
    {
        NPCManager.Instance.townData.VisitFeild[index] = true;
        GameManager.Instance.IsCanShoot = true;
        GameManager.Instance.ConnectShootEvent();
        GameManager.Instance.MakeSmallSize();
        GameManager.Instance.ConnectMoveEvent();
        ResourcesManager.Instance.ClearDic();
        LoadScene(index+3);       
    }

    public void OnExitButton()
    {
        FieldPanel.SetActive(false);
        GameManager.Instance.ConnectMoveEvent();
        PlayerManager.Instance.interaction.swicthbool();
    }
}
