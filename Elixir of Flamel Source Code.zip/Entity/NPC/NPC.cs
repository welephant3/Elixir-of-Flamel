using UnityEngine;

public class NPC : MonoBehaviour, IInteractable
{
    public NPCData data;
    public Canvas InteractionUI; //접근시 팝업될 UI

    private void Start()
    {
        ClosePrompt();
    }
    public void ClosePrompt()
    {
       InteractionUI.gameObject.SetActive(false);       
    }

    public void GetInteractPrompt()
    {
        InteractionUI.gameObject.SetActive(true);
    }

    public void OnInteract() //E버튼 누를시 띄울 판넬
    {
        NPCManager.Instance.data = data;
        UIController.Instance.ShowUI<OnInteractNPCUI>(UIs.Popup);
    }
}
