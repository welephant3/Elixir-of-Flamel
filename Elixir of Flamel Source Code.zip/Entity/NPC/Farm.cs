using UnityEngine;

public class Farm : MonoBehaviour
{
    public GameObject[] Gress;

    private void Awake()
    {
        for (int i = 0; i < Gress.Length; i++)
        {
            NPCManager.Instance.Gress[i] = Gress[i];

            if (NPCManager.Instance.townData.GrowData.Count > i && NPCManager.Instance.townData.GrowData[i] != null)
            {
                Gress[i].gameObject.SetActive(true);
            }
        }
    }
}
