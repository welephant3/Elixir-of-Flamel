using UnityEngine;

public class RefugeeNPC : MonoBehaviour
{
    public GameObject[] RefugeeNPCs;
    public ResourceData resourcedata;

    private void Start()
    {
        AvailableNPC();
    }

    void AvailableNPC()
    {
        for (int i = 0; i < (float)resourcedata.totalResources/20; i++)
        {
            RefugeeNPCs[i].gameObject.SetActive(true);
        }
    }
}
