using System;
using UnityEngine;

public class NPCManager : Singleton<NPCManager>
{
    public TownSceneData townData;
    public NPCData data;

    public bool PlzchangeReliefPanel = false;
    public bool PlzchangeGrowPanel = false;

    public GameObject[] Gress;

    public Action<ItemData, int> Product; // 퀘스트 로직 구독을 위한 Action
    public Action<ItemData, int> Relief;
    public Action<ItemData, int> Grow;

    public int ReductionResource;

    private void Start()
    {
        //TODO TimeSystem에 이벤트 만들고 구독시키기
        TimeSystem.Instance.UpdateSystem += OnDayChanged;
    }

    private void OnDayChanged() //Day 변경 로직에 Action invoke시키고 Action에 구독
    {
        if (townData.curDays != TimeSystem.Instance.day)
        {
            townData.curDays = TimeSystem.Instance.day;
            PlzchangeReliefPanel = true;
            PlzchangeGrowPanel = true;
            for (int i = 0; i < townData.VisitFeild.Length; i++)
            {
                townData.VisitFeild[i] = false;
            }
        }
    }
}
