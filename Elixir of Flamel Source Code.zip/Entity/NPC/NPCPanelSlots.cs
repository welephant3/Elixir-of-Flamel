using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class NPCPanelSlots : MonoBehaviour
{
    public Image image;
    public Button btn;
    public TextMeshProUGUI tmp;

    private void Awake()
    {
        GameObject obj = GetComponentInChildren<Button>().gameObject;

        image = obj.GetComponent<Image>();
        btn = obj.GetComponent<Button>();
        tmp = GetComponentInChildren<TextMeshProUGUI>();
    }
}
