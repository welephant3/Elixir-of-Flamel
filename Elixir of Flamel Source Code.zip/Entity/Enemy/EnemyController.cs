using UnityEngine;

public class EnemyController : EntityController
{
    protected Transform toTargetPosition { get; private set; }    

    protected override void Awake()
    {
        base.Awake();              
    }

    protected virtual void Start()
    {
        toTargetPosition = PlayerManager.Instance.PlayerInstance.transform;
    }   

    // 타겟과의 거리 측정
    protected float CaculateDistance()
    {
        return Vector3.Distance(transform.position, toTargetPosition.position);
    }

    // 타겟의 방향 판단
    protected Vector2 CaculateDirection()
    {
        return (toTargetPosition.position - transform.position).normalized;
    }
}