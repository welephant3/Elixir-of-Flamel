using System;
using UnityEngine;

public class ContactEnemy : EnemyController
{        
    [SerializeField][Range(0f, 100f)] private float ChaseRange;  //인식 및 추적 거리
    [SerializeField][Range(0f, 2f)] private float attackRange;   //공격 가능 거리
        
    private HealthSystem _myHealthSystem;
    private HealthSystem _targetHealthSystem;
    private EntityMovement _targetMovement;
    private int _targetLayerIndex;   
    private bool _isCollidingWithTarget;  //타겟과 접촉(타겟을 공격)중인지 여부
    private bool _isAttacking;

    protected override void Start()
    {
        base.Start();

        _targetLayerIndex = (int)Mathf.Log(stats.CurrentStat.StatDataSO.Target.value, 2);
        _myHealthSystem = GetComponent<HealthSystem>();
        _myHealthSystem.OnDamage += OnDamage;
        
        OnAttackEvent += ApplyHealthChange;
    }

    private void OnDamage()
    {
        ChaseRange *= 1.1f;
    }
    
    private void FixedUpdate()
    {
        float distanceToTarget = CaculateDistance();
        Vector2 directionToTarget = CaculateDirection();

        UpdateEnemyState(distanceToTarget, directionToTarget);
    }

    private void UpdateEnemyState(float distance, Vector2 direction)
    {
        if (isAttacking)
        {
            CallMoveEvent(Vector2.zero);  
            return;
        }

        if (distance <= ChaseRange)
        {
            CallLookEvent(direction);
            CheckIfNear(distance, direction);
        }
        else
        {
            CallMoveEvent(Vector2.zero);
        }
    }

    private void CheckIfNear(float distance, Vector2 direction)
    {
        if (distance <= attackRange)
        {
            PerformAttackEvent(direction);
        }
        else
        {
            CallMoveEvent(direction);
        }
    }

    private void PerformAttackEvent(Vector2 direction)
    {        
        CallMoveEvent(Vector2.zero);
        isAttacking = true;  
    }    

    private void OnCollisionEnter2D(Collision2D collision)
    {
        GameObject receiver = collision.gameObject;        

        if (receiver.layer != _targetLayerIndex)
        {
            return;
        }
        else
        {            
            _targetHealthSystem = receiver.GetComponent<HealthSystem>();
            if (_targetHealthSystem != null)
            {
                _isCollidingWithTarget = true;
            }

            _targetMovement = receiver.GetComponent<EntityMovement>();
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.layer != _targetLayerIndex)
        {            
            return;
        }

        _isCollidingWithTarget = false;
    }

    public void ApplyHealthChange(ObjectStatData entityStat)
    {
        if (isAttacking && _isCollidingWithTarget)
        {
            bool isChanged = _targetHealthSystem.ChangeHealth(-entityStat.DamageValue);
            
            if (entityStat.IsOnKnockback && _targetMovement != null)
            {
                _targetMovement.ApplyKnockback(transform, entityStat.KnockbackDistance, entityStat.KnockbackTime);
            }
        }        
    }

    public void EndAttack()
    { 
        isAttacking = false;
    }
}