using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class EnemyAI : MonoBehaviour
{
    private NavMeshAgent agent; // NavMeshAgent 컴포넌트
    public DefenseEnemyData enemyData; // 적의 데이터
    private float currentHealth; // 현재 체력
    private Transform target; // 목표
    public Image hpBarBackground; // HP 바 배경 이미지
    public Image hpBarFill; // HP 바 채우기 이미지

    private void Start()
    {
        Initialize(); // 초기화 메서드 호출
    }

    // 초기화 메서드
    public void Initialize()
    {
        currentHealth = enemyData.maxHealth; // 체력 초기화
        target = GameObject.FindWithTag("Castle").transform; // 목표를 성으로 설정

        if (agent == null)
        {
            agent = GetComponent<NavMeshAgent>(); // NavMeshAgent 컴포넌트 가져오기
            agent.updateRotation = false; // 회전 업데이트 비활성화
            agent.updateUpAxis = false; // 축 업데이트 비활성화
        }

        agent.SetDestination(target.position); // 목표 위치로 이동 경로 설정
        agent.isStopped = false; // 적의 이동 시작

        UpdateHPBar(); // HP 바 초기화
    }

    private void Update()
    {
        if (agent == null || !agent.isOnNavMesh || !agent.enabled) return; // NavMeshAgent가 비활성화되었거나 NavMesh에 없으면 반환

        // 에이전트가 목표 지점에 도달했는지 확인
        if (!agent.pathPending && agent.remainingDistance <= agent.stoppingDistance)
        {
            if (!agent.hasPath || agent.velocity.sqrMagnitude == 0f)
            {
                AttackTarget(); // 목표 공격
            }
        }
    }

    // 적이 피해를 받을 때 호출되는 메서드
    public void TakeDamage(float amount)
    {
        currentHealth -= amount; // 체력 감소
        if (currentHealth <= 0)
        {
            currentHealth = 0; // 체력이 0 이하로 떨어지지 않도록 보정
            Die(); // 사망 처리
        }
        UpdateHPBar(); // HP 바 업데이트
    }

    // 적이 사망할 때 호출되는 메서드
    private void Die()
    {
        if (agent != null && agent.enabled && agent.isOnNavMesh)
        {
            agent.isStopped = true; // 적의 이동 멈춤
            agent.ResetPath(); // 네브메쉬 에이전트의 경로 초기화
        }

        DefenseEnemyManager enemyManager = FindObjectOfType<DefenseEnemyManager>(); // DefenseEnemyManager 찾기
        if (enemyManager != null)
        {            
            enemyManager.RemoveEnemy(gameObject); // DefenseEnemyManager에서 적 제거
        }
        else
        {
            gameObject.SetActive(false); // DefenseEnemyManager가 없으면 적 비활성화
        }
    }

    // 적이 목표에 도달했을 때 호출되는 메서드
    private void AttackTarget()
    {
        Castle castleHP = target.GetComponent<Castle>(); // 성의 체력 컴포넌트 가져오기
        if (castleHP != null && Vector3.Distance(transform.position, target.position) <= agent.stoppingDistance)
        {
            castleHP.TakeDamage(1); // 성에 피해 입히기
            Die(); // 적 사망 처리
        }
    }

    // HP 바를 업데이트하는 메서드
    private void UpdateHPBar()
    {
        if (hpBarFill != null && hpBarBackground != null)
        {
            float healthPercent = Mathf.Clamp01(currentHealth / enemyData.maxHealth); // 체력 비율 계산
            hpBarFill.fillAmount = healthPercent; // HP 바 채우기
        }
    }
}
