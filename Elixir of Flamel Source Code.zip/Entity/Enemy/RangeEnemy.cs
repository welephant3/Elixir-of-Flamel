using System;
using UnityEngine;

public class RangeEnemy : EnemyController
{
    [SerializeField][Range(0f, 100f)] private float ChaseRange;  //인식 및 추적 거리
    [SerializeField][Range(0f, 50f)] private float ShootRange;  //공격시 제한 사정거리
    private int _layerMaskLevel;
    private int _layerMaskTarget;

    protected override void Start()
    {
        base.Start();

        _layerMaskLevel = LayerMask.NameToLayer("Level");
        _layerMaskTarget = stats.CurrentStat.StatDataSO.Target;
    }

    private void FixedUpdate()
    {   
        float distanceToTarget = CaculateDistance();
        Vector2 directionToTarget = CaculateDirection();

        UpdateEnemyState(distanceToTarget, directionToTarget);
    }

    // 적 현재 상태 확인 이후 행동 설정 메서드
    private void UpdateEnemyState(float distance, Vector2 direction)
    {
        isAttacking = false;

        if (distance <= ChaseRange)
        {
            CallLookEvent(direction);
            CheckIfNear(distance, direction);
        }
        else
        {              
            CallMoveEvent(Vector2.zero);
        }

    }

    // 공격거리 내 원거리 공격 작동 메서드
    private void CheckIfNear(float distance, Vector2 direction)
    {
        if (distance <= ShootRange)
        {
            TryShootAtTarget(direction);
        }
        else
        {
            CallMoveEvent(direction);
        }
    }

    // 레이캐스트로 타겟의 레이어마스크 체크 후 적절한 로직 수행 메서드
    private void TryShootAtTarget(Vector2 direction)
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, ShootRange, CheckLayerMask());

        if (IsHitAtTarget(hit))
        {
            PerformAttackEvent(direction);
        }
        else
        {
            CallMoveEvent(direction);
        }
    }

    // Level 레이어와 타겟 레이어 모두를 포함하는 LayerMask를 반환
    private int CheckLayerMask()
    {
        return (1 << _layerMaskLevel) | _layerMaskTarget;
    }

    // 타겟과 설정 레이어가 동일한지 판별
    private bool IsHitAtTarget(RaycastHit2D hit)
    {
        return hit.collider != null && _layerMaskTarget == (_layerMaskTarget | (1 << hit.collider.gameObject.layer));
    }

    // 공격시 행동제한 메서드
    private void PerformAttackEvent(Vector2 direction)
    {
        CallMoveEvent(Vector2.zero);    
        isAttacking = true;
    }
}