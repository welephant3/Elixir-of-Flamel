using UnityEngine;

public class PlayerScaleController : MonoBehaviour
{
    private Vector3 _newScale;
    private Vector3 _normalScale;

    private void Start()
    {
        _normalScale = transform.localScale;
        _newScale = _normalScale * 0.3f ;  
    }

    public void MakeBigSize()
    {
        transform.localScale = _normalScale;        
    }

    public void MakeSmallSize()
    {
        transform.localScale = _newScale;        
    }
}
