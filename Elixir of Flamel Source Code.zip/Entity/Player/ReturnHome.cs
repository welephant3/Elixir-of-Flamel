using UnityEngine;
using UnityEngine.SceneManagement;

public class ReturnHome : MonoBehaviour
{
    private HealthSystem _healthSystem;    

    private void Awake()
    {
        _healthSystem = GetComponent<HealthSystem>();        
    }

    private void Start()
    {
        _healthSystem.OnReturn += ReturnTown;
    }

    private void ReturnTown()
    {
        if(_healthSystem.CurrentHealth <= 10)
        {
            PlayerManager.Instance.interaction.isPortal = true;
            PlayerManager.Instance.interaction.swicthbool();
            _healthSystem.ChangeHealth(20);
            ResourcesManager.Instance.ClearDic();
            GameManager.Instance.IsCanShoot = false;
            GameManager.Instance.DisconnectShootEvent();
            GameManager.Instance.MakeBigSize();
            SceneManager.LoadScene((int)eSceneName.TOWN);
        }       
    }

    private void OnDestroy() 
    {
        _healthSystem.OnReturn -= ReturnTown;
    }
}
