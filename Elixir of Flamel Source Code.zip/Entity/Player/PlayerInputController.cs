using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class PlayerInputController : EntityController
{
    private PlayerInteraction _interaction;
    private Camera _camera;

    protected override void Awake()
    {
        base.Awake();
        _interaction = GetComponent<PlayerInteraction>();
        SceneManager.sceneLoaded += FindCamera;
    }

    private void FindCamera(Scene scene, LoadSceneMode mode)
    {
        _camera = Camera.main;        
    }

    public void OnMove(InputAction.CallbackContext context)
    {
        Vector2 moveInput = context.ReadValue<Vector2>();              
        CallMoveEvent(moveInput);
    }

    public void OnRun(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            CallRunEvent(true);
        }
        else if (context.canceled)
        {
            CallRunEvent(false);
        }        
    }

    public void OnLook(InputAction.CallbackContext context)
    {
        Vector2 aimInput = context.ReadValue<Vector2>();      
        Vector2 worldPos = _camera.ScreenToWorldPoint(aimInput);       
        aimInput = (worldPos - (Vector2)transform.position).normalized;

        if (aimInput.magnitude >= 0.9f)
        { 
            CallLookEvent(aimInput);
        }
    }

    public void OnAttack(InputAction.CallbackContext context)
    {
        isAttacking = context.ReadValueAsButton();
    }

    public void OnInventory(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            _interaction.CallInventoryEvent();
        }
    }

    public void OnInteraction(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            _interaction.CallInteractionEvent();
        }
    }

    public void OnQuickSlot1(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            _interaction.CallQuickSlot1Event();
        }
    }

    public void OnQuickSlot2(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            _interaction.CallQuickSlot2Event();
        }
    }

    public void OnQuickSlot3(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            _interaction.CallQuickSlot3Event();
        }
    }

    public void OnQuickSlot4(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            _interaction.CallQuickSlot4Event();
        }
    }

    public void OnQuickSlot5(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            _interaction.CallQuickSlot5Event();
        }
    }
}