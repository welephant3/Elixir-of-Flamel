using System;
using UnityEngine;

public class StaminaSystem : MonoBehaviour
{    
    [SerializeField] private float staminaLimitMinValue;  // 달리기 기능이 작동하기 위한 스태미나 최소값
    [SerializeField] private float staminaDecreaseRate;   // 초당 감소 스태미나
    [SerializeField] public float staminaRecoveryRate;   // 초당 회복 스태미나
        
    private ObjectStatHandler _statHandler;

    public event Action<float> OnStaminaChanged;  // 스태미나 변동시 UI적용을 위한 이벤트 
    
    public float CurrentStamina { get; private set; }
    public float MaxStamina => _statHandler.CurrentStat.StatDataSO.MaxStamina;

    private bool _isRunning = false;
   
    private void Awake()
    {
        _statHandler = GetComponent<ObjectStatHandler>();
    }

    private void Start()
    {
        CurrentStamina = _statHandler.CurrentStat.StatDataSO.MaxStamina;     
    }

    private void Update()
    {
        if (!_isRunning)
        {
            RecoverStamina(Time.deltaTime);
        }
    }

    public bool CanRun()
    {
        return CurrentStamina > staminaLimitMinValue;
    }

    public void DecreaseStamina(float deltaTime)
    { 
        CurrentStamina -= staminaDecreaseRate * deltaTime;
        CurrentStamina = Mathf.Clamp(CurrentStamina, 0, MaxStamina);
        OnStaminaChanged?.Invoke(CurrentStamina);
    }

    private void RecoverStamina(float deltaTime)
    {
        CurrentStamina += staminaRecoveryRate * deltaTime;
        CurrentStamina = Mathf.Clamp(CurrentStamina, 0, MaxStamina);
        OnStaminaChanged?.Invoke(CurrentStamina);
    }

    public void StartRunning()
    { 
        _isRunning = true;
    }

    public void StopRunning()
    { 
        _isRunning = false;
    }

    public void LoadStaminaData(int loadData)
    {
        CurrentStamina = loadData;
    }
}