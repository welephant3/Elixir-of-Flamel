using System;
using UnityEngine;

public class PlayerInteraction : MonoBehaviour
{
    public event Action OnInventoryEvent;
    public event Action OnInteractionEvent;    
    public event Action OnQuickSlot1;
    public event Action OnQuickSlot2;
    public event Action OnQuickSlot3;
    public event Action OnQuickSlot4;
    public event Action OnQuickSlot5;    

    public void CallInventoryEvent()
    {
        OnInventoryEvent?.Invoke();
    }

    public void CallInteractionEvent()
    {
        OnInteractionEvent?.Invoke();
    }

    public void CallQuickSlot1Event()
    {
        OnQuickSlot1?.Invoke();
    }

    public void CallQuickSlot2Event()
    {
        OnQuickSlot2?.Invoke();
    }

    public void CallQuickSlot3Event()
    {
        OnQuickSlot3?.Invoke();
    }

    public void CallQuickSlot4Event()
    {
        OnQuickSlot4?.Invoke();
    }

    public void CallQuickSlot5Event()
    {
        OnQuickSlot5?.Invoke();
    }
}