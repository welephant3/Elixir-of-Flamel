using System;
using UnityEngine;

public class HealthSystem : MonoBehaviour
{
    private ObjectStatHandler _statHandler;
    private float _stateChangeDelay;
    private float _timeSinceLastStateChange = float.MaxValue;
    private bool _isAttacked = false;

    public event Action OnDamage;
    public event Action OnHeal;
    public event Action OnDeath;
    public event Action OnInvincibilityEnd;
    public event Action OnReturn;

    public float CurrentHealth { get; set; }

    public float MaxHealth => _statHandler.CurrentStat.StatDataSO.MaxHealth;

    private void Awake()
    {
        _statHandler = GetComponent<ObjectStatHandler>();
    }

    void Start()
    {
        if (gameObject.CompareTag("Player"))
        {
            TimeSystem.Instance.UpdateSystem += () =>
            {
                ChangeHealth(MaxHealth);
                _isAttacked = false;
                _timeSinceLastStateChange = float.MaxValue;
            };
        }  //클로저(Closure) 사용, 매개변수 전달을 위함
        
        _stateChangeDelay = _statHandler.CurrentStat.StatDataSO.KnockbackTime;
        CurrentHealth = _statHandler.CurrentStat.StatDataSO.MaxHealth;
    }
       
    void Update()
    {
        if (_isAttacked && _timeSinceLastStateChange < _stateChangeDelay)
        {
            _timeSinceLastStateChange += Time.deltaTime;
            if (_timeSinceLastStateChange >= _stateChangeDelay)
            { 
                OnInvincibilityEnd?.Invoke();
                _isAttacked = false;
            }
        }
    }

    public bool ChangeHealth(float value)
    {
        if (_timeSinceLastStateChange < _stateChangeDelay)
        { 
            return false;
        }

        _timeSinceLastStateChange = 0;

        if (value < 0)
        {
            float finalDamage = value + _statHandler.CurrentStat.StatDataSO.DefenseValue;
            value = Mathf.Min(finalDamage, 0);            
        }

        CurrentHealth += value;
        CurrentHealth = Mathf.Clamp(CurrentHealth, 0, MaxHealth);

        if (!gameObject.CompareTag("Player") && CurrentHealth <= 0f)
        {
            CallDeath();
            return true;
        }

        if (gameObject.CompareTag("Player"))
        {
            if (CurrentHealth <= MaxHealth * 0.1f)
            {
                OnReturn?.Invoke();
            }
        }

        if (value > 0)
        {
            OnHeal?.Invoke();
        }
        else if (value < 0)
        { 
            OnDamage?.Invoke();
            _isAttacked = true;
        }
        else
        {
            return true;
        }

        return true;
    }

    private void CallDeath()
    {
        OnDeath?.Invoke();
    }

    public void LoadHealthData(int loadData)
    {
        CurrentHealth = loadData;
    }
}
