using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

//ToDo : ENUM 이동
public enum eStatChangeType
{ 
    ADD,
    MULTIPLE,
    OVERRIDE   
}

public enum eUpgradeOption
{ 
    MAXHEALTH,
    MAXSTAMINA,
    CURHEALTH,
    ATTACKDELAY,
    DAMAGEVALUE,
    PROJECTILESPEED,
    MAXRANGE,
    DEFENSEVALUE,
    SPEED,
    COUNT
}

[Serializable]
public class ObjectStat
{
    public eStatChangeType StatChangeType;
    public ObjectStatData StatDataSO;
    public int Id;

    public override bool Equals(object obj)
    {
        if (obj == null || GetType() != obj.GetType())
            return false;

        ObjectStat other = (ObjectStat)obj;
        return Id == other.Id &&
               StatChangeType == other.StatChangeType &&
                (StatDataSO == other.StatDataSO ||
                (StatDataSO != null && StatDataSO.Equals(other.StatDataSO)));
    }

    public override int GetHashCode()
    {
        int hash = 17;
        hash = hash * 23 + Id.GetHashCode();
        hash = hash * 23 + StatChangeType.GetHashCode();
        hash = hash * 23 + (StatDataSO != null ? StatDataSO.GetHashCode() : 0);
        return hash;
    }
}

public class ObjectStatHandler : MonoBehaviour
{
    //기본 스탯과 버프 스탯들의 능력치를 종합해서 스탯을 계산하는 컴포넌트
    [SerializeField] private ObjectStat baseStat;
    public ObjectStat CurrentStat { get; private set; } = new();
    public List<ObjectStat> StatsModifier = new List<ObjectStat>();

    public event Action OnStatChanged;

    private readonly int _minHealth = 5;
    private readonly int _minStamina = 5;
    private readonly float _minDelay = 0.03f;
    private readonly float _minDamageValue = 0.5f;
    private readonly float _minProjectileSpeed = 0.1f;
    private readonly float _minMaxRange = 0.1f;
    private readonly float _minDefenseValue = 1.0f;
    private readonly float _minSpeed = 1.0f;

    private void Awake()
    {
        ApplyBaseStat();
        UpdateStatus();
    }

    //외부에서 스탯 변화 얻음
    public void AddStatModifier(ObjectStat statModifier)
    {        
        StatsModifier.Add(statModifier);
        UpdateStatus();
    }

    //스탯 변화 해제
    public void RemoveStatModifier(ObjectStat statModifier)
    {      
        ObjectStat foundModifier = StatsModifier.Find(stat => stat.Equals(statModifier));
        if (foundModifier != null)
        {
            StatsModifier.Remove(foundModifier);
            UpdateStatus();
        }
    }

    //베이스 스탯 먼저 적용
    private void ApplyBaseStat()
    { 
        CurrentStat.StatDataSO = Instantiate(baseStat.StatDataSO);
    }

    private void UpdateStatus()
    {
        ApplyBaseStat();

        //변경되는 수치들을 반영
        //StatChangeType의 순서 0 : Add, 1 : Multiple, 2 : Override
        foreach (var modifier in StatsModifier.OrderBy(o => o.StatChangeType))
        {
            ApplyStatModifiers(modifier);
        }
        OnStatChanged?.Invoke();
    }

    private void ApplyStatModifiers(ObjectStat modifier)
    {
        Func<float, float, float> operation = modifier.StatChangeType switch
        {
            eStatChangeType.ADD => (current, change) => current + change,
            eStatChangeType.MULTIPLE => (current, change) => current * change,
            _ => (current, change) => change,
        };
                
        UpdateStatData(operation, modifier); 
    }

    private void UpdateStatData(Func<float, float, float> operation, ObjectStat modifier)
    {
        if (CurrentStat.StatDataSO == null || modifier.StatDataSO == null) return;

        var currentStat = CurrentStat.StatDataSO;
        var newStat = modifier.StatDataSO;
        
        currentStat.MaxHealth = Mathf.Max((int)operation(currentStat.MaxHealth, newStat.MaxHealth), _minHealth);
        currentStat.MaxStamina = Mathf.Max((int)operation(currentStat.MaxStamina, newStat.MaxStamina), _minStamina);
        currentStat.Delay = Mathf.Max(operation(currentStat.Delay, newStat.Delay), _minDelay);
        currentStat.DamageValue = Mathf.Max(operation(currentStat.DamageValue, newStat.DamageValue), _minDamageValue);
        currentStat.ProjectileSpeed = Mathf.Max(operation(currentStat.ProjectileSpeed, newStat.ProjectileSpeed), _minProjectileSpeed);
        currentStat.MaxRange = Mathf.Max(operation(currentStat.MaxRange, newStat.MaxRange), _minMaxRange);
        currentStat.DefenseValue = Mathf.Max(operation(currentStat.DefenseValue, newStat.DefenseValue), _minDefenseValue);
        currentStat.Speed = Mathf.Max(operation(currentStat.Speed, newStat.Speed), _minSpeed);
    }    
}