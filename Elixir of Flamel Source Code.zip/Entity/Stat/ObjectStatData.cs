using UnityEngine;

[CreateAssetMenu(fileName = "ObjectStatSO", menuName = "SO/Object", order = 3)]
public class ObjectStatData : ScriptableObject
{
    public string Id;

    public override bool Equals(object obj)
    {
        if (obj is ObjectStatData other)
        {
            return Id == other.Id;
        }
        return false;
    }

    public override int GetHashCode()
    {
        return Id.GetHashCode();
    }

    [Header("Health Info")]  //체력 스탯    
    public int MaxHealth;
    public int MaxStamina;

    [Header("CommonAttack Info")]  //공통 공격 스탯
    [Range(0f, 20f)] public float Delay;  //공격간 딜레이
    [Range(0f, 50f)] public float DamageValue;
    public LayerMask Target;  //공격 목표

    [Header("ContactAttack Info")]  //근접 공격 스탯
    public bool IsOnKnockback;  //넉백 활성화 여부
    [Range(0f, 10f)] public float KnockbackDistance;  //넉백시 거리 
    [Range(0f, 5f)] public float KnockbackTime;  //무적 시간

    [Header("RangedAttack Info")] //원거리 공격 스탯
    public float Size;  //투사체 스프라이트 크기
    public string ProjectileTag;
    [Range(0f, 10f)] public float ProjectileSpeed;
    [Range(0f, 20f)] public float MaxRange;
    public Color ProjectileColor;  //투사체 색 변경시

    [Header("Defense Info")]  //방어 스탯
    [Range(0f, 20f)] public float DefenseValue;

    [Header("Etc Info")]  //기타
    [Range(0f, 20f)] public float Speed;
}