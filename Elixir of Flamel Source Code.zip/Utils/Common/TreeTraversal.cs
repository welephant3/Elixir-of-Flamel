using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class TreeTraversal : MonoBehaviour
{
    // 자식 이미지, 텍스트를 저장할 리스트
    private List<Image> childImages = new List<Image>();
    private List<TextMeshProUGUI> childTexts = new List<TextMeshProUGUI>();
    private List<Button> childButtons = new List<Button>();
    private List<RecipeImage> childRecipes = new List<RecipeImage>();
    private List<GameObject> childGameObjects = new List<GameObject>();

    // 트리 구조를 순회하고 자식 이미지와 텍스트를 수집하는 메서드
    public void TraverseGameObjectTree(GameObject rootObject)
    {
        // 초기화
        childImages.Clear();
        childTexts.Clear();
        childButtons.Clear();
        childRecipes.Clear();
        childGameObjects.Clear();

        // 시작 오브젝트의 자식들을 순회하며 이미지와 텍스트를 수집
        TraverseChildren(rootObject.transform);
    }

    private void TraverseChildren(Transform parent)
    {
        foreach (Transform child in parent)
        {
            // 자식 오브젝트에서 Image 컴포넌트 가져오기
            Image image = child.GetComponent<Image>();
            if (image != null)
            {
                childImages.Add(image);
            }

            // 자식 오브젝트에서 Text 컴포넌트 가져오기
            TextMeshProUGUI text = child.GetComponent<TextMeshProUGUI>();
            if (text != null)
            {
                childTexts.Add(text);
            }

            Button button = child.GetComponent<Button>();
            if (button != null)
            {
                childButtons.Add(button);
            }
            RecipeImage recipe = child.GetComponent<RecipeImage>();
            if (recipe != null)
            {
                childRecipes.Add(recipe);
            }
            GameObject gameObject = child.GetComponent<GameObject>();
            if (gameObject != null)
            {
                childGameObjects.Add(gameObject);
            }

            // 재귀적으로 자식 오브젝트의 자식들도 탐색
            TraverseChildren(child);
        }
    }

    // 자식 이미지들 반환
    public List<Image> GetChildImages()
    {
        return childImages;
    }

    // 자식 텍스트들 반환
    public List<TextMeshProUGUI> GetChildTexts()
    {
        return childTexts;
    }

    public List<Button> GetChildButtons()
    {
        return childButtons;
    }
    public List<RecipeImage> GetChildRecipes()
    {
        return childRecipes;
    }
    public List<GameObject> GetChildGameObjects()
    {
        return childGameObjects;
    }
}
