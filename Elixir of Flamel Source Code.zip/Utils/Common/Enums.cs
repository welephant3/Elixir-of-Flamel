
//규칙1. enum 이름 앞에 소문자e 붙이기
//규칙2. enum의 원소들은 대문자로 만들기

//ex)
public enum eItemType
{
    MATERIAL,
    CONSUME,
    EQUIP,
    RESOURCE
}

public enum eConditionType //플레이어의 상태 체력, 스태미나에 영향
{
    HEALTH,
    STAMINA
}

public enum eEquipStatType
{
    ATK,
    DEF
}

public enum eEquipType
{
    WEAPON,
    HELMET,
    ARMOR,
    NECKLESS,
    RING,
    BOOTS
}