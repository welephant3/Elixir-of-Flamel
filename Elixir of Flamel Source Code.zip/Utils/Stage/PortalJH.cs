using UnityEngine;
using UnityEngine.SceneManagement;

public class PortalJH : MonoBehaviour
{
    [SerializeField] private int nextScene;
    private int _playerLayer;

    private void Start()
    {
        _playerLayer = LayerMask.NameToLayer("Player");
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == _playerLayer)
        {
            if (3 <= nextScene && nextScene <= 5)
            {
                GameManager.Instance.IsCanShoot = true;
                GameManager.Instance.ConnectShootEvent();
                GameManager.Instance.MakeSmallSize();
            }
            else
            {
                GameManager.Instance.IsCanShoot = false;
                GameManager.Instance.DisconnectShootEvent();
                GameManager.Instance.MakeBigSize();
            }
            SceneLoad(nextScene);
        }
        ResourcesManager.Instance.ClearDic();
    }

    public void SceneLoad(int sceneIndex)
    {
        SceneManager.LoadScene(sceneIndex);        
    }
}