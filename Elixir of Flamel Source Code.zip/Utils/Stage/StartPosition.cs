using UnityEngine;

public class StartPosition : MonoBehaviour
{    
    private GameObject _playerStartPos;

    private void Start()
    {
        _playerStartPos = PlayerManager.Instance.PlayerInstance;
        _playerStartPos.transform.position = transform.position;
    }
}