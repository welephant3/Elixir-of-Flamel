using System.Collections.Generic;
using UnityEngine;

public class RandomSpawn : MonoBehaviour
{
    public RandomMapGenerator RandomMapGenerator;
    public ObjectPool ObjectPool;    

    public int MinSpawnCount;
    public int MaxSpawnCount;

    private List<Vector3Int> _spawnPoints;    
    private int _mapSize;

    private void Awake()
    {
        ObjectPool = GetComponentInChildren<ObjectPool>();
        _spawnPoints = RandomMapGenerator.ObjectPosition;             
    }

    private void OnEnable()
    {
        _mapSize = RandomMapGenerator.mapSize;  
        RandomObjectSpawn();
    }

    public void RandomObjectSpawn()
    {
        int spawnCount = Random.Range(MinSpawnCount, MaxSpawnCount);        

        for (int i = 0; i < spawnCount; i++)
        {
            GameObject obj = ObjectPool.SpawnFromPool(ObjectPool.Pools[RandomIndex()].tag);            
            obj.transform.position = RandomPosition();            
        }
    }

    private int RandomIndex()
    {
        int index = Random.Range(0, ObjectPool.Pools.Count);
        return index;
    }

    private Vector3Int RandomPosition()
    {
        float minRangeX = 4;
        float maxRangeX = _mapSize - 4;
        float minRangeY = 4;
        float maxRangeY = _mapSize - 4;
        
        float boundaryX = Random.Range(minRangeX, maxRangeX);
        float boundaryY = Random.Range(minRangeY, maxRangeY);
       
        Vector3Int respawnPosition = new Vector3Int((int)boundaryX, (int)boundaryY, 0);
        _spawnPoints.Add(respawnPosition);        
        return respawnPosition;           
    }
}