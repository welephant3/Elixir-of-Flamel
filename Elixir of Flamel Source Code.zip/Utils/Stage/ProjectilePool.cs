using UnityEngine;

public class ProjectilePool : MonoBehaviour
{
    public ObjectPool ObjectPool;

    private void Awake()
    {
        ObjectPool = GetComponent<ObjectPool>();
    }
}