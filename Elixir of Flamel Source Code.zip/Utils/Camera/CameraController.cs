using UnityEngine;

public class CameraController : MonoBehaviour
{
    [Tooltip("카메라 이동속도")]
    [SerializeField] private float moveSpeed; //카메라 이동속도

    private GameObject _target;  //카메라가 추적할 대상
    private Vector3 _targetPosition;  //대상의 현재 위치

    private void Start()
    {
        _target = PlayerManager.Instance.PlayerInstance;       
    }

    void FixedUpdate()
    {
        if (_target.gameObject != null)
        {
            _targetPosition.Set(_target.transform.position.x, _target.transform.position.y, transform.position.z);
            //z값이 대상의 값과 같으면 대상을 찍을 수 없으므로 카메라 자신의 z값을 넣어줌.

            transform.position = Vector3.Lerp(transform.position, _targetPosition, moveSpeed * Time.deltaTime);
        }
    }
}
