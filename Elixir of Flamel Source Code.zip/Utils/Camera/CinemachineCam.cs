using Cinemachine;
using UnityEngine;

public class CinemachineCam : MonoBehaviour
{
    private CinemachineVirtualCamera mCam;
    
    void Start()
    {
        mCam = GetComponent<CinemachineVirtualCamera>();
        GameObject target = PlayerManager.Instance.PlayerInstance;
        mCam.Follow = target.transform;
    }
}
