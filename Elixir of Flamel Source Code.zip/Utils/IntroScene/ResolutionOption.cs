using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ResolutionOption : MonoBehaviour
{
    public Toggle FullScreenSwitch;

    [SerializeField] private TMP_Dropdown ResolutionDropdown;

    private FullScreenMode _screenMode;
    private Resolution[] _resolutions;
    private List<Resolution> _filteredResolutions;
    private float _currentRefreshRate;
    private int _currentResolutionIndex = 0;
    
    void Start()
    {
        _resolutions = Screen.resolutions;  //모든 해상도를 가져옴
        _filteredResolutions = new List<Resolution>();

        ResolutionDropdown.ClearOptions();
        _currentRefreshRate = (float)Screen.currentResolution.refreshRateRatio.value;  //Hz, 화면주사율

        for (int i = 0; i < _resolutions.Length; i++)
        {
            if ((float)_resolutions[i].refreshRateRatio.value == _currentRefreshRate)  //현재 모니터의 화면주사율에 맞는 요소만 받아옴
            {
                _filteredResolutions.Add(_resolutions[i]);
            }
        }

        //조건에 맞게 필터링된 해상도 내림차순 정렬
        _filteredResolutions.Sort((a, b) =>
        {
            if (a.width != b.width)
            {
                return b.width.CompareTo(a.width);
            }
            else
            {
                return b.height.CompareTo(a.height);
            }
        });

        List<string> options = new List<string>();  //드롭다운에 조건에 맞는 해상도를 넣어줌
        for (int i = 0; i < _filteredResolutions.Count; i++)
        {
            string resolutionOption = _filteredResolutions[i].width + "x" + _filteredResolutions[i].height + "   " + _filteredResolutions[i].refreshRateRatio.value.ToString("0.##") + "Hz";
            options.Add(resolutionOption);

            if (_filteredResolutions[i].width == Screen.width &&
                _filteredResolutions[i].height == Screen.height &&
                (float)_filteredResolutions[i].refreshRateRatio.value == _currentRefreshRate)
            { 
                _currentResolutionIndex = i;
            }
        }

        ResolutionDropdown.AddOptions(options);
        ResolutionDropdown.value = _currentResolutionIndex = 0;
        ResolutionDropdown.RefreshShownValue();  //드롭다운에 해상도 표시

        FullScreenSwitch.isOn = Screen.fullScreenMode.Equals(FullScreenMode.FullScreenWindow)? true : false;
        SetResolution(_currentResolutionIndex);
    }

    //풀스크린 토글 작동 메서드
    public void FullScreenToggle(bool isFull)
    {
        _screenMode = isFull ? FullScreenMode.FullScreenWindow : FullScreenMode.Windowed;
    }

    //해상도 설정 메서드
    public void SetResolution(int resolutionIndex)
    {
        Resolution resolution = _filteredResolutions[resolutionIndex];
        Screen.SetResolution(resolution.width, resolution.height, _screenMode);
    }
}
