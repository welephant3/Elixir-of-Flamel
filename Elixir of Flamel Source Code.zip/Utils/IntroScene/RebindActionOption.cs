using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;

public class RebindActionOption : MonoBehaviour
{
    [SerializeField] private InputActionReference currentAction = null; //현재 할당된 원본 키의 정보(InputActionReference)를 넣어줌
    [SerializeField] private TMP_Text displayBindingKey = null; //버튼에 적힌 키 이름
    [SerializeField] private GameObject CheckBox; //버튼을 눌렀는지 확인하는 용도
    [SerializeField] private InputBinding.DisplayStringOptions displayStringOptions; //버튼에 적힐 키 이름
    [SerializeField] private int bindingIndex = 0;  //Move와 QuickSlot처럼 다수의 Binding을 가진 경우를 위한 바인딩 인덱스

    private InputActionRebindingExtensions.RebindingOperation _rebindingOperation;
    private string _path = null;  //중복 키 설정시 기존의 경로로 덮어씌울 예정

    //리바인딩 시작메서드
    ////ToDo : 각 버튼에 OnClick 함수로 넣어줄 예정
    public void StartRebinding()
    {
        currentAction.action.Disable();  //리바인딩 전에 해당 InputAction을 비활성화

        CheckBox.SetActive(true);
        
        if (currentAction.action.bindings[bindingIndex].hasOverrides)
        {
            _path = currentAction.action.bindings[bindingIndex].overridePath;
        }
        else
        {
            _path = currentAction.action.bindings[bindingIndex].path;
        }
        //만약 InputAction이 override되지 않았다면 기존의 default 경로를, override 되었으면 기존의 override 된 경로를 _path에 넣어줌.
       
        _rebindingOperation = currentAction.action.PerformInteractiveRebinding(bindingIndex)
            .WithControlsExcluding("<Mouse>/rightButton")  //해당 키는 무시
            .WithCancelingThrough("<Mouse>/leftButton")    //해당 키를 누르면 바인딩이 취소됨
            .OnCancel(operation => RebindCancel())         //바인딩 취소시 콜백함수
            .OnComplete(operation => RebindComplete())     //바인딩 완료시 콜백함수
            .Start();                                      //실행
        /*사용자의 입력을 받고 처리해야 하기에 리바인딩은 일반 메서드처럼 한번에 실행 불가.
          InputActionRebindingExtensions.RebindingOperation 타입 변수를 반환*/
    }

    //리바인딩 취소 시 실행 메서드
    public void RebindCancel()
    { 
        _rebindingOperation.Dispose();
        currentAction.action.Enable();
        CheckBox.SetActive(false);
    }

    //리바인딩 완료 시 실행 메서드
    public void RebindComplete()
    {
        CheckBox.SetActive(false);
        _rebindingOperation.Dispose();
        /*유니티 공식문서에 따르면 리바인딩 동작을 반드시 Dispose 해줘야 함.
        GC가 처리해주지 않기 때문. OnComplete(operation...)이 여기에 해당하며 이걸 사용해도 되나, 변수로 만들어 사용함.*/
        
        currentAction.action.Enable();

        if (CheckDuplicate(currentAction.action, bindingIndex))
        {
            if (_path != null)
            {
                currentAction.action.ApplyBindingOverride(bindingIndex, _path);
            }
            return;
        }
        //중복된 키가 있을 경우 InputAction의 경로를 갱신하지 않고 기존의 경로로 덮어씌움.
        
        ShowBindText();
    }

    //바인딩된 입력 키를 버튼에 보여줄 메서드
    public void ShowBindText()
    { 
        var displayString = string.Empty;
        var deviceLayoutName = default(string);
        var controlPath = default(string);

        displayString = currentAction.action.GetBindingDisplayString(bindingIndex, out deviceLayoutName, out controlPath, displayStringOptions);
        /*바인딩된 인덱스를 매개변수로 설정, 대다수의 InputAction은 하나의 키만 설정되어 있으므로 0번만 존재.
          기기의 정보와 경로를 out으로 설정, 키보드에서 S를 누르면 deviceLayoutName은 키보드로, controlPath는 S가 됨.
          마지막 인자는 설정 = 키만 보이게 할지, 장치도 같이 보이게 할지 결정*/

        displayBindingKey.text = displayString;
    }

    //바인딩키 중복 여부 검사 메서드
    private bool CheckDuplicate(InputAction action, int index)
    { 
        InputBinding newBinding = action.bindings[index];
        
        foreach(InputBinding binding in action.actionMap.bindings)
        { 
            if (binding.action == newBinding.action)
            { 
                continue;
            }
            if (binding.effectivePath == newBinding.effectivePath)
            {
                return true;
            }
        }
        /*InputAction에서 actionMap의 모든 InputBinding을 가져옴.
          이후 반복문을 돌려 자기자신이면 무시, InputBinding의 경로가 같은 게 있다면 중복으로 판단*/
        
        return false;
    }
}
