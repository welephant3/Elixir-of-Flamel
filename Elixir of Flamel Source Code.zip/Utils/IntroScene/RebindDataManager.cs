using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class RebindDataManager : MonoBehaviour
{
    public InputActionAsset Actions;  //해당 변수를 통째로 Json형태로 바꾼 String 값을 PlayerPrefs로 저장/불러오는 방식

    [SerializeField] private List<RebindActionOption> rebindActionOptions = new List<RebindActionOption>();

    public void OnEnable()
    {
        var rebinds = PlayerPrefs.GetString("rebinds");
        if (!string.IsNullOrEmpty(rebinds))
        { 
            Actions.LoadBindingOverridesFromJson(rebinds);
        }

        //불러올 때 모든 버튼의 텍스트 갱신
        foreach (RebindActionOption rebindActionOption in rebindActionOptions)
        {
            rebindActionOption.ShowBindText();
        }
    }

    public void OnDisable()
    {
        var rebinds = Actions.SaveBindingOverridesAsJson();
        PlayerPrefs.SetString("rebinds", rebinds);
    }

    //키세팅 리셋 메서드
    public void resetAllBindings()
    {
        foreach (InputActionMap map in Actions.actionMaps)
        {
            map.RemoveAllBindingOverrides();
        }

        foreach (RebindActionOption rebindActionOption in rebindActionOptions)
        {
            rebindActionOption.ShowBindText();
        }

        PlayerPrefs.DeleteKey("rebinds");
    }
}