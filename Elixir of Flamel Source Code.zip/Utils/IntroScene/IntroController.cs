using UnityEngine;
using UnityEngine.UI;

public class IntroController : MonoBehaviour
{
    [SerializeField] Button[] button;
    [SerializeField] GameObject obj;

    public void GameExit()
    {
        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
        #else
            Application.Quit();
        #endif
    }    

    public void SetSibling(int index)
    {
        obj.transform.SetAsLastSibling();
        button[index].transform.SetAsLastSibling();
    }
}
