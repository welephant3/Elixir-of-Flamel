using TMPro;
using UnityEngine;

public class EventDetail : MonoBehaviour
{
    public TextMeshProUGUI leftBtnText;
    public TextMeshProUGUI rightBtnText;
    public TextEffect textEffect;

    public void RandomEvent(int randomint)
    {
        if (randomint == 1)
        {
            textEffect.fullText = "경비대가 순찰중에, 마을 근처에\r\n괴물들이 몰려있는 모습을 \r\n확인했습니다.\r\n\r\n괴물 무리의 습격을 걱정하는\r\n주민들이 많습니다.\r\n\r\n마을 근처의 경비를 \r\n더욱 강화할까요?";
            leftBtnText.text = "경비를\r\n강화하자.";
            rightBtnText.text = "인력이\r\n부족하다.";
        }
        else if (randomint == 2)
        {            textEffect.fullText = "마을에 소란이 일어나 \r\n확인해보니,\r\n\r\n다른 마을에서\r\n피난민들이 들어오려는것\r\n같습니다.\r\n\r\n\r\n피난민들을 받아들이겠습니까?";
            leftBtnText.text = "그들을\r\n보호하자.";
            rightBtnText.text = "위험하니\r\n거절한다.";
        }
        else if (randomint == 3)
        {
            textEffect.fullText = "병사들중 환자가 \r\n대량으로 발생했습니다.\r\n\r\n이대로는 인력이 부족하기에,\r\n병사를 더욱 늘리려합니다.\r\n\r\n어떻게 하시겠습니끼?";
            leftBtnText.text = "어린이와\r\n노인까지";
            rightBtnText.text = "환자를\r\n그대로\r\n전장에";
        }
    }

    public void StoryEvent(int eventint)
    {
        if(eventint == 1)
        {
            textEffect.fullText = "옆나라의 살아남은 피난민들이\r\n마을로 들어오고 있습니다.\r\n\r\n피난민 중 리더로 보이는 자가\r\n당신을 만나고 싶어합니다.";
            leftBtnText.text = "이야기를\r\n들어본다";
            rightBtnText.text = "";
        }
        else if(eventint == 2)
        {
            textEffect.fullText = "마을의 경비병에게\r\n급한 보고가 들어왔습니다.\r\n\r\n경비병은 급히 망원경을 들고\r\n마을에서 부터 멀리 떨어진\r\n산을 바라보라 외쳤습니다.";
            leftBtnText.text = "망원경을\r\n바라본다";
            rightBtnText.text = "";
        }
    }
}
