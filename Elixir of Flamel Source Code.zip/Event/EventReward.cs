using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class EventReward : MonoBehaviour
{
    public TextMeshProUGUI eventRewardNegativeText;
    public TextMeshProUGUI eventRewardPositiveText;
    public TextEffect textEffect;
    public Button closeBtn;

    public ResourceData resourceData;
    public DefenseData defenseData;
    public TowerDamageMultiplierData towerDamageMultiplierData;

    public void RandomEventReward(int randomInt)
    {
        if (randomInt == 1)
        {
            textEffect.fullText = "마을 근처의 경비를 증원시켰습니다.\r\n제보받은대로, 무리지은 괴물들을\r\n성공적으로 처리하였습니다.\r\n\r\n주민들의 걱정거리가\r\n하나 사라졌습니다.\r\n\r\n하지만, 경비를 지원한 병사들의\r\n피해가 속출하였습니다.";
            eventRewardNegativeText.text = "요새 공격력 감소";
            eventRewardPositiveText.text = "\r\n적 세력 감소";
            TowerDecreaseDamage();
            EnemyDecrease(5);
        }
        else if(randomInt == 2)
        {
            textEffect.fullText = "당신은 괴물 무리가 위협적이지 않다\r\n판단하여 무시하고 중요한 오늘 밤의\r\n싸움을 준비하였습니다.\r\n\r\n괴물 무리들은 밤이 되자,\r\n우르르 몰려오기 시작했습니다.\r\n그러나, 마을의 방어벽은 앞서\r\n준비했듯이 견고해졌습니다.";
            eventRewardNegativeText.text = "적 세력 증가";
            eventRewardPositiveText.text = "\r\n요새 공격력 증가";
            EnemyIncrease(5);
            TowerIncreaseDamage();
        }
        else if(randomInt == 3)
        {
            textEffect.fullText = "피난민들을 받아들였습니다.\r\n\r\n그들은 호의에 감사를 표하며\r\n마을에 도움을 줄것을\r\n약속하였습니다.\r\n\r\n하지만, 피난민들을 쫒아온\r\n괴물들이 마을을 향해\r\n오고 있습니다.";
            eventRewardNegativeText.text = "적 세력 증가";
            eventRewardPositiveText.text = "\r\n인력 증가";
            EnemyIncrease(5);
            ResourcesIncrease(4);
        }
        else if (randomInt == 4)
        {
            textEffect.fullText = "피난민들을 돌려보냈습니다.\r\n\r\n그들은 절망하였고, \r\n주민들은 당신에게 실망하였습니다.\r\n\r\n그리고, 피난민들이 돌아가면서,\r\n마을 주변 괴물들의 주의가 끌려,\r\n마을을 향하던 위협이 \r\n미세하게 사라졌습니다.";
            eventRewardNegativeText.text = "요새 공격력 감소";
            eventRewardPositiveText.text = "\r\n적 세력 감소";
            TowerDecreaseDamage();
            EnemyDecrease(5);
        }
        else if (randomInt == 5)
        {
            textEffect.fullText = "당신은 남녀노소를 불문하고\r\n병사로 차출하였습니다.\r\n\r\n일시적으로 인력이 충당되었지만,\r\n익숙치 않은 전장을 겪는\r\n병사들로 인해 \r\n사기가 저하되었습니다.";
            eventRewardNegativeText.text = "요새 공격력 대폭 감소";
            eventRewardPositiveText.text = "\r\n인력 증가";
            TowerDecreaseDamage(); 
            TowerDecreaseDamage();
            ResourcesIncrease(4);
        }
        else if (randomInt == 6)
        {
            textEffect.fullText = "당신은 다친 환자들도\r\n다시 전장으로 내보냈습니다.\r\n\r\n병사들은 다친 몸을 이끌고\r\n전장에서 전투하여\r\n사기가 저하되었습니다.";
            eventRewardNegativeText.text = "요새 공격력 감소";
            eventRewardPositiveText.text = "";
            TowerDecreaseDamage();
        }
    }

    public void StoryEventReward(int eventint)
    {
        if(eventint == 1)
        {
            textEffect.fullText = "리더는 당신에게 옆 나라에서 본\r\n괴물에 대해 이야기해주었습니다.\r\n\r\n괴물들 중, 특출나게 커다란\r\n개체가 존재하였고, 그 존재에 의해\r\n옆나라가 멸망하게 되었다는 정보를\r\n들은 당신은, 그에 대한 준비를\r\n하기로 하였습니다.\r\n";
            eventRewardNegativeText.text = "";
            eventRewardPositiveText.text = "\r\n인력 증가";
            ResourcesIncrease(8);
        }
        else if(eventint == 2)
        {
            textEffect.fullText = "망원경을 바라본 당신은,\r\n마을을 향해 오고있는 커다란\r\n괴물을 보았습니다.\r\n\r\n아직까지는 마을과는 거리가 있으나\r\n그 괴물은 천천히, 마을과의 거리를\r\n좁히고 있었습니다.\r\n\r\n당신은, 이제 주어진 시간이 얼마\r\n남지 않았다는것을 깨달았습니다.";
            eventRewardNegativeText.text = "";
            eventRewardPositiveText.text = "";
        }
    }

    public void TowerDecreaseDamage()
    {
        towerDamageMultiplierData.SetDamageMultiplier(towerDamageMultiplierData.damageMultiplier *= 0.75f);
    }
    public void TowerIncreaseDamage()
    {
        towerDamageMultiplierData.SetDamageMultiplier(towerDamageMultiplierData.damageMultiplier *= 1.25f);
    }
    public void EnemyDecrease(int enemy)
    {
        defenseData.maxEnemies -= enemy;
    }
    public void EnemyIncrease(int enemy)
    {
        defenseData.maxEnemies += enemy;
    }
    public void ResourcesDecrease(int enemy)
    {
        resourceData.totalResources -= enemy;
    }
    public void ResourcesIncrease(int enemy)
    {
        resourceData.totalResources += enemy;
    }
    public void CloseBtn()
    {
        EventUIManager.Instance.OnCloseBtnClick();
    }
}
