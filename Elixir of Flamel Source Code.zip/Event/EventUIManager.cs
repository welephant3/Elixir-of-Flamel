using UnityEngine;

public class EventUIManager : Singleton<EventUIManager>
{
    public EventDetail eventDetail; 
    public EventReward eventReward;
    public CommonUI commonUI;

    private int randomInt;

    public void ShowEventUI()
    {
        UIController.Instance.ShowUI<EventUI>(UIs.Popup);
    }
    public void HideEventUI()
    {
        UIController.Instance.HideUI<EventUI>();
    }
    public void ShowEventRewardUI()
    {
        UIController.Instance.ShowUI<EventRewardUI>(UIs.Popup);
    }
    public void HideEventRewardUI()
    {
        UIController.Instance.HideUI<EventRewardUI>();
    }        

    public void StartRandomEvent() // 이벤트 시작 시 랜덤 이벤트 출현
    {
        ShowEventUI();
        randomInt = Random.Range(1, 4);
        eventDetail.RandomEvent(randomInt);
    }
    public void StartStoryEvent()
    {
        if(TimeSystem.Instance.day == 5)
        {
            eventDetail.StoryEvent(1);
            ShowEventUI();
        }
        else if(TimeSystem.Instance.day == 10)
        {
            eventDetail.StoryEvent(2);
            ShowEventUI();
        }
    }

    public void OnButtonClick(int ButtonIndex) // 이벤트 왼,오 버튼 눌렀을시 나올 리워드
    {
        if(TimeSystem.Instance.day == 5)
        {
            if (ButtonIndex == 1)
            {
                ShowEventRewardUI();
                eventReward.StoryEventReward(1);
                HideEventUI();
            }
        }
        else if(TimeSystem.Instance.day == 10)
        {
            if (ButtonIndex == 1)
            {
                HideEventUI();
                ShowEventRewardUI();
                eventReward.StoryEventReward(2);
            }
        }
        else
        {
            if (ButtonIndex == 1)
            {
                HideEventUI();
                ShowEventRewardUI();
                ShowEventReward(1);
            }
            else if (ButtonIndex == 2)
            {
                HideEventUI();
                ShowEventRewardUI();
                ShowEventReward(2);
            }
        }
    }
    public void OnCloseBtnClick()
    {
        HideEventRewardUI();
        TimeSystem.Instance.min+=2;
        commonUI.is_Pop_Up = false; 
        Time.timeScale = 1;
    }

    public void ShowEventReward(int ButtonIndex) //이벤트 선택 시 나올 리워드
    {
        if(randomInt == 1)
        {
            if(ButtonIndex == 1)
            {
                eventReward.RandomEventReward(1);
            }
            else
            {
                eventReward.RandomEventReward(2);
            }
        }
        else if (randomInt == 2)
        {
            if (ButtonIndex == 1)
            {
                eventReward.RandomEventReward(3);
            }
            else
            {
                eventReward.RandomEventReward(4);
            }
        }
        else if (randomInt == 3)
        {
            if (ButtonIndex == 1)
            {
                eventReward.RandomEventReward(5);
            }
            else
            {
                eventReward.RandomEventReward(6);
            }
        }
    }
}